# WholeBrain Mobile v0.6.0 — Authorized Voice Mimic

## מטרה
להוסיף למסלול הקולי של v0.5 חיקוי קולי מקומי ומורשה, בלי ענן ובלי לשנות את מנגנון הלמידה של המוח.

## מה מיושם

### 1. הרשאה מפורשת
מצב Mimic אינו זמין עד שהמשתמש מסמן במפורש שהקול שלו או שיש לו רשות להשתמש בו.

### 2. הקלטת דגימת ייחוס מקומית
- AudioRecord, mono PCM16, 16 kHz.
- עד 20 שניות; נדרשות לפחות 2 שניות ליצירת profile.
- בזמן ההקלטה קלט השמיעה של המוח מושהה כדי למנוע תחרות על המיקרופון וחוזר לאחר סיום.

### 3. Voice profile
הניתוח המקומי מפיק:
- fundamental pitch (F0) בעזרת autocorrelation;
- RMS / loudness;
- articulation-rate proxy;
- spectral brightness;
- 8 תחומי spectral envelope מנורמלים.

### 4. שלושה מצבי פלט
- **TTS** — הקול המקומי המותקן ללא התאמה.
- **Persona** — התאמת pitch וקצב לדגימת הייחוס.
- **Mimic** — Persona + post-processing של spectral envelope ו-loudness על קובץ ה-TTS המקומי.

### 5. עיבוד Mimic
העיבוד נעשה מקומית ב-C++:
- שלוש שכבות peaking-EQ שנגזרות מההבדל בין מעטפת המקור למעטפת היעד;
- normalization של RMS עם גבולות שמונעים amplification חריג;
- soft clipping;
- ניתוח חוזר של קובץ הפלט בפועל.

### 6. Visual output אמיתי
מסך הקול מציג:
- waveform של דגימת הייחוס;
- waveform של הקובץ המושמע בפועל;
- target מול output עבור pitch, brightness ו-energy;
- Acoustic Profile Match שמחושב מהפלט בפועל.

ה-Match הוא מדד של קרבת מאפיינים אקוסטיים בלבד. הוא **אינו** מדד ביומטרי לזהות דובר.

## פרטיות
- אין `android.permission.INTERNET`.
- reference WAV נשמר רק ב-app-private files.
- `voice_profiles/` מוחרג במפורש מ-cloud backup ומ-device transfer.
- Delete profile מוחק גם את הדגימה וגם את ה-profile.

## גבול טענה
v0.6 הוא **Authorized Acoustic Voice Mimic**. הוא מעביר pitch, pace, loudness וצבע ספקטרלי אל TTS מקומי. הוא אינו מודל neural speaker cloning ואינו טוען לשחזור זהות דובר ברמת forensic/biometric equivalence.

## בדיקות host
הבדיקות הסופיות עברו:
- Sensory topology / engine regression: PASS.
- Learning smoke: seeds 77/78/79 הגיעו `post=1.000`.
- Voice analysis: reference 120.3 Hz ו-source 205.1 Hz זוהו נכון.
- Mimic DSP: אורך האודיו נשמר ו-RMS התקרב ל-target.
- אין INTERNET permission.
