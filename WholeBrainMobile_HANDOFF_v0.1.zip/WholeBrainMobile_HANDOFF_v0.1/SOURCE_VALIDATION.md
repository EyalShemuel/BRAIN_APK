# Source validation

Local validation performed before packaging:

- C++20 host engine compile: PASS.
- deterministic topology/hash gate: PASS.
- exact CORE53 differential update algebra: PASS.
- no-action-without-evidence gate: PASS.
- sensor/event/save/restore native smoke: PASS.
- two-association reward-learning smoke, seeds 77/78/79: post-training accuracy 1.00 on all three seeds: PASS.
- JNI translation unit host compilation with JNI headers + Android log stub: PASS.
- all Android XML resources parse: PASS.
- Kotlin parser-level syntax check: PASS; full Android type resolution is blocked locally because Android SDK/dependencies are unavailable.
- full APK/AGP gate: PENDING GitHub Actions or an Android SDK-enabled machine.

Scientific boundary: the mobile recurrent engine is not yet certified spike-for-spike against the Python CLEAN CORE. Android behavioral capacity claims remain blocked until the device parity and K=6 regression gates pass.
