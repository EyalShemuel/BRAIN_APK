# Build status — WholeBrain Mobile v0.1

Generated: 2026-09-14

## Passed locally

- C++20 host build with CMake/Ninja.
- Deterministic topology/hash primitives.
- Exact CORE53 differential error-update algebra.
- Sensors -> spikes -> event propagation smoke.
- Save/restore of plastic output state.
- No phantom action when no evidence is present.
- Reward-learning smoke on seeds 77/78/79: pre ~= 0.44-0.49, post = 1.00.
- JNI translation unit compiles against host JNI headers plus a minimal Android log stub.
- All Android XML parses.
- Kotlin source has no parser-level syntax errors (Android classpath is unavailable locally).

## Blocked by environment, not accepted as PASS yet

- Full Gradle/AGP Android compile.
- APK generation/signing.
- On-device permission/capability tests.
- Android CPU vs Python CLEAN CORE state/spike parity.
- K=6 Android behavioral regression.
- 30-minute thermal endurance.
- Vulkan parity (backend intentionally not enabled in v0.1).

The current execution environment has no Android SDK/NDK installed and cannot reach the external SDK repositories. The connected GitHub identity is visible, but the GitHub App currently exposes zero installations/repositories, so GitHub Actions cannot be launched from this session until a repository is connected.
