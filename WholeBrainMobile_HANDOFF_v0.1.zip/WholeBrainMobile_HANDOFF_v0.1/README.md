# WholeBrain Mobile

Offline Android embodiment of the validated WholeBrain Clean Core / CORE53 research line.

## v0.1 scope

- 15-region event-driven spiking substrate.
- Procedural deterministic recurrent connectivity; no recurrent edge table.
- Runtime-selected neuron count and fanout from measured device throughput and memory headroom.
- CORE53-derived differential opponent Motor organ: the large common mode is rejected before Motor thresholding.
- Local plastic state only in the explicit Association→Motor differential weights; recurrent substrate is fixed in v0.1.
- Camera, microphone, Android SensorManager devices that the OS allows, touch, location, NFC, connected USB/Bluetooth context. Runtime permissions are user-triggered from Device > Enable available sensors.
- Local outputs: haptics, sound, optional torch, notifications.
- Observe / Learn / Act / Sleep modes. Sleep is a framework state only; replay/consolidation is not claimed in v0.1.
- Plastic state persisted locally on the device.

## Scientific claim boundary

The Android C++ engine preserves the validated **CORE53 motor update algebra**, and its host implementation is deterministic and tested. It is **not yet certified as full spike-by-spike parity with the Python CORE18 recurrent substrate**. That is a separate gate and must be measured before scientific results from Android are merged into the paper.

The Python reference remains under `reference/`.

## Scaling

The app does not hard-code "71M" as a performance claim. It benchmarks procedural-edge hashing on the device, applies a memory budget, and reports:

- Verified profile: 250k neurons, K=1024 (safe mobile engineering baseline; not a scientific scale claim).
- Balanced profile: device recommendation, guarded to a conservative startup ceiling.
- Max profile: largest computed N×K under the calibration model, up to 71M neurons and K=4096. This is experimental until sustained thermal/latency gates pass on that device.

Logical connections are `N × K`; they are regenerated on spikes and are not stored.

## Build

GitHub Actions: `.github/workflows/android.yml` builds the debug APK and uploads it as `wholebrain-mobile-debug-apk`.

Local Android build compiles against Android SDK 37 (targetSdk remains 36 until Android 17 behavior testing is complete), with Build Tools 36.0.0, NDK 28.2.13676358, JDK 17, Gradle 9.6.

```bash
gradle :app:assembleDebug
```

Host-native validation needs only CMake/Ninja and includes deterministic engine tests plus a 3-seed reward-learning smoke test:

```bash
./scripts/test_host.sh
```

## Privacy

Raw sensor streams stay on-device. There is no network permission in the manifest. Bluetooth/USB/NFC are local external-device channels only.

## Current build status

The native C++ core, JNI translation unit, XML resources and Kotlin parser pass local source checks in this environment. A full Android APK build still requires the Android SDK/NDK dependency download. The included GitHub Actions workflow performs that build and publishes the debug APK as an artifact. See `BUILD_STATUS.md` for the exact gate state.
