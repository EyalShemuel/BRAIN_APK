# WholeBrain Mobile v0.1 — חבילת מסירה

Git commit סופי: 0da02038a4cee28659014816bc611afab9cf051b

## מה בפנים
- WholeBrainMobile_SOURCE_v0.1.zip — snapshot נקי של כל המקור.
- WholeBrainMobile_v0.1.git.bundle — branch main והיסטוריית Git מלאה.
- README.md — יכולות ומבנה.
- BUILD_STATUS.md — מה עבר ומה עדיין חסום.
- SOURCE_VALIDATION.md — gates שבוצעו בפועל.
- GITHUB_SETUP.md — CI שמייצר APK.
- HOST_CI_OUTPUT.txt — פלט validation אמיתי.

## מצב APK
קוד ה-Android ו-GitHub Actions מוכנים, אך APK לא נבנה בסביבת ההרצה הנוכחית: אין Android SDK/NDK מקומי, וה-GitHub App המחובר כרגע אינו מותקן על repository זמין. לאחר חיבור repository, ה-workflow המוכן מתקין את Android SDK 37/NDK ובונה את ה-APK.
