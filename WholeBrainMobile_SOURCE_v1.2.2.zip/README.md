# v1.2.2 — S25 Responsive Brain Loop

This release replaces the v1.2.1 live-input FIFO/scheduled loop with a latest-value sensor mailbox and a dedicated adaptive brain thread. UI stats are wall-clock limited to ~6.7 Hz, ambient sensor callbacks never enter the native brain directly, and slow 250K/K256 steps reserve CPU/memory-bandwidth headroom instead of creating catch-up pressure. See `V1_2_2_S25_RESPONSIVENESS_REPORT_HE.md`.

# v1.2.1 mobile freeze hotfix

Fixes device UI stalls seen when a 250K/K256 step takes longer than the 10 ms simulation tick. Live Android sensor callbacks now use a bounded background mailbox, the step scheduler is self-paced (`scheduleWithFixedDelay`), and Observe mode skips reward eligibility accumulation while still applying learned synaptic weights. Scientific Learn/Act behavior is unchanged.

# WholeBrain Mobile v1.0.0 — Human Cortex Scaffold

This version adds an active biologically constrained cortical scaffold (layers, cell classes, apical dendrites, structured laminar connectivity and delays) while preserving the validated v0.9 BioSpeech path. It is not claimed to be a complete biological human cortex reconstruction. See `V1_0_HUMAN_CORTEX_SCAFFOLD_REPORT_HE.md`.

## v0.9.0 — BioSpeech sensorimotor cortex

- Active speech path: Language/Semantic/PFC → BG/Thalamus → vPMC-like Motor → VocalMotor → articulators → vocal-tract plant.
- Closed-loop Auditory and Somatosensory feedback with cerebellar forward correction.
- Learned state stores articulatory motor frames + sensory targets, not waveform replay.
- Explicit perturbation/lesion gates differentiate S1, Auditory, Cerebellum, Basal Ganglia, planner and VocalMotor.
- Cortical speech path includes a compact L4/L2/3/L5/L6 + pyramidal/PV/SST/VIP-like microcircuit approximation.
- Pointed Hebrew teaches explicit a/e/i/o/u/schwa units; 40-prompt developmental curriculum covers 28/28 core units.
- v0.8 serialization-v4 state has an explicit backward-compatibility gate. BioSpeech motor memories are new and require calibration.
- K256 sustained-load/camera stabilization is retained.
- No Android TTS, no active phrase replay, no INTERNET permission.

**Scientific boundary:** BioSpeech is a biologically constrained model, not a complete reconstruction of the human speech cortex/connectome.

See `V0_9_BIOSPEECH_REPORT_HE.md`.

## v0.8.0 — Generative Speech Cortex

- Active speech path has **no Android TTS** and **no whole-phrase waveform replay**.
- Text is converted to a sub-word cortical motor plan; Hebrew final forms share learned primitives.
- Teaching streams the prompt cue plus live microphone chunks into the brain while recording.
- Native consolidation learns reusable sub-word VocalMotor primitives and within-word co-articulation transitions.
- Generative primitives store acoustic frames (`F0`, voicing, RMS, LPC-10), not replay PCM.
- A local cortical vocoder synthesizes a new waveform for never-recorded unit sequences.
- Punctuation drives timing/prosody; questions and statements take different F0/tempo trajectories.
- 30-prompt Hebrew rapid curriculum covers all 22 normalized core letters.
- Serialization v4 remains backward compatible with v0.6.x motor state and v0.7 legacy speech state.
- v0.6.1 K256 sustained-load/camera stabilization is retained.
- No INTERNET permission.

See `V0_8_GENERATIVE_SPEECH_CORTEX_REPORT_HE.md`.

## v0.7.0 — Neural Speech / VocalMotor

- Android TextToSpeech removed from the active speech path.
- Speech is learned from local microphone examples and stored as native VocalMotor engrams with brain plasticity.
- Recall produces PCM from learned brain state and uses AudioTrack only as the physical speaker actuator.
- Exact-phrase recall plus learned-word composition; unknown words never fall back to TTS.
- 24-item Hebrew fast-learning speech curriculum with automatic silence completion.
- v0.6.x motor-plasticity state remains backward-compatible.
- v0.6.1 K256 sustained-load/camera performance stabilization is retained.
- No INTERNET permission.

See `V0_7_NEURAL_SPEECH_REPORT_HE.md`.

## v0.6.0 — Authorized Voice Mimic

- Explicitly authorized local voice enrollment: user must attest ownership or permission.
- Raw enrollment audio is temporary only and is deleted after acoustic profiling.
- Offline acoustic mimic over local Android TTS: pitch + spectral-envelope/timbre + dynamics matching.
- Voice fingerprint UI compares reference vs last synthesized output and reports acoustic-profile match.
- Brain microphone capture is paused during enrollment and restored automatically.
- Voice-mimic preferences are excluded from Android cloud backup/device transfer.
- No INTERNET permission.
- Exact v0.5 neural trace / 1:1 active-neuron and recurrent-edge view remains unchanged.


## v0.5.0 — Voice + Exact Neural View

- Offline Android speech output with no INTERNET permission.
- Motor Action 1/2 can speak user-defined phrases.
- Synthesized audio waveform is derived from the actual local output file.
- Exact native neural trace: every fired neuron ID and every recurrent edge from the selected timestep.
- 20-step native history buffer, enabled only while Neural View is open.
- v0.6 reserved for authorized voice mimic/clone.

# WholeBrain Mobile

## 0.4.0 — Premium UX

The interface was rebuilt around everyday usability rather than engineering diagnostics:
- Four primary destinations: Live, Teach, Memory, System.
- Brain and Device are grouped under System to reduce bottom-navigation clutter.
- Live opens with one-glance brain health, input profile, activity, sense cards, and optional advanced diagnostics.
- Touch sensing uses a dedicated sensor pad so UI control taps do not contaminate somatosensory input.
- Teach focuses on one decision and two large consequence buttons, with learning guards.
- Memory owns save/restore actions.
- Device details and hardware lists are progressively disclosed.
- Larger touch targets, clearer hierarchy, accessible contrast, cleaner typography, rounded neutral surfaces, and dark-mode parity.


Offline Android embodiment of the WholeBrain Clean Core / CORE53 research line.

## 0.3.0 — Sensory Topology v3

The physical sensory front end is now scale-stable and modality-specific rather than a fixed tiny random population:

- Vision: 64×36 retinotopic retina, 10 roles/cell (luma, temporal, edges, chroma), orientation-corrected YUV sampling.
- Audio: 32 logarithmic tonotopic bands with microphone-floor rejection and onset coding.
- Touch: 32×18 somatotopic surface with contact, pressure, motion polarity and release.
- IMU/gyro/magnetometer/orientation: calibrated delta channels by sensor/axis/polarity; constant gravity/DC is rejected.
- Environment/body: calibrated level/change channels; one-shot trigger sensors; battery/thermal interoception.
- GPS: 200m/50m/10m multi-scale hippocampal place coding plus speed/bearing.
- External: NFC, USB attach/detach, Bluetooth/BLE context, network-state context with scale-stable distributed Semantic/Association banks.
- Validation UI isolates VISION / AUDIO / TOUCH / IMU / ENV / GPS / EXT / ALL and exposes real per-modality injection rates plus 15-region spike rates.

The scientific channel-9 teaching cue remains locked to the pre-v3 injection semantics. Reward-learning regression remains 1.000 post-training on seeds 77/78/79.

See `SENSORY_TOPOLOGY_V3_REPORT_HE.md` for the exact mapping and validation details.

## Scientific claim boundary

The Android C++ engine preserves the CORE53 differential motor update algebra and passes the host regression suite. Android runtime scale (for example 250K/K1024) is an engineering execution scale, not a scientific K1024 capability claim. Scientifically validated capacity remains bounded by the separately measured Clean Core experiments.

## Scaling

Logical recurrent connections are procedural (`N × K`) and regenerated on spikes rather than stored as a giant edge table. Scale is device-calibrated; 71M/K4096 remains only an implementation ceiling.

## Build

Expected Android toolchain:
- JDK 17
- Gradle 9.6
- AGP 9.4
- Android SDK 37.2 for compile (targetSdk 36)
- NDK 28.2.13676358

Host validation:

```bash
./scripts/test_host.sh
```

Android debug APK:

```bash
gradle :app:assembleDebug
```

## Privacy

Raw sensory processing is local. The manifest has no `INTERNET` permission. Network state is context only. External-device channels are opt-in and permission-gated where Android requires it.
