package com.eyalshemuel.wholebrainmobile.brain

private class RecordingConsumer : LatestLiveInputMailbox.Consumer {
    var camera = 0
    val sensors = mutableListOf<LatestLiveInputMailbox.SensorSample>()
    val touches = mutableListOf<LatestLiveInputMailbox.TouchSample>()
    val locations = mutableListOf<LatestLiveInputMailbox.LocationSample>()
    val visions = mutableListOf<LatestLiveInputMailbox.VisionSample>()
    val audios = mutableListOf<LatestLiveInputMailbox.AudioSample>()
    val tokens = mutableListOf<LatestLiveInputMailbox.TokenSample>()
    override fun onCameraFrame() { camera++ }
    override fun onSensor(sample: LatestLiveInputMailbox.SensorSample) { sensors += sample }
    override fun onTouch(sample: LatestLiveInputMailbox.TouchSample) { touches += sample }
    override fun onLocation(sample: LatestLiveInputMailbox.LocationSample) { locations += sample }
    override fun onVision(sample: LatestLiveInputMailbox.VisionSample) { visions += sample }
    override fun onAudio(sample: LatestLiveInputMailbox.AudioSample) { audios += sample }
    override fun onToken(sample: LatestLiveInputMailbox.TokenSample) { tokens += sample }
}

fun main() {
    val box = LatestLiveInputMailbox()
    val out = RecordingConsumer()

    box.offerCameraFrame(); box.offerCameraFrame(); box.offerCameraFrame()
    box.offerSensor(1, 1f, 2f, 3f)
    box.offerSensor(1, 9f, 8f, 7f) // same type must coalesce to newest
    box.offerSensor(4, 4f, 5f, 6f) // distinct type must survive
    box.offerTouch(.1f, .2f, .3f)
    box.offerTouch(.7f, .8f, .9f)
    box.offerLocation(1.0, 2.0, 3f, 4f)

    val vision = byteArrayOf(1, 2, 3)
    box.offerVision(vision, 1, 1)
    vision[0] = 99 // mailbox must have snapshotted reused producer memory

    val audio = shortArrayOf(10, 20)
    box.offerAudio(audio, 16_000)
    audio[0] = 99

    box.offerToken(2, byteArrayOf(1))
    box.offerToken(2, byteArrayOf(8))

    box.drain(out)

    check(out.camera == 1) { "camera events were not coalesced" }
    check(out.sensors.size == 2) { "expected one latest sample for each sensor type" }
    check(out.sensors.single { it.type == 1 }.x == 9f) { "sensor latest value lost" }
    check(out.touches.single().pressure == .9f) { "touch latest value lost" }
    check(out.visions.single().pixels[0].toInt() == 1) { "vision buffer alias leaked" }
    check(out.audios.single().pcm[0].toInt() == 10) { "audio buffer alias leaked" }
    check(out.tokens.single().data[0].toInt() == 8) { "token latest value lost" }

    val second = RecordingConsumer()
    box.drain(second)
    check(second.camera == 0 && second.sensors.isEmpty() && second.visions.isEmpty() && second.audios.isEmpty()) {
        "drain was not destructive"
    }

    box.offerSensor(7, 1f, 1f, 1f)
    box.offerAudio(shortArrayOf(1), 16_000)
    box.clear()
    val cleared = RecordingConsumer()
    box.drain(cleared)
    check(cleared.sensors.isEmpty() && cleared.audios.isEmpty()) { "clear left pending data" }

    println("PASS latest_live_input_mailbox coalescing copy-isolation destructive-drain clear")
}
