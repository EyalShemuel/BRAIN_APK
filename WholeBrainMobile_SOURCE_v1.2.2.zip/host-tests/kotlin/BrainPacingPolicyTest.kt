package com.eyalshemuel.wholebrainmobile.brain

fun main() {
    // Android currently uses 3/4 for severe/critical; pass explicit thresholds so this
    // policy stays JVM-testable without Android framework classes.
    val severe = 3
    val critical = 4

    val fast = BrainPacingPolicy.cooldownNs(8.0, 0, severe, critical) / 1_000_000.0
    val medium = BrainPacingPolicy.cooldownNs(35.0, 0, severe, critical) / 1_000_000.0
    val s25Observed = BrainPacingPolicy.cooldownNs(72.0, 0, severe, critical) / 1_000_000.0
    val hot = BrainPacingPolicy.cooldownNs(72.0, severe, severe, critical) / 1_000_000.0
    val criticalHot = BrainPacingPolicy.cooldownNs(72.0, critical, severe, critical) / 1_000_000.0

    check(fast in 1.0..3.0) { "fast steps should stay aggressive: $fast" }
    check(medium > fast) { "medium steps must reserve more headroom" }
    check(s25Observed >= 25.0) { "72 ms device step should leave substantial UI headroom: $s25Observed" }
    check(hot > s25Observed) { "severe thermal state must back off further" }
    check(criticalHot >= hot) { "critical thermal state must not increase duty" }
    check(criticalHot <= 100.0) { "cooldown cap violated" }

    println("PASS brain_pacing fast=$fast medium=$medium s25_72ms=$s25Observed severe=$hot critical=$criticalHot")
}
