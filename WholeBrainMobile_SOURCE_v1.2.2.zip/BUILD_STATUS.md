# Build Status — WholeBrain Mobile v1.2.2 S25 Responsive

- versionName 1.2.2 / versionCode 18: PASS
- Verified profile 250K neurons / K256: preserved
- Dedicated native brain thread: PASS
- Fixed-rate/fixed-delay scheduler in active brain loop: NONE
- Ambient sensor JNI from callback threads: NONE
- Latest-value mailbox per modality/type: PASS
- Camera/audio producer buffer copy isolation: PASS
- 30,000 ambient offers -> 3 latest values on single drain: PASS
- Adaptive pacing at observed 72 ms S25 step: ~30.9 ms cooldown
- UI stats cadence: 150 ms (~6.7 Hz)
- Main-thread Load path: async
- Learning smoke seeds 77/78/79: PASS
- Neural speech / generative speech / BioSpeech: PASS
- Cortical microcircuit: PASS
- dynamics_gate: PASS, scale_spread=1.32x
- topography_gate: PASS, decode gain +0.250
- plasticity_gate: PASS, dprime=1.820, post=0.830
- BioSpeech curriculum: PASS, 40 prompts / 28 core units
- Android TTS: NONE
- INTERNET permission: NONE
- Android APK compile/build: pending GitHub Actions

# Build Status — WholeBrain Mobile v0.9.0 BioSpeech

- Source integration: PASS
- versionName 0.9.0 / versionCode 13: PASS
- Native sensory/topology regression: PASS
- Sustained K256 performance stability: PASS
- Learning smoke seeds 77/78/79: PASS
- Legacy v0.7 speech persistence: PASS
- v0.8 novel generative speech compatibility: PASS
- Explicit v0.8 serialization-v4 restore into v0.9: PASS
- BioSpeech articulatory novel-sequence gate: PASS
- Motor + VocalMotor activation: PASS
- Jaw perturbation closed-loop compensation: PASS
- Independent S1 feedback lesion gate: PASS
- Independent auditory feedback lesion gate: PASS
- Dual-feedback lesion gate: PASS
- Cerebellar correction lesion gate: PASS
- Auditory F1/F2 perturbation adaptation: PASS
- Planner / VocalMotor / BasalGanglia lesion differentiation: PASS
- BioSpeech persistence/restore: PASS
- Active Android TTS dependency: NONE
- Active phrase replay: NONE
- Active v0.8 acoustic-generator fallback: NONE
- BioSpeech persistence stores motor/sensory frames, not PCM replay: PASS
- Hebrew developmental curriculum: 40 prompts, 28/28 core units
- No INTERNET permission: preserved
- Android APK compile/build: pending GitHub Actions

Latest BioSpeech host result:
`PASS biospeech primitives=3 baseline_samples=10432 jaw_before=0.034877 jaw_after=0.000305049 cereb_after=0.034877 auditory_before=0.113459 auditory_after=0.0657209 auditory_lesion_after=0.113459 s1_lesion_after=0.00591345 motor_auditory_lesion_after=0.000727233 dual_feedback_lesion_after=0.034877 compensation=0.102165`


## v1.0.0 Human Cortex Scaffold
- 5 cortical layers with area-specific fractions
- IT/ET/CT/PV/SST/VIP/LAMP5 phenotypes
- apical dendritic state + adaptation
- structured local/feedforward/feedback laminar connectivity
- thalamorecipient L4/L6 routing and conduction-delay model
- all host regressions PASS including K256 sustained load and BioSpeech
