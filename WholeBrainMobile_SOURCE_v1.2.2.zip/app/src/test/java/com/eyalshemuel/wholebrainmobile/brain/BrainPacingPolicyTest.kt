package com.eyalshemuel.wholebrainmobile.brain

import org.junit.Assert.assertTrue
import org.junit.Test

class BrainPacingPolicyTest {
    @Test fun slowStepsReserveIncreasingUiHeadroom() {
        val severe = 3
        val critical = 4
        fun ms(step: Double, thermal: Int = 0) =
            BrainPacingPolicy.cooldownNs(step, thermal, severe, critical) / 1_000_000.0

        val fast = ms(8.0)
        val medium = ms(35.0)
        val s25Observed = ms(72.0)
        val hot = ms(72.0, severe)
        val criticalHot = ms(72.0, critical)

        assertTrue(fast in 1.0..3.0)
        assertTrue(medium > fast)
        assertTrue(s25Observed >= 25.0)
        assertTrue(hot > s25Observed)
        assertTrue(criticalHot >= hot)
        assertTrue(criticalHot <= 100.0)
    }
}
