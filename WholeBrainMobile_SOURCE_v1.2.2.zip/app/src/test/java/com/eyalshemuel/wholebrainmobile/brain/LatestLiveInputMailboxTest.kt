package com.eyalshemuel.wholebrainmobile.brain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LatestLiveInputMailboxTest {
    private class Sink : LatestLiveInputMailbox.Consumer {
        var camera = 0
        val sensors = mutableListOf<LatestLiveInputMailbox.SensorSample>()
        val touches = mutableListOf<LatestLiveInputMailbox.TouchSample>()
        val locations = mutableListOf<LatestLiveInputMailbox.LocationSample>()
        val visions = mutableListOf<LatestLiveInputMailbox.VisionSample>()
        val audios = mutableListOf<LatestLiveInputMailbox.AudioSample>()
        val tokens = mutableListOf<LatestLiveInputMailbox.TokenSample>()
        override fun onCameraFrame() { camera++ }
        override fun onSensor(sample: LatestLiveInputMailbox.SensorSample) { sensors += sample }
        override fun onTouch(sample: LatestLiveInputMailbox.TouchSample) { touches += sample }
        override fun onLocation(sample: LatestLiveInputMailbox.LocationSample) { locations += sample }
        override fun onVision(sample: LatestLiveInputMailbox.VisionSample) { visions += sample }
        override fun onAudio(sample: LatestLiveInputMailbox.AudioSample) { audios += sample }
        override fun onToken(sample: LatestLiveInputMailbox.TokenSample) { tokens += sample }
    }

    @Test fun latestValuesReplaceStaleSamplesAndCopyReusableBuffers() {
        val box = LatestLiveInputMailbox()
        val sink = Sink()

        repeat(3) { box.offerCameraFrame() }
        box.offerSensor(1, 1f, 2f, 3f)
        box.offerSensor(1, 9f, 8f, 7f)
        box.offerSensor(4, 4f, 5f, 6f)
        box.offerTouch(.1f, .2f, .3f)
        box.offerTouch(.7f, .8f, .9f)

        val vision = byteArrayOf(1, 2, 3)
        box.offerVision(vision, 1, 1)
        vision[0] = 99
        val audio = shortArrayOf(10, 20)
        box.offerAudio(audio, 16_000)
        audio[0] = 99
        box.offerToken(2, byteArrayOf(1))
        box.offerToken(2, byteArrayOf(8))

        box.drain(sink)
        assertEquals(1, sink.camera)
        assertEquals(2, sink.sensors.size)
        assertEquals(9f, sink.sensors.single { it.type == 1 }.x)
        assertEquals(.9f, sink.touches.single().pressure)
        assertEquals(1, sink.visions.single().pixels[0].toInt())
        assertEquals(10, sink.audios.single().pcm[0].toInt())
        assertEquals(8, sink.tokens.single().data[0].toInt())

        val second = Sink()
        box.drain(second)
        assertTrue(second.sensors.isEmpty())
        assertTrue(second.visions.isEmpty())
        assertTrue(second.audios.isEmpty())
    }

    @Test fun clearDropsAllPendingAmbientInputs() {
        val box = LatestLiveInputMailbox()
        box.offerSensor(7, 1f, 1f, 1f)
        box.offerAudio(shortArrayOf(1), 16_000)
        box.offerToken(3, byteArrayOf(4))
        box.clear()
        val sink = Sink()
        box.drain(sink)
        assertTrue(sink.sensors.isEmpty())
        assertTrue(sink.audios.isEmpty())
        assertTrue(sink.tokens.isEmpty())
    }
}
