package com.eyalshemuel.wholebrainmobile.brain

/** Pure wall-clock pacing policy; it never changes the simulated biological timestep. */
internal object BrainPacingPolicy {
    fun cooldownNs(
        stepMs: Double,
        thermalStatus: Int,
        severeStatus: Int,
        criticalStatus: Int
    ): Long {
        val safeStepMs = stepMs.coerceAtLeast(0.1)
        val duty = when {
            thermalStatus >= criticalStatus -> 0.35
            thermalStatus >= severeStatus -> 0.50
            safeStepMs >= 60.0 -> 0.70
            safeStepMs >= 35.0 -> 0.76
            safeStepMs >= 20.0 -> 0.82
            else -> 0.88
        }
        val cooldownMs = safeStepMs * (1.0 / duty - 1.0)
        val maxMs = if (thermalStatus >= severeStatus) 100.0 else 32.0
        return (cooldownMs.coerceIn(1.0, maxMs) * 1_000_000.0).toLong()
    }
}
