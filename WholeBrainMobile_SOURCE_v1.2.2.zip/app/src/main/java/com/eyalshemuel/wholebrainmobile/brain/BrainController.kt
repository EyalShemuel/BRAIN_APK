package com.eyalshemuel.wholebrainmobile.brain

import android.app.ActivityManager
import android.content.Context
import android.hardware.Sensor
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.util.Log
import com.eyalshemuel.wholebrainmobile.storage.BrainStateStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.LockSupport
import kotlin.math.min

class BrainController(private val context: Context) {
    companion object {
        // UI snapshots are intentionally decoupled from the biological simulation tick.
        // 150 ms = 6.7 Hz, inside the 5-10 Hz range that stays responsive on-device.
        private const val UI_STATS_INTERVAL_NS = 150_000_000L
        private const val TRACE_INTERVAL_NS = 250_000_000L
    }

    // Control work (build/save/restore) is separate from the continuously running brain.
    // The native simulation itself owns one dedicated thread and is never scheduled by a
    // fixed-rate executor, so a slow 70 ms step cannot create catch-up pressure.
    private val controlExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "WholeBrain-Control").apply { priority = Thread.NORM_PRIORITY }
    }
    private val loopRunning = AtomicBoolean(false)
    @Volatile private var brainThread: Thread? = null

    // All ambient Android callbacks only publish latest values here. The brain thread is the
    // sole consumer and the sole caller of live-input JNI, eliminating native-mutex contention
    // from camera/audio/sensor callback threads.
    private val liveInputs = LatestLiveInputMailbox()
    private val pendingCommands = ConcurrentLinkedQueue<(Long) -> Unit>()
    private var drainHandle: Long = 0
    private val liveInputConsumer = object : LatestLiveInputMailbox.Consumer {
        override fun onCameraFrame() { NativeBrain.nativeNoteCameraFrame(drainHandle) }
        override fun onSensor(sample: LatestLiveInputMailbox.SensorSample) {
            NativeBrain.nativeSensor(drainHandle, sample.type, sample.x, sample.y, sample.z)
        }
        override fun onTouch(sample: LatestLiveInputMailbox.TouchSample) {
            NativeBrain.nativeTouch(drainHandle, sample.x, sample.y, sample.pressure)
        }
        override fun onLocation(sample: LatestLiveInputMailbox.LocationSample) {
            NativeBrain.nativeLocation(drainHandle, sample.lat, sample.lon, sample.speed, sample.bearing)
        }
        override fun onVision(sample: LatestLiveInputMailbox.VisionSample) {
            NativeBrain.nativeVision(drainHandle, sample.pixels, sample.width, sample.height)
        }
        override fun onAudio(sample: LatestLiveInputMailbox.AudioSample) {
            NativeBrain.nativeAudio(drainHandle, sample.pcm, sample.sampleRate)
        }
        override fun onToken(sample: LatestLiveInputMailbox.TokenSample) {
            NativeBrain.nativeToken(drainHandle, sample.channel, sample.data)
        }
    }

    @Volatile private var handle: Long = 0
    @Volatile private var thermalStatus: Int = PowerManager.THERMAL_STATUS_NONE
    private var nativeSteps = 0L
    private var currentStateKey: String? = null
    private val store = BrainStateStore(context)
    private val _state = MutableStateFlow(BrainUiState())
    val state: StateFlow<BrainUiState> = _state.asStateFlow()
    private val _trace = MutableStateFlow(NeuralTrace())
    val trace: StateFlow<NeuralTrace> = _trace.asStateFlow()
    @Volatile private var traceEnabled = false
    @Volatile private var traceHistoryBack = 0
    @Volatile private var desiredMode = BrainMode.Observe

    fun initialize(seed: Long = 261_711L) {
        if (handle != 0L || !_state.value.calibrating) return
        controlExecutor.execute {
            try {
                val am = context.getSystemService(ActivityManager::class.java)
                val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
                // Native allocations are outside the Java heap; still keep a conservative OS margin.
                val budget = min((mi.availMem * 0.25).toLong(), 1_800_000_000L).coerceAtLeast(128_000_000L)
                val rec = parseRecommendation(NativeBrain.nativeCalibrate(budget))
                _state.value = _state.value.copy(recommendation = rec)
                rebuildBlocking(ScaleProfile.Verified, seed)
            } catch (t: Throwable) {
                Log.e("WholeBrain", "initialize", t)
                _state.value = _state.value.copy(calibrating = false, error = t.message ?: t.javaClass.simpleName)
            }
        }
    }

    fun rebuild(profile: ScaleProfile, seed: Long = 261_711L) {
        _state.value = _state.value.copy(calibrating = true)
        controlExecutor.execute { rebuildBlocking(profile, seed) }
    }

    private fun quiesceLiveInputs() {
        liveInputs.clear()
        pendingCommands.clear()
    }

    private fun requestStopLoop() {
        loopRunning.set(false)
        brainThread?.let(LockSupport::unpark)
    }

    private fun stopLoopBlocking() {
        requestStopLoop()
        val t = brainThread
        if (t != null && t !== Thread.currentThread()) {
            t.join(2_000)
            if (t.isAlive) {
                // Never destroy an engine while nativeStep could still be using it.
                throw IllegalStateException("Brain thread did not quiesce within 2 s")
            }
        }
        brainThread = null
    }

    @Synchronized private fun rebuildBlocking(profile: ScaleProfile, seed: Long = 261_711L) {
        stopLoopBlocking()
        val old = handle
        handle = 0
        quiesceLiveInputs()
        if (old != 0L) {
            currentStateKey?.let { key -> runCatching { store.save(key, NativeBrain.nativeSave(old)) } }
            NativeBrain.nativeDestroy(old)
        }
        val rec = _state.value.recommendation
        val pair = when (profile) {
            ScaleProfile.Verified -> 250_000L to 256
            ScaleProfile.Balanced -> rec.balancedNeurons.coerceAtMost(2_500_000L).coerceAtLeast(250_000L) to rec.balancedFanout
            ScaleProfile.Max -> rec.maxNeurons.coerceAtLeast(250_000L) to rec.maxFanout
        }
        try {
            val created = NativeBrain.nativeCreate(pair.first, pair.second, seed)
            nativeSteps = 0
            currentStateKey = "v3_n${pair.first}_k${pair.second}_s$seed"
            currentStateKey?.let { key -> store.load(key)?.let { NativeBrain.nativeRestore(created, it) } }
            NativeBrain.nativeSetMode(created, desiredMode.nativeValue)
            NativeBrain.nativeSetTraceEnabled(created, traceEnabled)
            handle = created
            _state.value = _state.value.copy(running = true, calibrating = false, profile = profile, error = null)
            startLoop()
        } catch (t: Throwable) {
            handle = 0
            _state.value = _state.value.copy(running = false, calibrating = false, error = "Allocation/build failed: ${t.message}")
        }
    }

    private fun startLoop() {
        if (handle == 0L || loopRunning.getAndSet(true)) return
        val t = Thread({ runBrainLoop() }, "WholeBrain-Step").apply {
            isDaemon = true
            priority = Thread.NORM_PRIORITY
        }
        brainThread = t
        t.start()
    }

    private fun drainPendingCommands(h: Long) {
        var n = 0
        while (n < 32) {
            val command = pendingCommands.poll() ?: break
            command(h)
            n++
        }
    }

    private fun drainLatestLiveInputs(h: Long) {
        drainHandle = h
        try { liveInputs.drain(liveInputConsumer) }
        finally { drainHandle = 0 }
    }

    /**
     * Keep the brain fast when steps are cheap, but reserve CPU/memory-bandwidth headroom
     * when a 250K/K256 step becomes expensive. This is wall-clock pacing only: the engine's
     * internal biological timestep and all synaptic dynamics remain unchanged.
     */
    private fun adaptiveCooldownNs(stepMs: Double): Long = BrainPacingPolicy.cooldownNs(
        stepMs = stepMs,
        thermalStatus = thermalStatus,
        severeStatus = PowerManager.THERMAL_STATUS_SEVERE,
        criticalStatus = PowerManager.THERMAL_STATUS_CRITICAL
    )

    private fun runBrainLoop() {
        // Slightly lower priority than Android's main/UI thread. On high-end phones such as
        // the Galaxy S25 this still drives the native core hard while preventing a sustained
        // memory-bandwidth-heavy step from starving touch/composition/input dispatch.
        runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT + 2) }
        var lastUiNs = 0L
        var lastTraceNs = 0L
        var measuredStepMs = 10.0
        try {
            while (loopRunning.get()) {
                val h = handle
                if (h == 0L) break

                drainPendingCommands(h)
                drainLatestLiveInputs(h)

                val started = SystemClock.elapsedRealtimeNanos()
                NativeBrain.nativeStep(h)
                val finished = SystemClock.elapsedRealtimeNanos()
                measuredStepMs = ((finished - started).coerceAtLeast(1L)).toDouble() / 1_000_000.0
                nativeSteps++

                if (finished - lastUiNs >= UI_STATS_INTERVAL_NS) {
                    val stats = parseStats(NativeBrain.nativeStats(h))
                    _state.value = _state.value.copy(stats = stats, thermalStatus = thermalStatus, running = true)
                    lastUiNs = finished

                    if (traceEnabled && finished - lastTraceNs >= TRACE_INTERVAL_NS) {
                        val parsed = parseTrace(NativeBrain.nativeTraceFrame(h, traceHistoryBack), traceHistoryBack)
                        if (parsed.totalNeurons > 0) _trace.value = parsed
                        lastTraceNs = finished
                    }
                }

                LockSupport.parkNanos(adaptiveCooldownNs(measuredStepMs))
            }
        } catch (t: Throwable) {
            Log.e("WholeBrain", "brain loop", t)
            _state.value = _state.value.copy(error = t.message ?: "Native step failed", running = false)
        } finally {
            loopRunning.set(false)
        }
    }

    fun shutdown() {
        requestStopLoop()
        val h = handle
        handle = 0
        quiesceLiveInputs()
        controlExecutor.execute {
            runCatching { stopLoopBlocking() }
            if (h != 0L) {
                currentStateKey?.let { key -> runCatching { store.save(key, NativeBrain.nativeSave(h)) } }
                NativeBrain.nativeDestroy(h)
            }
        }
    }

    fun saveNow(): Boolean = withHandle(false) { h -> currentStateKey?.let { store.save(it, NativeBrain.nativeSave(h)); true } ?: false }
    fun saveAsync() { controlExecutor.execute { saveNow() } }
    fun loadNow(): Boolean = withHandle(false) { h -> currentStateKey?.let { key -> store.load(key)?.let { NativeBrain.nativeRestore(h, it) } } ?: false }
    fun loadAsync() { controlExecutor.execute { loadNow() } }

    private fun postBrainCommand(block: (Long) -> Unit) {
        if (handle == 0L) return
        pendingCommands.offer(block)
        brainThread?.let(LockSupport::unpark)
    }

    fun setMode(mode: BrainMode) {
        desiredMode = mode
        _state.value = _state.value.copy(stats = _state.value.stats.copy(mode = mode))
        postBrainCommand { NativeBrain.nativeSetMode(it, mode.nativeValue) }
    }
    fun reward(positive: Boolean) = postBrainCommand { NativeBrain.nativeReward(it, positive) }

    fun setTraceEnabled(enabled: Boolean) {
        traceEnabled = enabled
        traceHistoryBack = 0
        if (!enabled) _trace.value = NeuralTrace()
        postBrainCommand { NativeBrain.nativeSetTraceEnabled(it, enabled) }
    }

    fun setTraceHistoryBack(back: Int) {
        traceHistoryBack = back.coerceAtLeast(0)
        brainThread?.let(LockSupport::unpark)
    }

    fun setSensorMode(mode: SensorMode) {
        _state.value = _state.value.copy(sensorMode = mode)
        liveInputs.clear()
        postBrainCommand { NativeBrain.nativeResetDiagnostics(it) }
    }

    fun noteCameraFrame() = liveInputs.offerCameraFrame()

    fun injectSensor(type: Int, x: Float, y: Float, z: Float) {
        val mode = _state.value.sensorMode
        val allowed = mode == SensorMode.AllSensors ||
            (mode == SensorMode.ImuOnly && isImuType(type)) ||
            (mode == SensorMode.EnvironmentOnly && !isImuType(type))
        if (allowed) liveInputs.offerSensor(type, x, y, z)
    }

    fun injectTouch(x: Float, y: Float, pressure: Float) {
        val mode = _state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.TouchOnly) liveInputs.offerTouch(x, y, pressure)
    }

    fun injectLocation(lat: Double, lon: Double, speed: Float, bearing: Float) {
        val mode = _state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.LocationOnly) liveInputs.offerLocation(lat, lon, speed, bearing)
    }

    fun injectVision(pixels: ByteArray, w: Int, h: Int) {
        val mode = _state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.VisionOnly) liveInputs.offerVision(pixels, w, h)
    }

    fun injectAudio(pcm: ShortArray, sampleRate: Int) {
        val mode = _state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.AudioOnly) liveInputs.offerAudio(pcm, sampleRate)
    }

    // Explicit teaching streams bypass the latest-value mailbox: teaching must be lossless.
    fun injectTeachingAudio(pcm: ShortArray, sampleRate: Int) {
        if (pcm.isNotEmpty()) withHandle(Unit) { NativeBrain.nativeAudio(it, pcm, sampleRate) }
    }

    fun injectTeachingToken(bytes: ByteArray) {
        if (bytes.isNotEmpty()) withHandle(Unit) { NativeBrain.nativeToken(it, 9, bytes) }
    }

    fun injectToken(channel: Int, bytes: ByteArray) {
        val mode = _state.value.sensorMode
        if (channel == 9) {
            withHandle(Unit) { NativeBrain.nativeToken(it, channel, bytes) }
        } else if (mode == SensorMode.AllSensors || mode == SensorMode.ExternalOnly) {
            liveInputs.offerToken(channel, bytes)
        }
    }

    private fun normalizeSpeechKey(text: String): String = text
        .trim()
        .lowercase(Locale.ROOT)
        .replace(Regex("\\s+"), " ")
        .take(500)

    fun learnSpeechUnit(text: String, pcm: ShortArray, sampleRate: Int): Boolean {
        val key = normalizeSpeechKey(text)
        if (key.isBlank() || pcm.isEmpty()) return false
        val ok = withHandle(false) { NativeBrain.nativeLearnSpeech(it, key.toByteArray(Charsets.UTF_8), pcm, sampleRate) }
        if (ok) saveAsync()
        return ok
    }

    fun renderSpeechUnit(text: String): ShortArray {
        val key = normalizeSpeechKey(text)
        if (key.isBlank()) return ShortArray(0)
        return withHandle(ShortArray(0)) { NativeBrain.nativeRenderSpeech(it, key.toByteArray(Charsets.UTF_8)) }
    }

    fun learnGenerativeSpeech(plan: ByteArray, pcm: ShortArray, sampleRate: Int): Boolean {
        if (plan.isEmpty() || pcm.isEmpty()) return false
        val ok = withHandle(false) { NativeBrain.nativeLearnGenerativeSpeech(it, plan, pcm, sampleRate) }
        if (ok) saveAsync()
        return ok
    }

    fun renderGenerativeSpeech(plan: ByteArray): ShortArray {
        if (plan.isEmpty()) return ShortArray(0)
        return withHandle(ShortArray(0)) { NativeBrain.nativeRenderGenerativeSpeech(it, plan) }
    }

    fun learnBioSpeech(plan: ByteArray, pcm: ShortArray, sampleRate: Int): Boolean {
        if (plan.isEmpty() || pcm.isEmpty()) return false
        val ok = withHandle(false) { NativeBrain.nativeLearnBioSpeech(it, plan, pcm, sampleRate) }
        if (ok) saveAsync()
        return ok
    }

    fun renderBioSpeech(plan: ByteArray): ShortArray {
        if (plan.isEmpty()) return ShortArray(0)
        return withHandle(ShortArray(0)) { NativeBrain.nativeRenderBioSpeech(it, plan) }
    }

    fun hasBioSpeechPrimitive(unitKey: String): Boolean {
        if (unitKey.isBlank()) return false
        return withHandle(false) { NativeBrain.nativeHasBioSpeechPrimitive(it, unitKey.toByteArray(Charsets.US_ASCII)) }
    }

    fun learnedBioSpeechPrimitives(): Int = withHandle(0) { NativeBrain.nativeLearnedBioSpeechPrimitives(it) }

    fun setBioSpeechPerturbation(auditoryF1ShiftHz: Float, auditoryF2ShiftHz: Float, jawOffset: Float) =
        withHandle(Unit) { NativeBrain.nativeSetBioSpeechPerturbation(it, auditoryF1ShiftHz, auditoryF2ShiftHz, jawOffset) }

    fun setBioSpeechLesionMask(mask: Int) = withHandle(Unit) { NativeBrain.nativeSetBioSpeechLesionMask(it, mask) }

    fun hasSpeechPrimitive(unitKey: String): Boolean {
        if (unitKey.isBlank()) return false
        return withHandle(false) { NativeBrain.nativeHasSpeechPrimitive(it, unitKey.toByteArray(Charsets.US_ASCII)) }
    }

    fun learnedSpeechPrimitives(): Int = withHandle(0) { NativeBrain.nativeLearnedSpeechPrimitives(it) }

    fun clearSpeechMemory() {
        withHandle(Unit) { NativeBrain.nativeClearSpeech(it) }
        saveAsync()
    }

    fun learnedSpeechUnits(): Int = withHandle(0) { NativeBrain.nativeLearnedSpeechUnits(it) }
    fun setThermalStatus(status: Int) { thermalStatus = status }
    fun thermalStatus(): Int = thermalStatus

    private fun isImuType(type: Int): Boolean = when(type) {
        Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_MAGNETIC_FIELD, Sensor.TYPE_GYROSCOPE,
        Sensor.TYPE_GRAVITY, Sensor.TYPE_LINEAR_ACCELERATION, Sensor.TYPE_ROTATION_VECTOR,
        Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED, Sensor.TYPE_GAME_ROTATION_VECTOR,
        Sensor.TYPE_GYROSCOPE_UNCALIBRATED, Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR,
        3, 27, 28, 35, 37, 38, 39, 40, 41, 42 -> true
        else -> false
    }

    private inline fun <T> withHandle(default: T, block: (Long)->T): T { val h=handle; return if(h==0L) default else block(h) }

    private fun parseTrace(data: IntArray, historyBack: Int): NeuralTrace {
        if (data.size < 7 || data[0] != 1) return NeuralTrace(historyBack = historyBack)
        val tick = (data[1].toLong() and 0xffffffffL) or ((data[2].toLong() and 0xffffffffL) shl 32)
        val neuronCount = data[3].coerceAtLeast(0)
        val edgeCount = data[4].coerceAtLeast(0)
        val totalNeurons = data[5].coerceAtLeast(0)
        val historyDepth = data[6].coerceAtLeast(0)
        val expected = 7L + neuronCount.toLong() + edgeCount.toLong() * 4L
        if (expected > data.size.toLong()) return NeuralTrace(historyBack = historyBack)
        var off = 7
        val fired = ArrayList<Int>(neuronCount)
        repeat(neuronCount) { fired += data[off++] }
        val edges = ArrayList<NeuralEdge>(edgeCount)
        repeat(edgeCount) {
            val src = data[off++]
            val dst = data[off++]
            val delay = data[off++]
            val sign = data[off++]
            edges += NeuralEdge(src, dst, delay, sign >= 0)
        }
        return NeuralTrace(tick, totalNeurons, fired, edges, historyDepth, historyBack)
    }

    private fun parseRecommendation(json: String): ScaleRecommendation = JSONObject(json).run {
        ScaleRecommendation(
            optLong("balancedNeurons",250_000), optInt("balancedFanout",1024),
            optLong("maxNeurons",250_000), optInt("maxFanout",1024),
            optLong("logicalConnectionsBalanced",0), optLong("logicalConnectionsMax",0),
            optDouble("edgeHashPerSecond",0.0), optLong("memoryBudgetBytes",0)
        )
    }

    private fun parseStats(json: String): BrainStats = JSONObject(json).run {
        BrainStats(
            neurons=optLong("neurons"), logicalSynapses=optLong("logicalSynapses"), tick=optLong("tick"),
            spikesTotal=optLong("spikesTotal"), edgeEventsTotal=optLong("edgeEventsTotal"),
            spikesLastStep=optInt("spikesLastStep"), queuedEvents=optLong("queuedEvents"),
            lastStepMs=optDouble("lastStepMs"), spikesPerSecond=optDouble("spikesPerSecond"),
            edgesPerSecond=optDouble("edgesPerSecond"), stepHz=optDouble("stepHz"),
            regionSpikesPerSecond=optJSONArray("regionSpikesPerSecond")?.let { a -> List(15){ i -> a.optDouble(i,0.0) } } ?: List(15){0.0},
            cameraFramesPerSecond=optDouble("cameraFramesPerSecond"), visionFramesPerSecond=optDouble("visionFramesPerSecond"),
            visionFeaturesPerSecond=optDouble("visionFeaturesPerSecond"), visionInjectionsPerSecond=optDouble("visionInjectionsPerSecond"),
            audioChunksPerSecond=optDouble("audioChunksPerSecond"), audioBandsPerSecond=optDouble("audioBandsPerSecond"),
            audioInjectionsPerSecond=optDouble("audioInjectionsPerSecond"),
            touchEventsPerSecond=optDouble("touchEventsPerSecond"), touchInjectionsPerSecond=optDouble("touchInjectionsPerSecond"),
            imuEventsPerSecond=optDouble("imuEventsPerSecond"), imuChangesPerSecond=optDouble("imuChangesPerSecond"),
            imuInjectionsPerSecond=optDouble("imuInjectionsPerSecond"),
            environmentEventsPerSecond=optDouble("environmentEventsPerSecond"), environmentChangesPerSecond=optDouble("environmentChangesPerSecond"),
            environmentInjectionsPerSecond=optDouble("environmentInjectionsPerSecond"),
            locationEventsPerSecond=optDouble("locationEventsPerSecond"), locationInjectionsPerSecond=optDouble("locationInjectionsPerSecond"),
            externalTokensPerSecond=optDouble("externalTokensPerSecond"), externalInjectionsPerSecond=optDouble("externalInjectionsPerSecond"),
            currentAction=optInt("currentAction",-1), actionEpoch=optLong("actionEpoch",0), motorMargin=optDouble("motorMargin"),
            reinforcedEpisodes=optLong("reinforcedEpisodes"),
            learnedSpeechUnits=optInt("learnedSpeechUnits"),
            learnedSpeechPrimitives=optInt("learnedSpeechPrimitives"),
            learnedSpeechTransitions=optInt("learnedSpeechTransitions"),
            speechMemoryBytes=optLong("speechMemoryBytes"),
            speechRenderCount=optLong("speechRenderCount"), generatedSpeechCount=optLong("generatedSpeechCount"),
            learnedBioSpeechPrimitives=optInt("learnedBioSpeechPrimitives"),
            learnedBioSpeechTransitions=optInt("learnedBioSpeechTransitions"),
            bioSpeechMemoryBytes=optLong("bioSpeechMemoryBytes"),
            bioSpeechRenderCount=optLong("bioSpeechRenderCount"),
            bioSpeechAuditoryErrorBefore=optDouble("bioSpeechAuditoryErrorBefore"),
            bioSpeechAuditoryErrorAfter=optDouble("bioSpeechAuditoryErrorAfter"),
            bioSpeechSomatosensoryError=optDouble("bioSpeechSomatosensoryError"),
            bioSpeechCompensation=optDouble("bioSpeechCompensation"),
            bioSpeechLesionMask=optInt("bioSpeechLesionMask"),
            memoryBytes=optLong("memoryBytes"),
            motorDifferential=optDouble("motorDifferential",0.0),
            mode=BrainMode.entries.getOrElse(optInt("mode",0)){ BrainMode.Observe }
        )
    }
}
