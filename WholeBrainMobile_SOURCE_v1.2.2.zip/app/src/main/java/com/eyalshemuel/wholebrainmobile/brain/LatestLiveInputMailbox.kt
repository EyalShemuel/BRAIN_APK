package com.eyalshemuel.wholebrainmobile.brain

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Lock-free-ish latest-value mailbox for live Android sensors.
 *
 * Producers never enter the native brain and therefore never wait for its mutex. Each
 * modality keeps only the newest not-yet-consumed sample. If producers outrun the brain,
 * obsolete samples are replaced instead of accumulating latency and allocations in a FIFO.
 * Explicit teaching paths intentionally bypass this mailbox because they must be lossless.
 */
internal class LatestLiveInputMailbox {
    data class SensorSample(val type: Int, val x: Float, val y: Float, val z: Float)
    data class TouchSample(val x: Float, val y: Float, val pressure: Float)
    data class LocationSample(val lat: Double, val lon: Double, val speed: Float, val bearing: Float)
    data class VisionSample(val pixels: ByteArray, val width: Int, val height: Int)
    data class AudioSample(val pcm: ShortArray, val sampleRate: Int)
    data class TokenSample(val channel: Int, val data: ByteArray)

    interface Consumer {
        fun onCameraFrame()
        fun onSensor(sample: SensorSample)
        fun onTouch(sample: TouchSample)
        fun onLocation(sample: LocationSample)
        fun onVision(sample: VisionSample)
        fun onAudio(sample: AudioSample)
        fun onToken(sample: TokenSample)
    }

    private val cameraFrame = AtomicBoolean(false)
    private val sensors = ConcurrentHashMap<Int, SensorSample>()
    private val touch = AtomicReference<TouchSample?>(null)
    private val location = AtomicReference<LocationSample?>(null)
    private val vision = AtomicReference<VisionSample?>(null)
    private val audio = AtomicReference<AudioSample?>(null)
    private val tokens = ConcurrentHashMap<Int, TokenSample>()

    fun offerCameraFrame() { cameraFrame.set(true) }

    fun offerSensor(type: Int, x: Float, y: Float, z: Float) {
        sensors[type] = SensorSample(type, x, y, z)
    }

    fun offerTouch(x: Float, y: Float, pressure: Float) {
        touch.set(TouchSample(x, y, pressure))
    }

    fun offerLocation(lat: Double, lon: Double, speed: Float, bearing: Float) {
        location.set(LocationSample(lat, lon, speed, bearing))
    }

    fun offerVision(pixels: ByteArray, width: Int, height: Int) {
        // Camera analyzers commonly reuse their backing array immediately after returning.
        vision.set(VisionSample(pixels.copyOf(), width, height))
    }

    fun offerAudio(pcm: ShortArray, sampleRate: Int) {
        // AudioRecord reuses its capture buffer on the next read.
        audio.set(AudioSample(pcm.copyOf(), sampleRate))
    }

    fun offerToken(channel: Int, data: ByteArray) {
        tokens[channel] = TokenSample(channel, data.copyOf())
    }

    /** Drain at most one latest sample per modality/type into the brain thread. */
    fun drain(consumer: Consumer) {
        if (cameraFrame.getAndSet(false)) consumer.onCameraFrame()

        // remove(key,value) preserves a newer concurrent replacement for the next drain.
        for ((type, sample) in sensors) {
            if (sensors.remove(type, sample)) consumer.onSensor(sample)
        }

        touch.getAndSet(null)?.let(consumer::onTouch)
        location.getAndSet(null)?.let(consumer::onLocation)
        vision.getAndSet(null)?.let(consumer::onVision)
        audio.getAndSet(null)?.let(consumer::onAudio)

        for ((channel, sample) in tokens) {
            if (tokens.remove(channel, sample)) consumer.onToken(sample)
        }
    }

    fun clear() {
        cameraFrame.set(false)
        sensors.clear()
        touch.set(null)
        location.set(null)
        vision.set(null)
        audio.set(null)
        tokens.clear()
    }
}
