# WholeBrain Mobile v1.2.2 — Galaxy S25 / Real-Time Responsiveness Fix

## למה v1.2 נתקע על המכשיר

בצילום מהמכשיר נמדדו בערך:

- 250K neurons / K256
- 151.5K spikes/s
- 37.7M edges/s
- internal event queue ≈ 533K
- step ≈ 72 ms

הבעיה העיקרית לא הייתה זיכרון RAM חלש אלא תזמון Android: צעד native ארוך תפס CPU/memory bandwidth, ובגרסאות קודמות קלט חי נמסר דרך תור עבודה נפרד שנאלץ להתחרות על אותו mutex של המוח. גם אחרי מעבר מ-fixed-rate ל-fixed-delay עדיין נשארו FIFO ו-thread contention.

## תיקון v1.2.2

### 1. Latest-value mailbox per modality

כל קלט ambient מחזיק רק את הערך האחרון שלא עובד עדיין:

- IMU / environment — לפי sensor type
- touch
- location
- vision frame
- audio chunk
- external token — לפי channel
- camera-frame marker

אם החיישן מהיר יותר מהמוח, הדגימה הישנה מוחלפת. אין הצטברות latency של דגימות שכבר אינן רלוונטיות.

קלט teaching מפורש נשאר lossless ועוקף את ה-mailbox.

### 2. JNI live-input רק מתוך brain thread

callbacks של מצלמה / audio / sensor / touch אינם קוראים יותר ל-native brain. הם רק כותבים ל-mailbox. לפני כל simulation step, brain thread יחיד מנקז את הערכים האחרונים ומזריק אותם למוח. כך UI/main thread לעולם אינו ממתין ל-native brain mutex בגלל קלט ambient.

### 3. Dedicated self-paced brain thread

אין `scheduleAtFixedRate` ואין `scheduleWithFixedDelay`.

יש thread ייעודי `WholeBrain-Step` שמריץ:

`drain commands -> drain latest senses -> nativeStep -> optional UI snapshot -> adaptive cooldown`

ה-timestep הביולוגי הפנימי של המנוע לא משתנה. משתנה רק קצב wall-clock כאשר הטלפון לא מסוגל לחשב tick בזמן אמת.

### 4. Adaptive duty cycle

ה-pacing משאיר headroom ל-Android לפי זמן הצעד בפועל:

- step < 20 ms: duty ~88%
- 20–35 ms: ~82%
- 35–60 ms: ~76%
- >= 60 ms: ~70%
- thermal severe: ~50%
- thermal critical: ~35%

במדידת S25 של 72 ms מתקבל cooldown של ~30.9 ms, כלומר המוח ממשיך לרוץ חזק אבל לא מנסה להחזיק CPU/memory bandwidth ב-100% duty.

### 5. UI snapshot 6.7 Hz

Stats נשלחים ל-Compose כל 150 ms (~6.7 Hz), ללא תלות במספר simulation steps. Neural trace מוגבל ל-250 ms. שינויי mode/sensor selection עדיין משתקפים מיד.

### 6. Android main-thread actions

`setMode`, `reward`, `setTraceEnabled` ו-reset diagnostics נשלחים כפקודות ל-brain thread. כפתור Load עבר ל-`loadAsync()`. כך פעולות UI שגרתיות לא נכנסות ישירות ל-native mutex.

## מה לא השתנה

- 250,000 neurons בפרופיל Verified
- K256
- topology / long-range mapping
- membrane / synaptic dynamics
- learned synaptic weights
- plasticity במצבי Learn/Act
- BioSpeech
- targetSdk 36
- compileSdk 37.2

## gates חדשים

- latest-value coalescing
- copy isolation ל-camera/audio buffers
- destructive drain + clear
- pacing policy עבור step מהיר / 72ms / thermal severe / critical
- source locks: אין fixed scheduler, אין FIFO 24, אין ambient JNI callback path
- Android unit tests ב-`app/src/test/...`

## נקודת אימות על S25

המדד החשוב לאחר התקנה אינו ש-Queue הפנימי יהיה אפס. זהו תור delayed synaptic events של המודל ויכול להיות גדול. המדדים שצריכים להשתפר הם:

1. UI נשאר מגיב לאורך דקות, לא שנייה אחת.
2. `Step` יכול להישאר עשרות ms, אך אינו מקפיא touch/navigation.
3. אין עלייה בלתי מוגבלת ב-latency של camera/audio/IMU — ה-mailbox מחזיק רק latest.
4. thermal throttling לא גורם catch-up storm.

## בדיקת עומס mailbox

בבדיקת JVM הוזרקו לפני drain יחיד 10,000 עדכוני accelerometer, 10,000 chunks של audio ו-10,000 camera markers (סה"כ 30,000 אירועים). ה-drain החזיר בדיוק 3 ערכים: האחרון של כל modality. זה מוכיח שה-latency של קלט ambient אינה יכולה לגדול ליניארית עם קצב ה-producer.
