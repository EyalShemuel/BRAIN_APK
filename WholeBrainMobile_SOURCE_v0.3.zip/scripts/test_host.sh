#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cmake -S "$ROOT/host-tests" -B "$ROOT/host-tests/build" -G Ninja
cmake --build "$ROOT/host-tests/build"
"$ROOT/host-tests/build/wholebrain_host_test"

# Learning smoke: the same reward loop must learn two opposite associations
# from chance-like pre-training performance to >=0.75 on three independent seeds.
for seed in 77 78 79; do
  "$ROOT/host-tests/build/learning_smoke" "$seed"
done
