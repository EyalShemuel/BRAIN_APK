#include "wholebrain_engine.h"
#include "sensor_encoders.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>

namespace {
using namespace wb;
EngineConfig isolatedCfg(uint64_t neurons=250000, uint64_t seed=31415) {
    EngineConfig c; c.neurons=neurons; c.fanout=64; c.seed=seed;
    c.excitatoryWeight=0.0f; c.inhibitoryWeight=0.0f;
    return c;
}
void clearRefractory(BrainEngine& e){ for(int i=0;i<4;++i)e.step(); }
std::vector<uint8_t> checkerboard(){
    std::vector<uint8_t> im(64*36,0);
    for(int y=0;y<36;++y)for(int x=0;x<64;++x)im[y*64+x]=((x/4+y/4)%2)?255:0;
    return im;
}
uint64_t visualStaticSpikes(uint64_t neurons){
    BrainEngine e(isolatedCfg(neurons)); clearRefractory(e); auto im=checkerboard(); e.injectVision(im,64,36); e.step();
    return e.stats().spikesTotal;
}
}

int main(){
    using namespace wb;
    const auto a=BrainEngine::deterministicTarget(123,7,10000,42);
    const auto b=BrainEngine::deterministicTarget(123,7,10000,42);
    assert(a==b && a<10000);
    assert(BrainEngine::deterministicTarget(123,8,10000,42)!=a);
    assert(std::abs(BrainEngine::core53ErrorUpdate(0.0f,3,0,0.001f) - (-0.006f)) < 1e-7f);
    assert(std::abs(BrainEngine::core53ErrorUpdate(0.0f,3,1,0.001f) - 0.006f) < 1e-7f);
    assert(BrainEngine::core53ErrorUpdate(1.999f,100,1,0.001f) == 2.0f);

    // Topographic contract: adjacent retinal/touch cells stay ordered and nearby;
    // the same normalized cell remains in approximately the same relative location at scale.
    constexpr uint32_t visual250k=24647; // 250000*35/355 floor from engine region partition
    const uint32_t c0=BrainEngine::topographicLocal(visual250k,18*64+32,64*36,4,10);
    const uint32_t c1=BrainEngine::topographicLocal(visual250k,18*64+33,64*36,4,10);
    assert(c1>=c0 && c1-c0<20);
    const uint32_t small=BrainEngine::topographicLocal(5000,1000,2304,3,10);
    const uint32_t large=BrainEngine::topographicLocal(50000,1000,2304,3,10);
    const double rs=double(small)/5000.0, rl=double(large)/50000.0;
    assert(std::abs(rs-rl)<0.0025);

    const double rate=BrainEngine::benchmarkEdgeHash(500000,1234);
    assert(rate>1e6);
    const auto rec=BrainEngine::recommendScale(512ull*1024*1024,rate,60.0,0.005);
    assert(rec.balancedNeurons>=1024 && rec.maxNeurons>=1024);
    assert(rec.logicalConnectionsBalanced==rec.balancedNeurons*rec.balancedFanout);
    assert(rec.logicalConnectionsMax==rec.maxNeurons*rec.maxFanout);

    EngineConfig idleCfg; idleCfg.neurons=5000; idleCfg.fanout=64; idleCfg.seed=99;
    BrainEngine idle(idleCfg); idle.setMode(RunMode::Act);
    for(int i=0;i<16;++i) idle.step();
    assert(idle.stats().currentAction==-1);

    // Vision v3: a static structured image must be visible (not motion-only), and scaling
    // from 20K to 250K must not dilute the direct response as v0.2 did.
    const uint64_t v20=visualStaticSpikes(20000), v250=visualStaticSpikes(250000);
    assert(v20>50 && v250>100);
    assert(v250 >= v20/2); // no 12.5x dilution with brain size

    // Strong temporal transition still produces Visual spikes.
    BrainEngine vision(isolatedCfg(50000,315)); clearRefractory(vision);
    std::vector<uint8_t> black(64*36,0), white(64*36,255);
    vision.noteCameraFrame(); vision.injectVision(black,64,36); vision.step();
    vision.noteCameraFrame(); vision.injectVision(white,64,36); vision.step();
    auto vs=vision.stats();
    assert(vs.cameraFramesPerSecond>0.0 && vs.visionFeaturesPerSecond>0.0);
    assert(vs.regionSpikesPerSecond[static_cast<size_t>(Region::Visual)]>0.0);

    // Color survives camera encoding: chroma must create explicit U/V channel features
    // even when luminance is flat.
    std::vector<uint8_t> yuv(64*36*3,128);
    for(size_t i=0;i<64u*36u;++i){ yuv[i*3]=128; yuv[i*3+1]=255; yuv[i*3+2]=128; }
    const auto chroma=wb::enc::visionFeatures(yuv,{},64,36,768);
    assert(std::any_of(chroma.begin(),chroma.end(),[](const auto& f){
        return wb::enc::visionChannel(f.key)==static_cast<uint32_t>(wb::enc::VisionChannel::ChromaUPos);
    }));

    // Auditory tonotopy: a normal 440-Hz tone must directly ignite Auditory neurons
    // without recurrent amplification.
    BrainEngine audio(isolatedCfg(250000,316)); clearRefractory(audio);
    std::vector<int16_t> tone(512), highTone(512), silence(512,0);
    for(size_t i=0;i<tone.size();++i){
        tone[i]=int16_t(12000*std::sin(2*3.141592653589793*440*i/16000.0));
        highTone[i]=int16_t(12000*std::sin(2*3.141592653589793*1760*i/16000.0));
    }
    auto loBands=wb::enc::audioBands(tone,16000,32,16);
    auto hiBands=wb::enc::audioBands(highTone,16000,32,16);
    assert(wb::enc::audioBands(silence,16000,32,16).empty());
    auto peak=[](const auto& bands){return std::max_element(bands.begin(),bands.end(),[](const auto&a,const auto&b){return a.magnitude<b.magnitude;})->key;};
    assert(!loBands.empty() && !hiBands.empty() && peak(hiBands)>peak(loBands)); // higher tone -> higher tonotopic band
    audio.injectAudio(tone,16000); audio.step();
    auto as=audio.stats();
    assert(as.audioBandsPerSecond>0.0 && as.audioInjectionsPerSecond>0.0);
    assert(as.regionSpikesPerSecond[static_cast<size_t>(Region::Auditory)]>0.0);

    // Touch somatotopy: contact, movement and release all produce S1 input.
    BrainEngine touch(isolatedCfg(250000,317)); clearRefractory(touch);
    touch.injectTouch(.25f,.50f,1.0f); touch.step();
    touch.injectTouch(.55f,.50f,1.0f); touch.step();
    touch.injectTouch(.55f,.50f,0.0f); touch.step();
    auto ts=touch.stats();
    assert(ts.touchEventsPerSecond>0.0 && ts.touchInjectionsPerSecond>0.0);
    assert(ts.regionSpikesPerSecond[static_cast<size_t>(Region::Somatosensory)]>0.0);

    // IMU: constant gravity/DC is rejected; gyro/acceleration delta uses calibrated axes.
    BrainEngine imu(isolatedCfg(250000,318)); clearRefractory(imu);
    imu.injectSensor(1,0.0f,0.0f,9.8f); imu.step();
    imu.injectSensor(1,0.0f,0.0f,9.8f); imu.step();
    assert(imu.stats().imuChangesPerSecond==0.0);
    imu.injectSensor(4,0.0f,0.0f,0.0f); imu.step();
    imu.injectSensor(4,1.0f,0.0f,0.0f); imu.step();
    auto ims=imu.stats();
    assert(ims.imuChangesPerSecond>0.0 && ims.imuInjectionsPerSecond>0.0);
    assert(ims.regionSpikesPerSecond[static_cast<size_t>(Region::Somatosensory)]>0.0);
    assert(ims.regionSpikesPerSecond[static_cast<size_t>(Region::Cerebellum)]>0.0);

    // Environmental senses use calibrated units and dedicated Thalamic/homeostatic channels.
    BrainEngine env(isolatedCfg(250000,319)); clearRefractory(env);
    env.injectSensor(5,1000.0f,0,0); env.step(); // light
    env.injectSensor(13,24.0f,0,0); env.step();  // ambient temp
    env.injectSensor(10001,0.65f,31.0f,4.05f); env.step(); // battery/internal state
    auto es=env.stats();
    assert(es.environmentEventsPerSecond>0.0 && es.environmentInjectionsPerSecond>0.0);
    assert(es.regionSpikesPerSecond[static_cast<size_t>(Region::Thalamus)]>0.0 ||
           es.regionSpikesPerSecond[static_cast<size_t>(Region::Brainstem)]>0.0);
    // Repeated stable environmental level is observed but does not become a fresh
    // current burst. After refractory clears, the second identical light sample must not
    // create any new spikes in an otherwise isolated engine.
    BrainEngine envDc(isolatedCfg(250000,3191)); clearRefractory(envDc);
    envDc.injectSensor(5,1000.0f,0,0); envDc.step(); clearRefractory(envDc);
    const auto stableBefore=envDc.stats().spikesTotal;
    envDc.injectSensor(5,1000.0f,0,0); envDc.step();
    assert(envDc.stats().spikesTotal==stableBefore);

    // GPS uses multi-scale place populations; categorical external senses use stable
    // distributed Semantic/Association populations.
    BrainEngine place(isolatedCfg(250000,320)); clearRefractory(place);
    place.injectLocation(32.03,34.88,0.0f,0.0f); place.step();
    auto ps=place.stats();
    assert(ps.locationInjectionsPerSecond>0.0);
    assert(ps.regionSpikesPerSecond[static_cast<size_t>(Region::Hippocampus)]>0.0);

    BrainEngine ext(isolatedCfg(250000,321)); clearRefractory(ext);
    const std::vector<uint8_t> tag{'N','F','C','1'};
    ext.injectToken(1,tag); ext.step();
    auto xs=ext.stats();
    assert(xs.externalTokensPerSecond>0.0 && xs.externalInjectionsPerSecond>0.0);
    assert(xs.regionSpikesPerSecond[static_cast<size_t>(Region::Semantic)]>0.0);

    // End-to-end mixed-sensor state/save regression.
    EngineConfig c; c.neurons=30000; c.fanout=64; c.seed=261711; c.learningRate=.001f;
    BrainEngine e(c); e.setMode(RunMode::Learn);
    auto frame=checkerboard();
    for(int t=0;t<80;++t){
        if(t%3==0)e.injectVision(frame,64,36);
        if(t%4==0)e.injectAudio(tone,16000);
        e.injectSensor(1,.2f*t,9.8f,.1f);
        if(t%10==0){e.injectTouch(.3f,.6f,.8f);e.injectTouch(.31f,.61f,0.0f);}
        if(t%20==0)e.injectSensor(5,500.0f+t*10.0f,0,0);
        e.step();
    }
    auto s=e.stats();
    assert(s.neurons==30000 && s.logicalSynapses==30000ull*64);
    assert(s.tick==80 && s.spikesTotal>0);
    const auto blob=e.serializePlasticity(); assert(blob.size()>32);
    BrainEngine e2(c); assert(e2.restorePlasticity(blob));
    e.reward(false);

    std::cout<<"PASS topology_adj="<<(c1-c0)<<" visual20="<<v20<<" visual250="<<v250
             <<" audio_sps="<<as.regionSpikesPerSecond[static_cast<size_t>(Region::Auditory)]
             <<" touch_sps="<<ts.regionSpikesPerSecond[static_cast<size_t>(Region::Somatosensory)]
             <<" hash_edges_s="<<rate<<" mixed_spikes="<<s.spikesTotal<<"\n";
    std::cout<<e.statsJson()<<"\n";
    std::cout<<recommendationJson(rec)<<"\n";
    return 0;
}
