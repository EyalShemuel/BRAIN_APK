package com.eyalshemuel.wholebrainmobile

import android.content.Context
import android.content.Intent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.awaitPointerEventScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.eyalshemuel.wholebrainmobile.brain.*
import com.eyalshemuel.wholebrainmobile.output.OutputRouter
import com.eyalshemuel.wholebrainmobile.sensors.CapabilityScanner
import com.eyalshemuel.wholebrainmobile.sensors.SensorHub
import java.text.DecimalFormat
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private enum class Tab(val title:String){Live("Live"),Teach("Teach"),Memory("Memory"),Brain("Brain"),Device("Device")}
private val regionNames=listOf("Visual","Auditory","Language","Somatosensory","Association","Hippocampus","PFC","Basal ganglia","Thalamus","Cerebellum","Motor","Vocal motor","Semantic","Neuromod","Brainstem")

@Composable
fun WholeBrainApp(controller:BrainController,sensorHub:SensorHub,output:OutputRouter,permissionEpoch:Int,onRequestPermissions:()->Unit){
    val ui by controller.state.collectAsStateWithLifecycle()
    var tab by remember{mutableStateOf(Tab.Live)}
    val lifecycle=LocalLifecycleOwner.current
    val context=LocalContext.current

    LaunchedEffect(ui.stats.actionEpoch,ui.stats.currentAction,ui.stats.mode){
        if(ui.stats.mode==BrainMode.Act) output.route(ui.stats.currentAction)
    }

    Scaffold(
        topBar={BrainTopBar(ui)},
        bottomBar={NavigationBar{Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Text(if(tab==t)"●" else "○")},label={Text(t.title)})}}}
    ){pad->
        Box(Modifier.padding(pad).fillMaxSize()){
            when(tab){
                Tab.Live->LiveScreen(ui,controller,sensorHub,lifecycle,permissionEpoch)
                Tab.Teach->TeachScreen(ui,controller)
                Tab.Memory->MemoryScreen(ui)
                Tab.Brain->BrainScreen(ui)
                Tab.Device->DeviceScreen(ui,controller,output,context,permissionEpoch,onRequestPermissions)
            }
        }
    }
}

@Composable private fun BrainTopBar(ui:BrainUiState){
    Surface(shadowElevation=2.dp){
        Row(
            Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars).padding(horizontal=16.dp,vertical=10.dp),
            verticalAlignment=Alignment.CenterVertically
        ){
            Column(Modifier.weight(1f)){
                Text("WholeBrain Mobile",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.SemiBold)
                Text(statusText(ui),style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)
            }
            AssistChip(onClick={},label={Text(if(ui.running)ui.stats.mode.name.uppercase() else "OFFLINE")})
        }
    }
}

private fun statusText(ui:BrainUiState)=when{
    ui.calibrating->"Calibrating this device"
    ui.error!=null->ui.error
    ui.thermalStatus>=3->"Local • thermal protection"
    ui.running->{
        val k=if(ui.stats.neurons>0)ui.stats.logicalSynapses/ui.stats.neurons else 0
        "Local • Engine OK • ${fmt(ui.stats.neurons)} • K$k"
    }
    else->"Stopped"
}

@Composable private fun LiveScreen(ui:BrainUiState,controller:BrainController,sensors:SensorHub,lifecycle:androidx.lifecycle.LifecycleOwner,permissionEpoch:Int){
    var size by remember{mutableStateOf(IntSize.Zero)}
    LazyColumn(
        Modifier.fillMaxSize().onSizeChanged{size=it}.pointerInput(size,ui.sensorMode){
            awaitPointerEventScope{
                while(true){
                    val e=awaitPointerEvent(PointerEventPass.Initial)
                    e.changes.forEach{c->
                        if(size.width>0&&size.height>0){
                            controller.injectTouch(c.position.x/size.width,c.position.y/size.height,if(c.pressed)c.pressure.coerceIn(0.05f,1f) else 0f)
                        }
                    }
                }
            }
        },
        contentPadding=PaddingValues(16.dp),
        verticalArrangement=Arrangement.spacedBy(12.dp)
    ){
        item{InputIsolation(ui.sensorMode,controller)}
        item{BrainOrb(ui.stats)}
        item{MetricsGrid(ui.stats)}
        item{SensorDiagnostics(ui.stats)}
        item{SectionTitle("Vision")}
        item{
            key(permissionEpoch){
                AndroidView(
                    factory={ctx->PreviewView(ctx).apply{scaleType=PreviewView.ScaleType.FILL_CENTER;sensors.bindCamera(lifecycle,this)}},
                    modifier=Modifier.fillMaxWidth().height(190.dp).background(MaterialTheme.colorScheme.surfaceVariant,RoundedCornerShape(20.dp))
                )
            }
        }
        item{Text("Validation mode isolates which inputs may reach the brain. Vision is retinotopic, audio tonotopic, touch somatotopic, IMU axis/polarity mapped, and GPS uses multi-scale place codes. All processing stays local.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
    }
}

@Composable private fun InputIsolation(mode:SensorMode,controller:BrainController){
    Card(Modifier.fillMaxWidth()){
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Device Validation v3",fontWeight=FontWeight.Bold)
            Text("Input isolation — every physical modality now has its own stable map",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
            listOf(
                listOf(SensorMode.VisionOnly,SensorMode.AudioOnly),
                listOf(SensorMode.TouchOnly,SensorMode.ImuOnly),
                listOf(SensorMode.EnvironmentOnly,SensorMode.LocationOnly),
                listOf(SensorMode.ExternalOnly,SensorMode.AllSensors)
            ).forEach{row->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    row.forEach{m->FilterChip(selected=mode==m,onClick={controller.setSensorMode(m)},label={Text(m.label)},modifier=Modifier.weight(1f))}
                }
            }
        }
    }
}

@Composable private fun BrainOrb(stats:BrainStats){
    val p=MaterialTheme.colorScheme.primary
    val s=MaterialTheme.colorScheme.secondary
    val bg=MaterialTheme.colorScheme.surfaceVariant
    val maxRate=(stats.regionSpikesPerSecond.maxOrNull()?:0.0).coerceAtLeast(1.0)
    Card(Modifier.fillMaxWidth()){
        Column(Modifier.padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Canvas(Modifier.size(210.dp)){
                drawCircle(bg)
                val c=center
                val r=size.minDimension*.34f
                for(i in 0 until 15){
                    val a=2*PI*i/15.0
                    val pos=Offset(c.x+(cos(a)*r).toFloat(),c.y+(sin(a)*r).toFloat())
                    val rate=stats.regionSpikesPerSecond.getOrElse(i){0.0}
                    val active=sqrt((rate/maxRate).coerceIn(0.0,1.0)).toFloat()
                    drawCircle(if(i%2==0)p else s,radius=5f+13f*active,center=pos,alpha=.18f+.82f*active)
                }
                drawCircle(p,radius=32f,center=c,alpha=.16f)
                drawCircle(p,radius=8f,center=c,alpha=if(stats.spikesLastStep>0).9f else .25f)
            }
            Text(if(stats.currentAction<0)"REGIONAL ACTIVITY" else "ACTION ${stats.currentAction+1}",fontWeight=FontWeight.Bold)
            Text("${fmt(stats.spikesPerSecond)}/s spikes • ${fmt(stats.edgesPerSecond)}/s actual recurrent edges",style=MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable private fun MetricsGrid(s:BrainStats){
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Metric("Neurons",fmt(s.neurons),Modifier.weight(1f))
            Metric("Logical synapses",fmt(s.logicalSynapses),Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Metric("Step",if(s.lastStepMs>0)"${df1.format(s.lastStepMs)} ms" else "—",Modifier.weight(1f))
            Metric("Queued events",fmt(s.queuedEvents),Modifier.weight(1f))
        }
    }
}

@Composable private fun SensorDiagnostics(s:BrainStats){
    val visual=s.regionSpikesPerSecond.getOrElse(0){0.0}
    val auditory=s.regionSpikesPerSecond.getOrElse(1){0.0}
    val somato=s.regionSpikesPerSecond.getOrElse(3){0.0}
    val assoc=s.regionSpikesPerSecond.getOrElse(4){0.0}
    val hippoc=s.regionSpikesPerSecond.getOrElse(5){0.0}
    val pfc=s.regionSpikesPerSecond.getOrElse(6){0.0}
    val thalamus=s.regionSpikesPerSecond.getOrElse(8){0.0}
    val cerebellum=s.regionSpikesPerSecond.getOrElse(9){0.0}
    val motor=s.regionSpikesPerSecond.getOrElse(10){0.0}
    val semantic=s.regionSpikesPerSecond.getOrElse(12){0.0}
    val brainstem=s.regionSpikesPerSecond.getOrElse(14){0.0}
    Card(Modifier.fillMaxWidth()){
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Text("Live sensory topology diagnostics",fontWeight=FontWeight.Bold)
            DiagnosticRow("Vision","camera ${fmt(s.cameraFramesPerSecond)}/s • retinal frames ${fmt(s.visionFramesPerSecond)}/s","features ${fmt(s.visionFeaturesPerSecond)}/s • inject ${fmt(s.visionInjectionsPerSecond)}/s • Visual ${fmt(visual)}/s")
            HorizontalDivider()
            DiagnosticRow("Audio","chunks ${fmt(s.audioChunksPerSecond)}/s • active bands ${fmt(s.audioBandsPerSecond)}/s","tonotopic inject ${fmt(s.audioInjectionsPerSecond)}/s • Auditory ${fmt(auditory)}/s")
            HorizontalDivider()
            DiagnosticRow("Touch","events ${fmt(s.touchEventsPerSecond)}/s • somatotopic inject ${fmt(s.touchInjectionsPerSecond)}/s","Somatosensory ${fmt(somato)}/s")
            HorizontalDivider()
            DiagnosticRow("IMU / gyro","events ${fmt(s.imuEventsPerSecond)}/s • meaningful Δ ${fmt(s.imuChangesPerSecond)}/s","inject ${fmt(s.imuInjectionsPerSecond)}/s • S1 ${fmt(somato)}/s • Cerebellum ${fmt(cerebellum)}/s")
            HorizontalDivider()
            DiagnosticRow("Environment","events ${fmt(s.environmentEventsPerSecond)}/s • changes ${fmt(s.environmentChangesPerSecond)}/s","inject ${fmt(s.environmentInjectionsPerSecond)}/s • Thalamus ${fmt(thalamus)}/s • Brainstem ${fmt(brainstem)}/s")
            HorizontalDivider()
            DiagnosticRow("GPS / place","updates ${fmt(s.locationEventsPerSecond)}/s • inject ${fmt(s.locationInjectionsPerSecond)}/s","Hippocampus ${fmt(hippoc)}/s")
            HorizontalDivider()
            DiagnosticRow("External","tokens ${fmt(s.externalTokensPerSecond)}/s • inject ${fmt(s.externalInjectionsPerSecond)}/s","Semantic ${fmt(semantic)}/s • Association ${fmt(assoc)}/s")
            HorizontalDivider()
            DiagnosticRow("Propagation","Association ${fmt(assoc)}/s • PFC ${fmt(pfc)}/s","Motor ${fmt(motor)}/s • total ${fmt(s.spikesPerSecond)}/s")
        }
    }
}

@Composable private fun DiagnosticRow(title:String,line1:String,line2:String){
    Column(verticalArrangement=Arrangement.spacedBy(2.dp)){
        Text(title,fontWeight=FontWeight.SemiBold)
        Text(line1,style=MaterialTheme.typography.bodySmall)
        Text(line2,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun Metric(label:String,value:String,modifier:Modifier=Modifier){
    Card(modifier){Column(Modifier.padding(12.dp)){Text(value,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
}

@Composable private fun TeachScreen(ui:BrainUiState,controller:BrainController){
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        SectionTitle("Mode")
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){BrainMode.entries.forEach{m->FilterChip(selected=ui.stats.mode==m,onClick={controller.setMode(m)},label={Text(m.name)})}}
        Card{Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("Last motor decision",style=MaterialTheme.typography.labelLarge)
            Text(if(ui.stats.currentAction<0)"No action yet" else "Action ${ui.stats.currentAction+1}",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            Text("Teach with consequence, not a hidden label. A negative reward applies the validated opponent push–pull correction to the Association→Motor trace.",style=MaterialTheme.typography.bodyMedium)
        }}
        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
            Button(onClick={controller.reward(true)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(18.dp)){Text("✓ Good")}
            Button(onClick={controller.reward(false)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(18.dp),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text("✕ Wrong")}
        }
        Text("Learning only changes the explicit plastic output organ. The recurrent procedural substrate remains fixed in v0.3, matching the validated scientific boundary.",style=MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun MemoryScreen(ui:BrainUiState){
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{SectionTitle("Plastic state")}
        item{Metric("Reinforced error episodes",ui.stats.reinforcedEpisodes.toString(),Modifier.fillMaxWidth())}
        item{Metric("Differential output magnitude",df3.format(ui.stats.motorDifferential),Modifier.fillMaxWidth())}
        item{Card{Column(Modifier.padding(16.dp)){Text("What this means",fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text("This is not a claim of ${ui.stats.reinforcedEpisodes} independent memories. The app reports actual plastic updates separately from representational capacity so that learning success is not confused with a capacity measurement.")}}}
    }
}

@Composable private fun BrainScreen(ui:BrainUiState){
    val k=if(ui.stats.neurons>0)ui.stats.logicalSynapses/ui.stats.neurons else 0
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{SectionTitle("Substrate")}
        item{Text("${fmt(ui.stats.neurons)} neurons • K=$k • ${fmt(ui.stats.logicalSynapses)} logical connections")}
        item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            Text("Scientific boundary",fontWeight=FontWeight.Bold)
            Text("Validated mechanism: K6",color=MaterialTheme.colorScheme.primary)
            Text("Current runtime scale: K$k • experimental until parity/capacity validation",style=MaterialTheme.typography.bodySmall)
        }}}
        item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            val visualN=ui.stats.neurons*35/355
            val auditoryN=ui.stats.neurons*24/355
            val somatoN=ui.stats.neurons*18/355
            Text("Sensory topology v3",fontWeight=FontWeight.Bold)
            Text("Vision: 64×36 retinal cells • ~${df1.format(visualN/2304.0)} neurons/cell • 10 roles",style=MaterialTheme.typography.bodySmall)
            Text("Audio: 32 ordered frequency bands • ~${df1.format(auditoryN/32.0)} neurons/band",style=MaterialTheme.typography.bodySmall)
            Text("Touch: 32×18 somatotopic cells • ~${df1.format(somatoN/576.0)} neurons/cell",style=MaterialTheme.typography.bodySmall)
            Text("IMU: calibrated sensor/axis/polarity channels • environment: calibrated level/change channels",style=MaterialTheme.typography.bodySmall)
        }}}
        itemsIndexed(regionNames){i,r->
            val rate=ui.stats.regionSpikesPerSecond.getOrElse(i){0.0}
            Card(Modifier.fillMaxWidth()){
                Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){
                    Box(Modifier.size(9.dp).background(if(rate>0)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,RoundedCornerShape(50)))
                    Spacer(Modifier.width(10.dp))
                    Text(r,Modifier.weight(1f))
                    Text("${fmt(rate)}/s",style=MaterialTheme.typography.labelMedium)
                }
            }
        }
        item{Text("The Live orbit now reflects measured spikes from each region; it is no longer a decorative spike-count animation.",style=MaterialTheme.typography.bodySmall)}
    }
}

@Composable private fun DeviceScreen(ui:BrainUiState,controller:BrainController,output:OutputRouter,context:Context,permissionEpoch:Int,onRequestPermissions:()->Unit){
    val caps=remember(permissionEpoch){CapabilityScanner(context).scan()}
    var haptic by remember{mutableStateOf(output.hapticsEnabled)}
    var sound by remember{mutableStateOf(output.soundEnabled)}
    var torch by remember{mutableStateOf(output.torchEnabled)}
    var notices by remember{mutableStateOf(output.notificationsEnabled)}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{SectionTitle("Sensor permissions")}
        item{Card{Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Enable optional senses",fontWeight=FontWeight.Bold)
            Text("Camera, microphone, location, nearby Bluetooth and notifications are requested only after this explicit action. Physical motion/environment sensors that need no runtime permission are already available.",style=MaterialTheme.typography.bodySmall)
            Button(onClick=onRequestPermissions){Text("Enable available sensors")}
        }}}
        item{SectionTitle("Scale on this device")}
        item{Card{Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Balanced recommendation",fontWeight=FontWeight.Bold)
            Text("${fmt(ui.recommendation.balancedNeurons)} neurons × K=${ui.recommendation.balancedFanout} = ${fmt(ui.recommendation.logicalConnectionsBalanced)} logical connections")
            Button(onClick={controller.rebuild(ScaleProfile.Balanced)}){Text("Apply Balanced")}
            HorizontalDivider()
            Text("Max recommendation",fontWeight=FontWeight.Bold)
            Text("${fmt(ui.recommendation.maxNeurons)} neurons × K=${ui.recommendation.maxFanout} = ${fmt(ui.recommendation.logicalConnectionsMax)} logical connections")
            Button(onClick={controller.rebuild(ScaleProfile.Max)}){Text("Apply Max")}
            Text("Runtime scale is an engineering configuration, not a scientific validation claim. K6 remains the validated mechanism boundary.",style=MaterialTheme.typography.bodySmall)
        }}}
        item{SectionTitle("Outputs")}
        item{ToggleRow("Haptics",haptic){haptic=it;output.hapticsEnabled=it}}
        item{ToggleRow("Sound",sound){sound=it;output.soundEnabled=it}}
        item{ToggleRow("Torch",torch){torch=it;output.torchEnabled=it}}
        item{ToggleRow("Notifications",notices){notices=it;output.notificationsEnabled=it}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={controller.saveAsync()},modifier=Modifier.weight(1f)){Text("Save brain")}
            OutlinedButton(onClick={controller.loadNow()},modifier=Modifier.weight(1f)){Text("Load brain")}
        }}
        item{OutlinedButton(onClick={ContextCompat.startForegroundService(context,Intent(context,BrainForegroundService::class.java))},modifier=Modifier.fillMaxWidth()){Text("Background runtime")}}
        item{SectionTitle("Available hardware")}
        itemsIndexed(caps){_,c->
            ListItem(headlineContent={Text(c.name)},supportingContent={Text(c.detail)},trailingContent={Text(if(c.available)"Available" else "Unavailable",color=if(c.available)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)})
            HorizontalDivider()
        }
    }
}

@Composable private fun ToggleRow(label:String,checked:Boolean,onChange:(Boolean)->Unit){
    Card{Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f));Switch(checked=checked,onCheckedChange=onChange)}}
}
@Composable private fun SectionTitle(t:String)=Text(t,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
private val df1=DecimalFormat("0.0")
private val df3=DecimalFormat("0.000")
private fun fmt(v:Long)=fmt(v.toDouble())
private fun fmt(v:Double):String=when{v>=1e12->df1.format(v/1e12)+"T";v>=1e9->df1.format(v/1e9)+"B";v>=1e6->df1.format(v/1e6)+"M";v>=1e3->df1.format(v/1e3)+"K";else->df1.format(v)}
