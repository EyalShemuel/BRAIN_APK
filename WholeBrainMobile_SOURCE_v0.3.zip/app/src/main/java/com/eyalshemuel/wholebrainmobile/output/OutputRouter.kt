package com.eyalshemuel.wholebrainmobile.output

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class OutputRouter(private val context:Context) {
    var hapticsEnabled=true
    var soundEnabled=true
    var torchEnabled=false
    var notificationsEnabled=false
    private var lastAction=-1
    private var lastAt=0L
    private val tone=ToneGenerator(AudioManager.STREAM_MUSIC,55)

    fun route(action:Int){
        val now=System.currentTimeMillis(); if(action !in 0..1 || (action==lastAction && now-lastAt<450))return
        lastAction=action;lastAt=now
        if(hapticsEnabled)vibrate(action)
        if(soundEnabled)tone.startTone(if(action==0)ToneGenerator.TONE_PROP_BEEP else ToneGenerator.TONE_PROP_BEEP2,80)
        if(torchEnabled)flash(action)
        if(notificationsEnabled)notifyAction(action)
    }
    private fun vibrate(action:Int){
        val v:Vibrator=if(Build.VERSION.SDK_INT>=31) context.getSystemService(VibratorManager::class.java).defaultVibrator else @Suppress("DEPRECATION") (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        if(!v.hasVibrator())return
        val pattern=if(action==0) longArrayOf(0,45) else longArrayOf(0,30,40,30)
        v.vibrate(VibrationEffect.createWaveform(pattern,-1))
    }
    private fun flash(action:Int){
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return
        val cm=context.getSystemService(CameraManager::class.java)
        val id=runCatching{cm.cameraIdList.firstOrNull{cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)==true}}.getOrNull()?:return
        runCatching{cm.setTorchMode(id,true); android.os.Handler(context.mainLooper).postDelayed({runCatching{cm.setTorchMode(id,false)}},if(action==0)60 else 120)}
    }
    private fun notifyAction(action:Int){
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
        val nm=context.getSystemService(NotificationManager::class.java); val ch="wholebrain-actions"
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(ch,"WholeBrain actions",NotificationManager.IMPORTANCE_LOW))
        nm.notify(900+action,NotificationCompat.Builder(context,ch).setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("WholeBrain action ${action+1}").setContentText("Local motor output selected action $action").setAutoCancel(true).build())
    }
    fun close(){tone.release()}
}
