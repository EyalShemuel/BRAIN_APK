package com.eyalshemuel.wholebrainmobile.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light=lightColorScheme(
    primary=Color(0xFF006A67),onPrimary=Color.White,primaryContainer=Color(0xFF9CF1ED),
    secondary=Color(0xFF4A6361),tertiary=Color(0xFF48617A),background=Color(0xFFF5FAF9),surface=Color(0xFFF8FAFA)
)
private val Dark=darkColorScheme(
    primary=Color(0xFF80D5D1),onPrimary=Color(0xFF003735),primaryContainer=Color(0xFF00504E),
    secondary=Color(0xFFB1CCCA),tertiary=Color(0xFFADC9E7),background=Color(0xFF0E1515),surface=Color(0xFF111919)
)
@Composable fun WholeBrainTheme(content: @Composable () -> Unit){MaterialTheme(colorScheme=if(isSystemInDarkTheme())Dark else Light,content=content)}
