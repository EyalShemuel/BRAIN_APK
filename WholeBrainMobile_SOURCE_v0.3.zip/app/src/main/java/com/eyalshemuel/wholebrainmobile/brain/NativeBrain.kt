package com.eyalshemuel.wholebrainmobile.brain

object NativeBrain {
    init { System.loadLibrary("wholebrain") }
    external fun nativeCreate(neurons: Long, fanout: Int, seed: Long): Long
    external fun nativeDestroy(handle: Long)
    external fun nativeStep(handle: Long)
    external fun nativeStats(handle: Long): String
    external fun nativeSetMode(handle: Long, mode: Int)
    external fun nativeReward(handle: Long, positive: Boolean)
    external fun nativeSensor(handle: Long, type: Int, x: Float, y: Float, z: Float)
    external fun nativeTouch(handle: Long, x: Float, y: Float, pressure: Float)
    external fun nativeLocation(handle: Long, lat: Double, lon: Double, speed: Float, bearing: Float)
    external fun nativeNoteCameraFrame(handle: Long)
    external fun nativeVision(handle: Long, gray: ByteArray, width: Int, height: Int)
    external fun nativeAudio(handle: Long, pcm: ShortArray, sampleRate: Int)
    external fun nativeToken(handle: Long, channel: Int, data: ByteArray)
    external fun nativeSave(handle: Long): ByteArray
    external fun nativeRestore(handle: Long, blob: ByteArray): Boolean
    external fun nativeResetDiagnostics(handle: Long)
    external fun nativeCalibrate(memoryBudgetBytes: Long): String
}
