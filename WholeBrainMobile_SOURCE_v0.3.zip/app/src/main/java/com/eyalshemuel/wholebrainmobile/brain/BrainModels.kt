package com.eyalshemuel.wholebrainmobile.brain

enum class BrainMode(val nativeValue: Int) { Observe(0), Learn(1), Act(2), Sleep(3) }
enum class ScaleProfile { Verified, Balanced, Max }
enum class SensorMode(val label: String) {
    VisionOnly("VISION"), AudioOnly("AUDIO"), TouchOnly("TOUCH"), ImuOnly("IMU"),
    EnvironmentOnly("ENV"), LocationOnly("GPS"), ExternalOnly("EXT"), AllSensors("ALL")
}

data class ScaleRecommendation(
    val balancedNeurons: Long = 250_000,
    val balancedFanout: Int = 1024,
    val maxNeurons: Long = 250_000,
    val maxFanout: Int = 1024,
    val logicalConnectionsBalanced: Long = 256_000_000,
    val logicalConnectionsMax: Long = 256_000_000,
    val edgeHashPerSecond: Double = 0.0,
    val memoryBudgetBytes: Long = 0,
)

data class BrainStats(
    val neurons: Long = 0,
    val logicalSynapses: Long = 0,
    val tick: Long = 0,
    val spikesTotal: Long = 0,
    val edgeEventsTotal: Long = 0,
    val spikesLastStep: Int = 0,
    val queuedEvents: Long = 0,
    val lastStepMs: Double = 0.0,
    val spikesPerSecond: Double = 0.0,
    val edgesPerSecond: Double = 0.0,
    val stepHz: Double = 0.0,
    val regionSpikesPerSecond: List<Double> = List(15){0.0},
    val cameraFramesPerSecond: Double = 0.0,
    val visionFramesPerSecond: Double = 0.0,
    val visionFeaturesPerSecond: Double = 0.0,
    val visionInjectionsPerSecond: Double = 0.0,
    val audioChunksPerSecond: Double = 0.0,
    val audioBandsPerSecond: Double = 0.0,
    val audioInjectionsPerSecond: Double = 0.0,
    val touchEventsPerSecond: Double = 0.0,
    val touchInjectionsPerSecond: Double = 0.0,
    val imuEventsPerSecond: Double = 0.0,
    val imuChangesPerSecond: Double = 0.0,
    val imuInjectionsPerSecond: Double = 0.0,
    val environmentEventsPerSecond: Double = 0.0,
    val environmentChangesPerSecond: Double = 0.0,
    val environmentInjectionsPerSecond: Double = 0.0,
    val locationEventsPerSecond: Double = 0.0,
    val locationInjectionsPerSecond: Double = 0.0,
    val externalTokensPerSecond: Double = 0.0,
    val externalInjectionsPerSecond: Double = 0.0,
    val currentAction: Int = -1,
    val actionEpoch: Long = 0,
    val motorMargin: Double = 0.0,
    val reinforcedEpisodes: Long = 0,
    val memoryBytes: Long = 0,
    val motorDifferential: Double = 0.0,
    val mode: BrainMode = BrainMode.Observe,
)

data class BrainUiState(
    val running: Boolean = false,
    val calibrating: Boolean = true,
    val profile: ScaleProfile = ScaleProfile.Verified,
    val recommendation: ScaleRecommendation = ScaleRecommendation(),
    val sensorMode: SensorMode = SensorMode.AllSensors,
    val stats: BrainStats = BrainStats(),
    val thermalStatus: Int = 0,
    val error: String? = null,
)

data class CapabilityItem(
    val name: String,
    val available: Boolean,
    val detail: String = "",
    val category: String = "Sensor",
)
