#pragma once
#include <array>
#include <cstdint>
#include <mutex>
#include <span>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace wb {

enum class Region : uint8_t {
    Visual = 0, Auditory, Language, Somatosensory, Association,
    Hippocampus, Pfc, BasalGanglia, Thalamus, Cerebellum,
    Motor, VocalMotor, Semantic, Neuromod, Brainstem, Count
};

enum class RunMode : int { Observe = 0, Learn = 1, Act = 2, Sleep = 3 };

struct EngineConfig {
    uint64_t neurons = 250000;
    uint32_t fanout = 1024;
    uint64_t seed = 1;
    uint32_t timestepMs = 10;
    uint32_t recurrentDelayMax = 8;
    float localFraction = 0.875f;
    float excitatoryFraction = 0.80f;
    float membraneDecay = 0.90f;
    float threshold = 1.0f;
    float resetPotential = 0.0f;
    uint32_t refractoryTicks = 2;
    float excitatoryWeight = 0.040f;
    float inhibitoryWeight = 0.052f;

    // Modality-specific gains. Sensory geometry is fixed independently of these gains;
    // gain only controls current strength, not which neuron represents which input.
    float sensorGain = 0.90f;
    float visionGain = 1.15f;
    float audioGain = 1.15f;
    float touchGain = 1.20f;
    float imuGain = 1.15f;
    float environmentGain = 1.10f;
    float locationGain = 1.15f;
    float tokenGain = 1.20f;

    float motorGain = 8.0f;
    float learningRate = 0.001f;
    uint32_t actionWindowTicks = 8;
};

struct Event { uint32_t target; float weight; };

struct Stats {
    uint64_t neurons = 0;
    uint64_t logicalSynapses = 0;
    uint64_t tick = 0;
    uint64_t spikesTotal = 0;
    uint64_t edgeEventsTotal = 0;
    uint32_t spikesLastStep = 0;
    uint64_t queuedEvents = 0;
    double lastStepMs = 0.0;
    double spikesPerSecond = 0.0;
    double edgesPerSecond = 0.0;
    double stepHz = 0.0;
    std::array<double, static_cast<size_t>(Region::Count)> regionSpikesPerSecond{};

    double cameraFramesPerSecond = 0.0;
    double visionFramesPerSecond = 0.0;
    double visionFeaturesPerSecond = 0.0;
    double visionInjectionsPerSecond = 0.0;

    double audioChunksPerSecond = 0.0;
    double audioBandsPerSecond = 0.0;
    double audioInjectionsPerSecond = 0.0;

    double touchEventsPerSecond = 0.0;
    double touchInjectionsPerSecond = 0.0;

    double imuEventsPerSecond = 0.0;
    double imuChangesPerSecond = 0.0;
    double imuInjectionsPerSecond = 0.0;

    double environmentEventsPerSecond = 0.0;
    double environmentChangesPerSecond = 0.0;
    double environmentInjectionsPerSecond = 0.0;

    double locationEventsPerSecond = 0.0;
    double locationInjectionsPerSecond = 0.0;

    double externalTokensPerSecond = 0.0;
    double externalInjectionsPerSecond = 0.0;

    int currentAction = -1;
    uint64_t actionEpoch = 0;
    double motorMargin = 0.0;
    double motorDifferential = 0.0;
    uint64_t reinforcedEpisodes = 0;
    uint64_t memoryBytes = 0;
    RunMode mode = RunMode::Observe;
};

struct ScaleRecommendation {
    uint64_t balancedNeurons = 0;
    uint32_t balancedFanout = 1024;
    uint64_t maxNeurons = 0;
    uint32_t maxFanout = 1024;
    uint64_t logicalConnectionsBalanced = 0;
    uint64_t logicalConnectionsMax = 0;
    double measuredEdgeHashPerSecond = 0.0;
    uint64_t memoryBudgetBytes = 0;
};

class BrainEngine {
public:
    explicit BrainEngine(const EngineConfig& config);
    ~BrainEngine() = default;
    BrainEngine(const BrainEngine&) = delete;
    BrainEngine& operator=(const BrainEngine&) = delete;

    void step();
    void setMode(RunMode mode);
    RunMode mode() const;

    void noteCameraFrame();
    void injectVision(std::span<const uint8_t> pixels, int width, int height);
    void injectAudio(std::span<const int16_t> pcm, int sampleRate);
    void injectSensor(int sensorType, float x, float y, float z);
    void injectTouch(float xNorm, float yNorm, float pressure);
    void injectLocation(double latitude, double longitude, float speed, float bearing);
    void injectToken(uint32_t channel, std::span<const uint8_t> bytes);
    void resetDiagnostics();

    void reward(bool positive);

    Stats stats() const;
    std::string statsJson() const;
    std::vector<uint8_t> serializePlasticity() const;
    bool restorePlasticity(std::span<const uint8_t> blob);

    const EngineConfig& config() const { return cfg_; }
    static double benchmarkEdgeHash(uint64_t edges, uint64_t seed = 1);
    static ScaleRecommendation recommendScale(uint64_t memoryBudgetBytes,
                                              double measuredEdgesPerSecond,
                                              double targetHz = 60.0,
                                              double assumedActiveFraction = 0.005);

    // Deterministic scientific/test primitives.
    static uint64_t mix64(uint64_t x);
    static uint32_t deterministicTarget(uint32_t source, uint32_t slot,
                                        uint32_t n, uint64_t seed);
    static float core53ErrorUpdate(float differential, uint16_t count, int chosen, float eta);

    // Scale-stable topographic mapping. Adjacent cells map to adjacent neuron columns;
    // role chooses a neuron inside the cell column and never hashes spatial position.
    static uint32_t topographicLocal(uint32_t regionSize,
                                     uint32_t cellIndex,
                                     uint32_t cellCount,
                                     uint32_t role,
                                     uint32_t roleCount);

private:
    struct RegionRange { uint32_t begin = 0, end = 0; };
    struct FeatureCount { uint32_t index; uint16_t count; };
    struct TouchState { float x=0.0f, y=0.0f, pressure=0.0f; bool active=false; };

    void buildRegions();
    Region regionOf(uint32_t neuron) const;
    uint32_t regionSize(Region region) const;
    bool isExcitatory(uint32_t neuron) const;
    void schedule(uint32_t target, float weight, uint32_t delayTicks);
    uint32_t injectPopulation(Region region, uint64_t key, float magnitude, uint32_t count, float gain);
    uint32_t injectChannelPopulation(Region region, uint32_t channel, uint32_t channelCount,
                                     float magnitude, float density, float gain, uint64_t salt = 0,
                                     uint32_t maxCount = 16);
    uint32_t injectDistributedSubrange(Region region, uint32_t bank, uint32_t banks,
                                       uint64_t key, float magnitude, float density, float gain,
                                       uint32_t maxCount = 64);
    uint32_t injectTopographicCell(Region region, uint32_t x, uint32_t y,
                                   uint32_t width, uint32_t height,
                                   uint32_t role, uint32_t roleCount,
                                   float magnitude, float gain);
    uint32_t injectVisualFeature(uint64_t key, float magnitude, int width, int height);
    uint32_t injectAudioBand(uint32_t band, float magnitude, float onset);
    void injectEnvironment(int sensorType, float x, float y, float z);

    void applyLazyDecay(uint32_t neuron);
    void fire(uint32_t neuron, std::vector<uint32_t>& fired);
    void propagate(std::span<const uint32_t> fired);
    void processMotor(std::span<const uint32_t> fired);
    void finishActionWindow();
    void resetCurrentFeature();
    float thresholdFor(uint32_t neuron) const;
    uint64_t memoryBytesUnsafe() const;

    EngineConfig cfg_;
    mutable std::mutex mutex_;
    std::array<RegionRange, static_cast<size_t>(Region::Count)> regions_{};

    std::vector<float> membrane_;
    std::vector<uint32_t> lastUpdateTick_;
    std::vector<uint32_t> lastSpikeTick_;
    std::vector<uint16_t> touchMarker_;
    uint16_t touchEpoch_ = 1;
    std::vector<uint32_t> touched_;
    std::vector<std::vector<Event>> eventRing_;

    RegionRange association_{};
    RegionRange motor_{};
    std::vector<float> motorDifferential_;
    std::vector<uint16_t> featureCounts_;
    std::vector<uint32_t> featureTouched_;
    std::vector<FeatureCount> lastFeature_;
    double motorEvidence_ = 0.0;
    std::array<uint32_t, 2> motorSpikesWindow_{0, 0};
    int lastAction_ = -1;
    uint64_t actionEpoch_ = 0;
    double lastMotorMargin_ = 0.0;
    uint64_t reinforcedEpisodes_ = 0;

    uint64_t tick_ = 0;
    uint64_t spikesTotal_ = 0;
    uint64_t edgeEventsTotal_ = 0;
    uint32_t spikesLastStep_ = 0;
    double lastStepMs_ = 0.0;
    double emaStepMs_ = 0.0;
    double emaSpikesPerSecond_ = 0.0;
    double emaEdgesPerSecond_ = 0.0;
    std::array<double, static_cast<size_t>(Region::Count)> emaRegionSpikesPerSecond_{};

    double emaCameraFramesPerSecond_ = 0.0;
    double emaVisionFramesPerSecond_ = 0.0;
    double emaVisionFeaturesPerSecond_ = 0.0;
    double emaVisionInjectionsPerSecond_ = 0.0;
    double emaAudioChunksPerSecond_ = 0.0;
    double emaAudioBandsPerSecond_ = 0.0;
    double emaAudioInjectionsPerSecond_ = 0.0;
    double emaTouchEventsPerSecond_ = 0.0;
    double emaTouchInjectionsPerSecond_ = 0.0;
    double emaImuEventsPerSecond_ = 0.0;
    double emaImuChangesPerSecond_ = 0.0;
    double emaImuInjectionsPerSecond_ = 0.0;
    double emaEnvironmentEventsPerSecond_ = 0.0;
    double emaEnvironmentChangesPerSecond_ = 0.0;
    double emaEnvironmentInjectionsPerSecond_ = 0.0;
    double emaLocationEventsPerSecond_ = 0.0;
    double emaLocationInjectionsPerSecond_ = 0.0;
    double emaExternalTokensPerSecond_ = 0.0;
    double emaExternalInjectionsPerSecond_ = 0.0;

    uint64_t pendingCameraFrames_ = 0;
    uint64_t pendingVisionFrames_ = 0;
    uint64_t pendingVisionFeatures_ = 0;
    uint64_t pendingVisionInjections_ = 0;
    uint64_t pendingAudioChunks_ = 0;
    uint64_t pendingAudioBands_ = 0;
    uint64_t pendingAudioInjections_ = 0;
    uint64_t pendingTouchEvents_ = 0;
    uint64_t pendingTouchInjections_ = 0;
    uint64_t pendingImuEvents_ = 0;
    uint64_t pendingImuChanges_ = 0;
    uint64_t pendingImuInjections_ = 0;
    uint64_t pendingEnvironmentEvents_ = 0;
    uint64_t pendingEnvironmentChanges_ = 0;
    uint64_t pendingEnvironmentInjections_ = 0;
    uint64_t pendingLocationEvents_ = 0;
    uint64_t pendingLocationInjections_ = 0;
    uint64_t pendingExternalTokens_ = 0;
    uint64_t pendingExternalInjections_ = 0;

    RunMode mode_ = RunMode::Observe;

    std::vector<uint8_t> previousVision_;
    std::array<float, 32> previousAudioBands_{};
    bool havePreviousAudio_ = false;
    std::unordered_map<int, std::array<float,3>> previousMotionSensor_;
    std::unordered_map<int, float> previousEnvironmentLevel_;
    TouchState previousTouch_{};
};

std::string recommendationJson(const ScaleRecommendation& r);

} // namespace wb
