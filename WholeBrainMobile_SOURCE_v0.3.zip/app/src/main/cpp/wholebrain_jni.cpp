#include <jni.h>
#include <algorithm>
#include <android/log.h>
#include <memory>
#include <string>
#include <vector>
#include "wholebrain_engine.h"

#define LOG_TAG "WholeBrainNative"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
wb::BrainEngine* engine(jlong h) { return reinterpret_cast<wb::BrainEngine*>(h); }
jstring jstr(JNIEnv* env, const std::string& s) { return env->NewStringUTF(s.c_str()); }
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeCreate(
    JNIEnv* env, jobject, jlong neurons, jint fanout, jlong seed) {
    try {
        wb::EngineConfig c; c.neurons=static_cast<uint64_t>(neurons); c.fanout=static_cast<uint32_t>(fanout); c.seed=static_cast<uint64_t>(seed);
        return reinterpret_cast<jlong>(new wb::BrainEngine(c));
    } catch (const std::exception& e) {
        LOGE("create failed: %s", e.what());
        jclass cls=env->FindClass("java/lang/RuntimeException"); env->ThrowNew(cls,e.what()); return 0;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeDestroy(JNIEnv*, jobject, jlong h) {
    delete engine(h);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeStep(JNIEnv*, jobject, jlong h) { if(auto* e=engine(h)) e->step(); }
extern "C" JNIEXPORT jstring JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeStats(JNIEnv* env, jobject, jlong h) {
    return jstr(env, engine(h)?engine(h)->statsJson():"{}");
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSetMode(JNIEnv*, jobject, jlong h, jint mode) {
    if(auto* e=engine(h)) e->setMode(static_cast<wb::RunMode>(std::clamp(mode,0,3)));
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeReward(JNIEnv*, jobject, jlong h, jboolean positive) {
    if(auto* e=engine(h)) e->reward(positive==JNI_TRUE);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSensor(JNIEnv*, jobject, jlong h, jint type, jfloat x,jfloat y,jfloat z) {
    if(auto* e=engine(h)) e->injectSensor(type,x,y,z);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeTouch(JNIEnv*, jobject, jlong h, jfloat x,jfloat y,jfloat p) {
    if(auto* e=engine(h)) e->injectTouch(x,y,p);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLocation(JNIEnv*, jobject, jlong h, jdouble lat,jdouble lon,jfloat speed,jfloat bearing) {
    if(auto* e=engine(h)) e->injectLocation(lat,lon,speed,bearing);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeNoteCameraFrame(JNIEnv*, jobject, jlong h) {
    if(auto* e=engine(h)) e->noteCameraFrame();
}

extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeVision(JNIEnv* env, jobject, jlong h, jbyteArray data, jint w,jint hh) {
    if(!engine(h)||!data) return;
    const jsize n=env->GetArrayLength(data); std::vector<uint8_t> v(n);
    env->GetByteArrayRegion(data,0,n,reinterpret_cast<jbyte*>(v.data())); engine(h)->injectVision(v,w,hh);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeAudio(JNIEnv* env, jobject, jlong h, jshortArray data, jint sr) {
    if(!engine(h)||!data) return;
    const jsize n=env->GetArrayLength(data); std::vector<int16_t> v(n);
    env->GetShortArrayRegion(data,0,n,reinterpret_cast<jshort*>(v.data())); engine(h)->injectAudio(v,sr);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeToken(JNIEnv* env, jobject, jlong h, jint channel, jbyteArray data) {
    if(!engine(h)||!data) return;
    const jsize n=env->GetArrayLength(data); std::vector<uint8_t> v(n);
    env->GetByteArrayRegion(data,0,n,reinterpret_cast<jbyte*>(v.data())); engine(h)->injectToken(static_cast<uint32_t>(channel),v);
}
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSave(JNIEnv* env, jobject, jlong h) {
    if(!engine(h)) return env->NewByteArray(0);
    const auto blob=engine(h)->serializePlasticity();
    jbyteArray out=env->NewByteArray(static_cast<jsize>(blob.size()));
    env->SetByteArrayRegion(out,0,static_cast<jsize>(blob.size()),reinterpret_cast<const jbyte*>(blob.data())); return out;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeRestore(JNIEnv* env, jobject, jlong h, jbyteArray data) {
    if(!engine(h)||!data) return JNI_FALSE;
    const jsize n=env->GetArrayLength(data); std::vector<uint8_t> v(n);
    env->GetByteArrayRegion(data,0,n,reinterpret_cast<jbyte*>(v.data())); return engine(h)->restorePlasticity(v)?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeResetDiagnostics(JNIEnv*, jobject, jlong h) {
    if(auto* e=engine(h)) e->resetDiagnostics();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeCalibrate(JNIEnv* env, jobject, jlong memoryBudgetBytes) {
    const double rate=wb::BrainEngine::benchmarkEdgeHash(3000000,0xC0FFEE);
    const auto r=wb::BrainEngine::recommendScale(static_cast<uint64_t>(memoryBudgetBytes),rate); return jstr(env,wb::recommendationJson(r));
}
