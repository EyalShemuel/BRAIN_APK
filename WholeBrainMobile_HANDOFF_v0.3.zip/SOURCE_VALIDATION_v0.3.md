# Source validation — WholeBrain Mobile 0.3.0

Validated locally before packaging:

- C++20 host engine compile: PASS.
- all sensory-topology v3 host gates: PASS.
- reward-learning regression, seeds 77/78/79: post-training accuracy 1.000 / 1.000 / 1.000: PASS.
- camera source uses display-orientation-corrected 64×36 YUV retinal sampling.
- touch source sends continuous down/move/release and pointer pressure.
- audio capture has raw-source fallback chain.
- Android sensor source separates IMU and environmental sampling policy and supports trigger sensors.
- versionCode=3, versionName=0.3.0.

Full Android type resolution/APK is a separate CI gate because this local environment does not contain the Android SDK/AGP dependency set. The CI workflow included in the handoff builds the exact packaged source.

Scientific boundary: the mobile recurrent engine is not yet certified spike-for-spike against Python CLEAN CORE; runtime 250K/K1024 is not a K1024 capability validation.
