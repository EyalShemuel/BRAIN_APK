# WholeBrain Mobile

Offline Android embodiment of the WholeBrain Clean Core / CORE53 research line.

## 0.3.0 — Sensory Topology v3

The physical sensory front end is now scale-stable and modality-specific rather than a fixed tiny random population:

- Vision: 64×36 retinotopic retina, 10 roles/cell (luma, temporal, edges, chroma), orientation-corrected YUV sampling.
- Audio: 32 logarithmic tonotopic bands with microphone-floor rejection and onset coding.
- Touch: 32×18 somatotopic surface with contact, pressure, motion polarity and release.
- IMU/gyro/magnetometer/orientation: calibrated delta channels by sensor/axis/polarity; constant gravity/DC is rejected.
- Environment/body: calibrated level/change channels; one-shot trigger sensors; battery/thermal interoception.
- GPS: 200m/50m/10m multi-scale hippocampal place coding plus speed/bearing.
- External: NFC, USB attach/detach, Bluetooth/BLE context, network-state context with scale-stable distributed Semantic/Association banks.
- Validation UI isolates VISION / AUDIO / TOUCH / IMU / ENV / GPS / EXT / ALL and exposes real per-modality injection rates plus 15-region spike rates.

The scientific channel-9 teaching cue remains locked to the pre-v3 injection semantics. Reward-learning regression remains 1.000 post-training on seeds 77/78/79.

See `SENSORY_TOPOLOGY_V3_REPORT_HE.md` for the exact mapping and validation details.

## Scientific claim boundary

The Android C++ engine preserves the CORE53 differential motor update algebra and passes the host regression suite. Android runtime scale (for example 250K/K1024) is an engineering execution scale, not a scientific K1024 capability claim. Scientifically validated capacity remains bounded by the separately measured Clean Core experiments.

## Scaling

Logical recurrent connections are procedural (`N × K`) and regenerated on spikes rather than stored as a giant edge table. Scale is device-calibrated; 71M/K4096 remains only an implementation ceiling.

## Build

Expected Android toolchain:
- JDK 17
- Gradle 9.6
- AGP 9.4
- Android SDK 37.2 for compile (targetSdk 36)
- NDK 28.2.13676358

Host validation:

```bash
./scripts/test_host.sh
```

Android debug APK:

```bash
gradle :app:assembleDebug
```

## Privacy

Raw sensory processing is local. The manifest has no `INTERNET` permission. Network state is context only. External-device channels are opt-in and permission-gated where Android requires it.
