# Build status — WholeBrain Mobile 0.3.0 Sensory Topology v3

Generated: 2026-09-14

## Host-native PASS

- C++20 engine + sensory encoder compile.
- deterministic recurrent topology primitives.
- exact CORE53 differential error-update algebra.
- no phantom action without evidence.
- retinotopic mapping adjacency + scale stability.
- static and temporal Visual ignition at 250K without v0.2 scale dilution.
- chroma feature preservation.
- audio silence rejection + tonotopic frequency ordering + direct Auditory ignition.
- touch contact/movement/release → Somatosensory.
- IMU constant/DC rejection + calibrated axis/polarity delta injection.
- calibrated environmental channels; repeated stable level does not create a new spike burst.
- GPS multi-scale place injection → Hippocampus.
- NFC/external distributed context → Semantic/Association.
- mixed-sensor event/save/restore smoke.
- reward-learning regression seeds 77/78/79: post = 1.000 on all three.

Latest host output is saved under `host-tests/V3_SENSORY_TEST_OUTPUT.txt`.

## Android source changes included

- camera orientation correction and 3×3 stratified YUV sampling per retinal cell.
- raw microphone preference (`UNPROCESSED` → `VOICE_RECOGNITION` → `MIC` fallback).
- continuous touch down/move/up with actual pointer pressure.
- one-shot SensorManager triggers re-armed after events.
- IMU GAME sampling; environment NORMAL sampling.
- USB/Bluetooth/BLE/network/battery change callbacks.
- input-isolation and real modality/region diagnostics UI.
- state namespace/version bumped so old sensory geometry is not silently reused.

## Pending gate

- GitHub Actions Android compile/APK for this exact 0.3.0 source.
- on-device isolation measurements for each modality.
- 30-minute thermal/endurance measurement.
- Android-vs-Python spike/state parity and Android K6 behavioral regression.

Do not treat K1024 runtime operation as K1024 scientific validation.
