# WholeBrain Mobile v0.6.1 — Performance / Camera Stability Audit

## נקודת הכשל שנמצאה

ההאטה אינה מתחילה מה-Preview עצמו. מסלול החישה הוויזואלית דוחף את המנוע הרקורסיבי מעבר לברך יציבות של פרופיל המובייל הישן `250K / K=1024`. כאשר התור גדל, `nativeStep()` מחזיק את mutex לזמן ארוך יותר, קריאות המצלמה/חיישנים ממתינות לאותו mutex, צריכת CPU וזיכרון מזנקת, ובהמשך גם ה-UI וה-Preview מאבדים קצב.

## מדידה משחזרת

בבדיקת host עם 250K נוירונים, K=1024 וקלט ויזואלי נע:

- בקצב המקביל לכ-10Hz vision: כשל סביב tick 76–77, עם יותר מ-5.6M אירועים בתור ו-step של כ-69ms.
- בתרחיש עומס דחוס יותר: tick 10 = 699,456 queued / 6.8ms; tick 20 = 37,812,415 queued / 440ms / ~540MB.
- ריצה ללא בלם הגיעה לכ-3.9GB RSS ונקטלה על ידי מערכת ההפעלה.

הסיבה המבנית: משקלי הרקורסיה קבועים בעוד fanout גדל. בדיקות ה-host המקוריות הפעילו את mixed regression ב-K=64, ולכן לא חשפו את instability knee של K=1024 תחת חישה רציפה.

## אימות פרופיל יציב

סריקת K תחת אותו קלט: K=64/128/192/256 נשארו יציבים; K>=384 נכנסו ל-avalanche.

תרחיש worst-case נוסף המדמה גם האטה תרמית (vision כל 3 ticks, audio בכל tick, IMU רציף):

- K=256: PASS ל-5,000 ticks. peak queue ~266K, end queue ~198K, peak host step ~4.9ms.
- K=384 ומעלה: FAIL עקב event avalanche.

## גורמים משניים שנמצאו

1. `CameraBrainAnalyzer` יצר `Pair<Int,Int>` לכל נקודת דגימה: 64×36×9 = 20,736 זוגות לכל retinal frame, כלומר מאות אלפי allocations בשנייה סביב 10Hz.
2. נוצר `ByteArray` חדש לכל retinal frame.
3. כל `BrainUiState` עודכן כל 4 ticks (~25Hz), ולכן מסך Compose הראשי קיבל state חדש בקצב גבוה למרות שה-Preview אינו צריך אותו.
4. thermal protection דילג על 2 מתוך 3 צעדי מוח ב-SEVERE, אבל לא האט את קצב החיישנים. לכן מספר קלטים לכל tick גדל דווקא כשהמכשיר מתחמם.
5. ה-APK הנוכחי הוא Debug; Android מציינת ש-Debug mode עצמו מוסיף overhead, ולכן אחרי תיקון ה-avalanche כדאי לבנות גם build מותאם ביצועים.

## תיקוני v0.6.1

- פרופיל Stable/Verified: 250K / K256.
- Balanced/Max recommendations נשארים K256 ומגדילים N בלבד עד שתתבצע ולידציה נפרדת ל-K גבוה יותר.
- retinal sampling מוגבל בזמן: 8Hz רגיל, ~3.3Hz ב-thermal severe; ה-Preview נשאר עצמאי.
- הסרת Pair allocations בעזרת packed primitive coordinates.
- שימוש חוזר ב-retinal ByteArray.
- ImageAnalysis target 640×360 ו-thread priority מעט נמוך יותר מה-UI.
- UI telemetry ירד מ-25Hz ל-12.5Hz.
- נוסף regression של sustained live load ב-K256 ל-host test.

## תוצאות רגרסיה אחרי התיקון

כל החבילה עוברת: topology, sensory paths, learning smoke בשלושה seeds, authorized voice mimic, ובדיקת sustained live-load החדשה.
