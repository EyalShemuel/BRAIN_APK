# WholeBrain Mobile v0.9.0 — BioSpeech

## גבול הטענה המדעית

v0.9.0 היא **מערכת דיבור סנסורימוטורית מוגבלת־ביולוגית**. היא אינה "שחזור מלא" של קורטקס הדיבור האנושי, משום שאין כיום מפת חיבורים, דינמיקה סינפטית ומודל ביומכני מלאים ברמת האדם שמאפשרים לשחזר מערכת כזו בדיוק. המטרה כאן היא לבנות מודל מפורש, מדיד וניתן להפרכה שמחקה עקרונות ידועים: תכנון לשוני, תכנון מוטורי, פקודות ארטיקולטוריות, משוב שמיעתי וסומטוסנסורי, לולאות צרבלריות/גרעיני בסיס, ומיקרו־מעגל קורטיקלי מקורב.

## מה השתנה לעומת v0.8

v0.8 יצר waveform חדש מתוך מסגרות אקוסטיות נלמדות. v0.9 מוציא את מחולל הקול האקוסטי מתפקיד "הקורטקס" ומעביר את הפלט דרך plant ארטיקולטורי:

`Language/Semantic → PFC → Basal Ganglia/Thalamus → vPMC-like Motor → vM1-like VocalMotor → articulators → vocal-tract plant → audio`

ומחזיר שתי לולאות:

- `audio → Auditory cortex → prediction error → Cerebellum → motor correction`
- `jaw/tongue/lips/etc. → Somatosensory cortex → proprioceptive error → Cerebellum → motor correction`

`AudioTrack` באנדרואיד הוא actuator פיזי בלבד. אין Android TTS, אין `synthesizeToFile`, ואין replay של משפט מוקלט במסלול הפעיל.

## ייצוג מוטורי

כל MotorFrame כולל 10 משתנים ארטיקולטוריים מנורמלים:

1. מיקום לשון קדימה/אחורה (`tongueX`)
2. גובה לשון (`tongueY`)
3. קצה לשון (`tongueTip`)
4. פתיחת לסת (`jaw`)
5. פתיחת שפתיים (`lipAperture`)
6. עיגול שפתיים (`lipRound`)
7. וילום/נזאליות (`velum`)
8. מתח מיתרי קול (`glottalTension`)
9. adduction (`adduction`)
10. לחץ תת־גלוטלי (`pressure`)

הזיכרון שנשמר הוא תוכנית מוטורית + יעד חושי, לא PCM להשמעה חוזרת.

## Plant קולי

ה־plant הנוכחי הוא מודל רציף מקורב, לא מודל FEM/CFD אנטומי מלא. הוא ממפה articulators ל־F0, אנרגיה, voicing, F1/F2/F3 ונזאליות, ומפיק waveform דרך מקור גלוטלי + resonators. המטרה היא לאפשר closed-loop learning ו־perturbation experiments בתוך תקציב חישוב של טלפון.

## משוב ותיקון

המודל תומך ב־perturbations מפורשים:

- הסטת F1 שמיעתית
- הסטת F2 שמיעתית
- הסטה מכנית של הלסת

לולאת S1 תוקנה ב־v0.9 לעבוד על **השארית המכנית שנותרה בפועל בכל איטרציה**, ולא על perturbation קבוע שחוזר שוב ושוב. כך נמנע over-correction ונוצרות שתי לולאות תיקון עצמאיות.

בבדיקת host הנוכחית:

```text
PASS biospeech primitives=3 baseline_samples=10432
jaw_before=0.034877
jaw_after=0.000305049
cereb_after=0.034877
auditory_before=0.113459
auditory_after=0.0657209
auditory_lesion_after=0.113459
s1_lesion_after=0.00591345
motor_auditory_lesion_after=0.000727233
dual_feedback_lesion_after=0.034877
compensation=0.102165
```

כלומר:

- perturbation מכני מתוקן כשהלולאות פעילות;
- lesion ל־S1 מחמיר את התוצאה הסגורה, אך המשוב השמיעתי עדיין מפצה חלקית;
- lesion למסלול השמיעתי מחמיר את התוצאה, אך S1 עדיין מפצה;
- lesion לשניהם משאיר את השגיאה המכנית כמעט ללא תיקון;
- lesion ל־Cerebellum מבטל את התיקון המהיר;
- perturbation שמיעתי מתוקן כשה־Auditory loop פעיל ונשאר כמעט ללא תיקון כשהוא lesioned;
- lesion ל־planner או ל־VocalMotor חוסם דיבור;
- lesion ל־Basal Ganglia פוגע ב־initiation/energy בלי למחוק את התוכנית.

## מיקרו־מעגל קורטיקלי מקורב

מסלול הדיבור מפעיל באופן מפורש קבוצות מקורבות של:

- L4 — input חושי/תלמי
- L2/3 — ייצוגים וקשרים קורטיקו־קורטיקליים
- L5 — output מוטורי
- L6 — corticothalamic/context

ובתוכן חלוקה דטרמיניסטית ל־pyramidal / PV / SST / VIP-like populations. זוהי **approximation הנדסית**, לא טענה ליחסי תאים או connectome אנושי מדויקים.

## התפתחות ולמידה מהירה

סט הלמידה עבר למבנה התפתחותי:

1. כיול תנועות
2. CV syllables מנוקדות
3. מילים
4. משפטים
5. generalization לרצפים חדשים

הקוריקולום כולל 40 prompts ומכסה 28/28 יחידות ליבה: 22 אותיות עבריות מנורמלות + `a/e/i/o/u/schwa`.

בזמן לימוד:

- ה־prompt מוזרם ל־Language/Semantic;
- המיקרופון מוזרם online ל־Auditory;
- בסיום מתבצע consolidation של תוכנית articulatory + sensory targets לתוך זיכרון המוח.

עברית לא מנוקדת עדיין דורשת inference מהקשר שנלמד; אין dictionary סמוי שמחליף למידה.

## תאימות לאחור

פורמט הפלסטיות החיצוני של v0.9 הוא serialization v5. restore מקבל גם v2/v3/v4.

נוסף gate מפורש שמייצר blob אמיתי בפורמט v0.8/serialization-v4 וטוען אותו לתוך v0.9. הזיכרון הגנרטיבי הישן נשמר; זיכרונות BioSpeech אינם קיימים ב־v0.8 ולכן יש לבצע כיול/למידת BioSpeech חדשה.

## מה נבדק

- sensory/topology regression
- sustained K256 stability
- learning smoke בשלושה seeds: 77/78/79
- legacy neural-speech persistence
- v0.8 novel-sequence generation
- v0.8 serialization-v4 restore into v0.9
- BioSpeech novel sequence
- VocalMotor + Motor activation
- jaw perturbation compensation
- independent auditory/S1 feedback lesions
- cerebellar lesion
- auditory perturbation + auditory lesion
- planner/VocalMotor/BG lesions
- BioSpeech persistence/restore
- fail-closed על primitive חסר
- hard gate נגד Android TTS
- hard gate נגד active phrase replay
- hard gate נגד שימוש פעיל ב־v0.8 generator

## מגבלות שנותרו

1. אין connectome אנושי מלא ברמת synapse.
2. ה־vocal tract הוא plant פורמנטי רציף, לא רקמה תלת־ממדית עם fluid dynamics.
3. אין מודל מלא של cranial nerves, motor units ושרירי גרון/פנים פרטניים.
4. היחסים PV/SST/VIP וה־laminar mapping הם קירוב, לא מדידה אישית מאדם מסוים.
5. אין עדיין developmental babbling ארוך עם גילוי עצמי של כל inventory הפונמי ללא supervision.
6. איכות/מובנות/טבעיות חייבות להימדד על מכשיר פיזי ובדוברים אמיתיים; host tests מוכיחים התנהגות מנגנונית, לא איכות קול אנושית.

## מסקנה

v0.9 אינו "מוח אנושי משוחזר", אבל הוא מוציא את הדיבור ממסלול של TTS או vocoder קורטיקלי ישיר ומעמיד במקומו מערכת סנסורימוטורית מפורשת: cortex-like planning, BG/thalamic gating, cerebellar forward correction, vPMC/vM1-like motor drive, articulatory plant, auditory feedback ו־somatosensory feedback. זה יעד מדעי מדיד שאפשר להמשיך להעמיק בלי לטעון מעבר למה שנבדק.
