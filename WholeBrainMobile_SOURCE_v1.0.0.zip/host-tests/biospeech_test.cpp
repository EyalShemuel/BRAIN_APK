#include "../app/src/main/cpp/wholebrain_engine.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <span>
#include <string>
#include <vector>

static std::vector<int16_t> richVoice(double f0,double form1,double form2,double seconds){
    constexpr int sr=16000; const size_t n=size_t(std::llround(seconds*sr)); std::vector<int16_t> x(n);
    for(size_t i=0;i<n;++i){
        const double t=double(i)/sr; const double edge=std::min(1.0,std::min(double(i)/160.0,double(n-1-i)/160.0));
        double v=0.55*std::sin(2*M_PI*f0*t)+0.18*std::sin(2*M_PI*2*f0*t)+0.10*std::sin(2*M_PI*3*f0*t);
        v += 0.15*std::sin(2*M_PI*form1*t)+0.10*std::sin(2*M_PI*form2*t);
        x[i]=int16_t(std::clamp(v*14500.0*std::max(0.0,edge),-30000.0,30000.0));
    } return x;
}
static std::vector<int16_t> phrase(std::initializer_list<std::array<double,3>> parts){
    std::vector<int16_t> out; for(auto p:parts){auto x=richVoice(p[0],p[1],p[2],0.18);out.insert(out.end(),x.begin(),x.end());}return out;
}
static std::span<const uint8_t> bytes(const std::string&s){return {reinterpret_cast<const uint8_t*>(s.data()),s.size()};}
static long long energy(const std::vector<int16_t>&x){long long e=0;for(auto v:x)e+=std::abs(int(v));return e;}

int main(){
    wb::EngineConfig c;c.neurons=30000;c.fanout=64;c.seed=9090;wb::BrainEngine e(c);e.setMode(wb::RunMode::Learn);for(int i=0;i<4;++i)e.step();
    const std::string A="g:05d0",B="g:05d1",M="g:05de";const char sep=char(0x1f);
    const std::string AB=A+sep+B, MA=M+sep+A, BM=B+sep+M;
    assert(e.learnBioSpeech(bytes(AB),phrase({{130,520,1250},{145,650,1800}}),16000));
    assert(e.learnBioSpeech(bytes(MA),phrase({{155,430,2100},{130,520,1250}}),16000));
    assert(e.learnBioSpeech(bytes(BM),phrase({{145,650,1800},{155,430,2100}}),16000));
    assert(e.learnedBioSpeechPrimitives()>=3);
    assert(e.hasBioSpeechPrimitive(bytes(A))&&e.hasBioSpeechPrimitive(bytes(B))&&e.hasBioSpeechPrimitive(bytes(M)));

    const std::string novel=A+sep+M+sep+B+sep+"#p";
    e.setMode(wb::RunMode::Act); const auto baseline=e.renderBioSpeech(bytes(novel)); assert(baseline.size()>4000); assert(energy(baseline)>1000000);
    auto d0=e.bioSpeechDiagnostics(); assert(d0.renderedFrames>0);
    for(int i=0;i<8;++i) e.step();
    auto st=e.stats();
    assert(st.regionSpikesPerSecond[size_t(wb::Region::VocalMotor)]>0.0);
    assert(st.regionSpikesPerSecond[size_t(wb::Region::Motor)]>0.0);

    // A mechanical jaw perturbation must evoke closed-loop compensation and reduce error.
    e.setBioSpeechPerturbation(0,0,0.10f);e.setBioSpeechLesionMask(0);const auto compensated=e.renderBioSpeech(bytes(novel));assert(!compensated.empty());
    auto dc=e.bioSpeechDiagnostics();
    assert(dc.compensationMagnitude>0.01); assert(dc.auditoryErrorAfter<dc.auditoryErrorBefore);

    // S1 and auditory feedback must be independently useful.  Removing either
    // loop worsens the fully closed-loop result; removing both restores the
    // uncorrected mechanical error rather than silently using another path.
    e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionSomatosensory);
    e.renderBioSpeech(bytes(novel)); const auto ds=e.bioSpeechDiagnostics();
    assert(ds.auditoryErrorAfter>dc.auditoryErrorAfter*1.20);
    assert(ds.auditoryErrorAfter<ds.auditoryErrorBefore);
    e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionAuditory);
    e.renderBioSpeech(bytes(novel)); const auto dam=e.bioSpeechDiagnostics();
    assert(dam.auditoryErrorAfter>dc.auditoryErrorAfter*1.20);
    assert(dam.auditoryErrorAfter<dam.auditoryErrorBefore);
    e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionSomatosensory|wb::BioSpeechModel::LesionAuditory);
    e.renderBioSpeech(bytes(novel)); const auto dboth=e.bioSpeechDiagnostics();
    assert(dboth.auditoryErrorAfter>std::max(ds.auditoryErrorAfter,dam.auditoryErrorAfter));
    assert(dboth.compensationMagnitude<1e-6);

    // Removing cerebellar correction should selectively worsen the same perturbation.
    e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionCerebellum);const auto cereb=e.renderBioSpeech(bytes(novel));assert(!cereb.empty());
    auto dl=e.bioSpeechDiagnostics(); assert(dl.auditoryErrorAfter>dc.auditoryErrorAfter*1.10);

    // Auditory shift should be compensated when the auditory loop is present, less when lesioned.
    e.setBioSpeechPerturbation(170.0f,-220.0f,0.0f);e.setBioSpeechLesionMask(0);e.renderBioSpeech(bytes(novel));auto da=e.bioSpeechDiagnostics();
    assert(da.auditoryErrorAfter<da.auditoryErrorBefore);
    e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionAuditory);e.renderBioSpeech(bytes(novel));auto daa=e.bioSpeechDiagnostics();
    assert(daa.auditoryErrorAfter>=da.auditoryErrorAfter);

    // Planner and vocal-motor lesions fail closed, while BG lesion degrades onset/energy but does not erase the plan.
    e.setBioSpeechPerturbation(0,0,0);e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionPlanner);assert(e.renderBioSpeech(bytes(novel)).empty());
    e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionVocalMotor);assert(e.renderBioSpeech(bytes(novel)).empty());
    e.setBioSpeechLesionMask(wb::BioSpeechModel::LesionBasalGanglia);const auto bg=e.renderBioSpeech(bytes(novel));assert(!bg.empty());assert(energy(bg)<energy(baseline));

    // Persist the articulatory memory, not waveform output.
    e.setBioSpeechLesionMask(0);const auto blob=e.serializePlasticity();wb::BrainEngine restored(c);assert(restored.restorePlasticity(blob));
    assert(restored.learnedBioSpeechPrimitives()>=3);const auto again=restored.renderBioSpeech(bytes(novel));assert(again==baseline);
    const std::string missing=A+sep+"g:05ea";assert(restored.renderBioSpeech(bytes(missing)).empty());

    std::cout<<"PASS biospeech primitives="<<restored.learnedBioSpeechPrimitives()
             <<" baseline_samples="<<baseline.size()
             <<" jaw_before="<<dc.auditoryErrorBefore<<" jaw_after="<<dc.auditoryErrorAfter
             <<" cereb_after="<<dl.auditoryErrorAfter
             <<" auditory_before="<<da.auditoryErrorBefore<<" auditory_after="<<da.auditoryErrorAfter
             <<" auditory_lesion_after="<<daa.auditoryErrorAfter
             <<" s1_lesion_after="<<ds.auditoryErrorAfter
             <<" motor_auditory_lesion_after="<<dam.auditoryErrorAfter
             <<" dual_feedback_lesion_after="<<dboth.auditoryErrorAfter
             <<" compensation="<<dc.compensationMagnitude<<"\n";
}
