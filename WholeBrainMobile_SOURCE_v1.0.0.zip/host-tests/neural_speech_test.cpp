#include "wholebrain_engine.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

static std::vector<int16_t> makeVoice(int sampleRate, double seconds) {
    const size_t n = static_cast<size_t>(sampleRate * seconds);
    std::vector<int16_t> pcm(n);
    constexpr double pi = 3.14159265358979323846;
    for (size_t i=0;i<n;++i) {
        const double t = double(i)/sampleRate;
        const double attack = std::min(1.0, t/0.06);
        const double release = std::min(1.0, (seconds-t)/0.08);
        const double env = std::max(0.0,std::min(attack,release));
        const double fundamental = std::sin(2*pi*185.0*t);
        const double formant1 = 0.34*std::sin(2*pi*555.0*t);
        const double formant2 = 0.17*std::sin(2*pi*1480.0*t);
        pcm[i] = static_cast<int16_t>(std::clamp(env*(fundamental+formant1+formant2)*13500.0,-30000.0,30000.0));
    }
    return pcm;
}

static double corr(const std::vector<int16_t>& a,const std::vector<int16_t>& b) {
    const size_t n=std::min(a.size(),b.size());
    if(n<100) return 0;
    double ab=0,aa=0,bb=0;
    for(size_t i=0;i<n;++i){const double x=a[i],y=b[i];ab+=x*y;aa+=x*x;bb+=y*y;}
    return ab/std::sqrt(std::max(1.0,aa*bb));
}

int main(){
    wb::EngineConfig c; c.neurons=30000; c.fanout=64; c.seed=404;
    wb::BrainEngine e(c);
    const std::string key="שלום";
    const auto pcm=makeVoice(16000,1.1);
    for(int i=0;i<4;++i)e.step(); // leave startup refractory window
    assert(e.learnedSpeechUnits()==0);
    assert(e.learnSpeech(std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(key.data()),key.size()),pcm,16000));
    assert(e.learnedSpeechUnits()==1);
    const std::string missing="unknown";
    assert(e.renderSpeech(std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(missing.data()),missing.size())).empty());
    const auto out=e.renderSpeech(std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(key.data()),key.size()));
    assert(out.size()>10000);
    assert(corr(pcm,out)>0.92);
    for(int i=0;i<4;++i)e.step();
    const auto st=e.stats();
    assert(st.learnedSpeechUnits==1);
    assert(st.speechMemoryBytes>10000);
    assert(st.speechRenderCount==1);
    assert(st.regionSpikesPerSecond[static_cast<size_t>(wb::Region::VocalMotor)]>0.0);

    const auto blob=e.serializePlasticity();
    wb::BrainEngine restored(c);
    assert(restored.restorePlasticity(blob));
    assert(restored.learnedSpeechUnits()==1);
    const auto out2=restored.renderSpeech(std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(key.data()),key.size()));
    assert(out2==out);

    // Backward compatibility: v0.6.x v2 state ends immediately after motorDifferentiaI.
    auto legacy=blob;
    uint32_t v2=2;
    std::memcpy(legacy.data()+4,&v2,sizeof(v2));
    uint32_t assocN=0; std::memcpy(&assocN,legacy.data()+28,sizeof(assocN));
    const size_t legacyBytes=32u + size_t(assocN)*sizeof(float);
    assert(legacy.size()>=legacyBytes);
    legacy.resize(legacyBytes);
    wb::BrainEngine fromLegacy(c);
    assert(fromLegacy.restorePlasticity(legacy));
    assert(fromLegacy.learnedSpeechUnits()==0);

    restored.clearSpeech();
    assert(restored.learnedSpeechUnits()==0);
    std::cout<<"PASS neural_speech units="<<st.learnedSpeechUnits
             <<" bytes="<<st.speechMemoryBytes
             <<" corr="<<corr(pcm,out)
             <<" vocal_sps="<<st.regionSpikesPerSecond[static_cast<size_t>(wb::Region::VocalMotor)]<<"\n";
    return 0;
}
