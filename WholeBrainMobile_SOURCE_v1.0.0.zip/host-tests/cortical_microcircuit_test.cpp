#include "cortical_microcircuit.h"
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>

using namespace wb;

int main(){
    for(auto area:{CorticalAreaKind::SensoryGranular,CorticalAreaKind::Association,CorticalAreaKind::AgranularMotor}){
        const auto f=CorticalMicrocircuit::layerFractions(area);
        float sum=0; for(float x:f){assert(x>0);sum+=x;} assert(std::abs(sum-1.0f)<1e-5f);
    }
    const auto fg=CorticalMicrocircuit::layerFractions(CorticalAreaKind::SensoryGranular);
    const auto fm=CorticalMicrocircuit::layerFractions(CorticalAreaKind::AgranularMotor);
    assert(fg[static_cast<size_t>(CorticalLayer::L4)] > 4.0f*fm[static_cast<size_t>(CorticalLayer::L4)]);

    constexpr uint32_t N=200000;
    std::array<uint64_t,7> cells{}; std::array<uint64_t,5> layers{}; uint64_t exc=0;
    for(uint32_t i=0;i<N;++i){
        const auto p=CorticalMicrocircuit::phenotype(CorticalAreaKind::Association,i,N,12345);
        cells[static_cast<size_t>(p.cell)]++; layers[static_cast<size_t>(p.layer)]++; if(p.excitatory)++exc;
        const auto p2=CorticalMicrocircuit::phenotype(CorticalAreaKind::Association,i,N,12345);
        assert(p.layer==p2.layer && p.cell==p2.cell && p.excitatory==p2.excitatory);
    }
    const double exFrac=double(exc)/N;
    assert(exFrac>0.72 && exFrac<0.84);
    assert(cells[static_cast<size_t>(CorticalCellClass::ET)]>1000);
    assert(cells[static_cast<size_t>(CorticalCellClass::CT)]>1000);
    assert(cells[static_cast<size_t>(CorticalCellClass::PV)]>1000);
    assert(cells[static_cast<size_t>(CorticalCellClass::SST)]>1000);
    assert(cells[static_cast<size_t>(CorticalCellClass::VIP)]>500);
    assert(cells[static_cast<size_t>(CorticalCellClass::LAMP5)]>500);

    // Human-like agranular motor cortex must have a reduced L4 population.
    uint64_t motorL4=0, sensoryL4=0;
    for(uint32_t i=0;i<100000;++i){
        if(CorticalMicrocircuit::phenotype(CorticalAreaKind::AgranularMotor,i,100000,2).layer==CorticalLayer::L4)++motorL4;
        if(CorticalMicrocircuit::phenotype(CorticalAreaKind::SensoryGranular,i,100000,2).layer==CorticalLayer::L4)++sensoryL4;
    }
    assert(sensoryL4>4*motorL4);

    CorticalPhenotype et; et.layer=CorticalLayer::L5; et.cell=CorticalCellClass::ET; et.excitatory=true; et.dendriticGain=0.68f;
    const float basal=CorticalMicrocircuit::dendriticCoincidence(et,0.62f,0.0f);
    const float paired=CorticalMicrocircuit::dendriticCoincidence(et,0.62f,0.95f);
    assert(paired>basal+0.20f);
    const float inhibited=CorticalMicrocircuit::dendriticCoincidence(et,0.62f,-0.40f);
    assert(std::abs(inhibited-basal)<1e-6f);

    const auto pv=CorticalMicrocircuit::localRule(CorticalPhenotype{CorticalLayer::L23,CorticalCellClass::PV,false});
    const auto sst=CorticalMicrocircuit::localRule(CorticalPhenotype{CorticalLayer::L5,CorticalCellClass::SST,false});
    const auto vip=CorticalMicrocircuit::localRule(CorticalPhenotype{CorticalLayer::L23,CorticalCellClass::VIP,false});
    assert(pv.compartment==DendriticCompartment::Soma);
    assert(sst.compartment==DendriticCompartment::Apical);
    assert(vip.preferredTarget==CorticalCellClass::SST);
    assert(CorticalMicrocircuit::inhibitionScale(CorticalCellClass::VIP,CorticalCellClass::SST) >
           CorticalMicrocircuit::inhibitionScale(CorticalCellClass::VIP,CorticalCellClass::IT));

    const auto ff=CorticalMicrocircuit::longRangeRule(et,false);
    const auto fb=CorticalMicrocircuit::longRangeRule(et,true);
    assert(ff.targetLayer==CorticalLayer::L4 && ff.compartment==DendriticCompartment::Soma);
    assert(fb.compartment==DendriticCompartment::Apical);

    const uint32_t dl=CorticalMicrocircuit::conductionDelayTicks(true,8,123,1);
    const uint32_t dr=CorticalMicrocircuit::conductionDelayTicks(false,8,123,3);
    assert(dl>=1 && dl<=3 && dr>=4 && dr<=8);

    std::cout<<"PASS cortical_microcircuit exc_fraction="<<exFrac
             <<" sensory_L4="<<sensoryL4<<" motor_L4="<<motorL4
             <<" dendritic_gain="<<(paired-basal)<<" local_delay="<<dl<<" long_delay="<<dr<<"\n";
    return 0;
}
