package com.eyalshemuel.wholebrainmobile.output

/**
 * BioSpeech developmental curriculum. It starts with vowel and CV calibration, then
 * advances to words and sentences. Microphone audio is streamed into Auditory while the
 * written cue drives Language/Semantic; consolidation learns articulatory programs.
 */
object FastSpeechCurriculum {
    val hebrew: List<String> = listOf(
        "אַ אֶ אִ אֹ אֻ אְ",
        "בַ בֶ בִ בֹ בֻ",
        "מַ מֶ מִ מֹ מֻ",
        "לַ לֶ לִ לֹ לֻ",
        "נַ נֶ נִ נֹ נֻ",
        "רַ רֶ רִ רֹ רֻ",
        "שַ שֶ שִ שֹ שֻ",
        "קַ קֶ קִ קֹ קֻ",
        "תַ תֶ תִ תֹ תֻ",
        "פַ פֶ פִ פֹ פֻ",
        "אבא ואמא בבית",
        "בוקר טוב לכולם",
        "גדי קנה דג קטן",
        "דנה הלכה לגן",
        "הילד רץ מהר",
        "ורד זוהר בשמש",
        "זאב חכם טייל בחוץ",
        "חתול שחור ישן כאן",
        "טל כתב מכתב יפה",
        "ילד קטן שותה מים",
        "כלב לבן רץ בגינה",
        "לימון מתוק וחמוץ",
        "משה נסע לצפון",
        "נועה סגרה את החלון",
        "סוס עבר ליד העץ",
        "עומר פתח ספר חדש",
        "פרח צהוב גדל בחצר",
        "ציפור קטנה עפה בשקט",
        "קפה חם מוכן עכשיו",
        "רות שרה שיר קצר",
        "שלום ותודה רבה",
        "אני רוצה ללמוד לדבר",
        "אנחנו חושבים ופועלים",
        "צריך להמשיך קדימה",
        "שמאל ימין למעלה למטה",
        "היום מזג האוויר נעים",
        "בקשה פשוטה וברורה",
        "המוח לומד מכל חוויה",
        "שקט רגע ואז ממשיכים",
        "אפשר ליצור משפט חדש",
    )
}
