package com.eyalshemuel.wholebrainmobile.sensors

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.PowerManager
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.eyalshemuel.wholebrainmobile.brain.BrainController
import java.util.concurrent.Executors

class CameraBrainAnalyzer(private val context: Context, private val brain: BrainController) {
    private val executor=Executors.newSingleThreadExecutor { r ->
        Thread(r,"WholeBrain-Camera").apply { priority=(Thread.NORM_PRIORITY-1).coerceAtLeast(Thread.MIN_PRIORITY) }
    }
    private var provider: ProcessCameraProvider?=null
    private var analysisUseCase: ImageAnalysis?=null
    private var previewUseCase: Preview?=null
    private var lastVisionNs=0L
    private val retinal=ByteArray(64*36*3)

    private fun ensureAnalysis(p:ProcessCameraProvider,owner:LifecycleOwner){
        val existing=analysisUseCase
        if(existing!=null && p.isBound(existing)) return
        val analysis=existing?:ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setTargetResolution(Size(640,360))
            .build().also { useCase ->
                useCase.setAnalyzer(executor){ image -> analyze(image) }
                analysisUseCase=useCase
            }
        p.bindToLifecycle(owner,CameraSelector.DEFAULT_BACK_CAMERA,analysis)
    }

    fun bindAnalysis(owner: LifecycleOwner) {
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return
        val future=ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val p=future.get(); provider=p
                ensureAnalysis(p,owner)
            }
        },ContextCompat.getMainExecutor(context))
    }

    fun bind(owner: LifecycleOwner, previewView: PreviewView) {
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return
        val future=ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val p=future.get(); provider=p
                ensureAnalysis(p,owner)
                previewUseCase?.let { if(p.isBound(it)) p.unbind(it) }
                val preview=Preview.Builder().build().also{it.surfaceProvider=previewView.surfaceProvider}
                previewUseCase=preview
                p.bindToLifecycle(owner,CameraSelector.DEFAULT_BACK_CAMERA,preview)
            }
        },ContextCompat.getMainExecutor(context))
    }

    private fun sample(image:ImageProxy, planeIndex:Int, sx:Int, sy:Int):Int {
        val plane=image.planes.getOrNull(planeIndex)?:return if(planeIndex==0)0 else 128
        val div=if(planeIndex==0)1 else 2
        val x=(sx/div).coerceAtLeast(0)
        val y=(sy/div).coerceAtLeast(0)
        val pos=y*plane.rowStride+x*plane.pixelStride
        return if(pos in 0 until plane.buffer.limit()) plane.buffer.get(pos).toInt() and 0xFF else if(planeIndex==0)0 else 128
    }

    // Pack two non-negative coordinates into one primitive Long. This avoids allocating
    // ~20K Pair<Int,Int> objects for every retinal sample frame.
    private fun rawPointPacked(ox:Int,oy:Int,rotation:Int,srcW:Int,srcH:Int):Long {
        val sx:Int
        val sy:Int
        when(rotation){
            90 -> { sx=oy.coerceIn(0,srcW-1); sy=(srcH-1-ox).coerceIn(0,srcH-1) }
            180 -> { sx=(srcW-1-ox).coerceIn(0,srcW-1); sy=(srcH-1-oy).coerceIn(0,srcH-1) }
            270 -> { sx=(srcW-1-oy).coerceIn(0,srcW-1); sy=ox.coerceIn(0,srcH-1) }
            else -> { sx=ox.coerceIn(0,srcW-1); sy=oy.coerceIn(0,srcH-1) }
        }
        return (sx.toLong() shl 32) or (sy.toLong() and 0xffffffffL)
    }

    private fun analyze(image: ImageProxy){
        try{
            val now=SystemClock.elapsedRealtimeNanos()
            // Retinal injection is deliberately slower than preview. At K=1024 the old
            // ~10 Hz path crossed the measured recurrent-stability knee; 8 Hz stays below it.
            // Under thermal pressure, back off further instead of slowing the brain while
            // continuing to inject senses at the old wall-clock rate.
            val minPeriodNs=if(brain.thermalStatus()>=PowerManager.THERMAL_STATUS_SEVERE) 300_000_000L else 125_000_000L
            if(now-lastVisionNs<minPeriodNs)return
            lastVisionNs=now
            brain.noteCameraFrame()

            val srcW=image.width; val srcH=image.height
            val rotation=((image.imageInfo.rotationDegrees%360)+360)%360
            val orientedW=if(rotation==90||rotation==270)srcH else srcW
            val orientedH=if(rotation==90||rotation==270)srcW else srcH
            val w=64; val h=36
            val out=retinal

            for(y in 0 until h){
                val y0=y*orientedH/h
                val y1=((y+1)*orientedH/h-1).coerceAtLeast(y0)
                for(x in 0 until w){
                    val x0=x*orientedW/w
                    val x1=((x+1)*orientedW/w-1).coerceAtLeast(x0)
                    var yy=0;var uu=0;var vv=0;var taps=0
                    for(ty in 0..2) for(tx in 0..2){
                        val ox=x0+((x1-x0)*tx)/2
                        val oy=y0+((y1-y0)*ty)/2
                        val packed=rawPointPacked(ox,oy,rotation,srcW,srcH)
                        val sx=(packed ushr 32).toInt()
                        val sy=packed.toInt()
                        yy+=sample(image,0,sx,sy);uu+=sample(image,1,sx,sy);vv+=sample(image,2,sx,sy);taps++
                    }
                    val q=(y*w+x)*3
                    out[q]=(yy/taps).toByte(); out[q+1]=(uu/taps).toByte(); out[q+2]=(vv/taps).toByte()
                }
            }
            brain.injectVision(out,w,h)
        }finally{ image.close() }
    }
    fun unbind(){
        val p=provider
        if(p!=null){
            analysisUseCase?.let{runCatching{p.unbind(it)}}
            previewUseCase?.let{runCatching{p.unbind(it)}}
        }
        analysisUseCase=null;previewUseCase=null;provider=null
    }
    fun close(){unbind();executor.shutdownNow()}
}
