package com.eyalshemuel.wholebrainmobile.output

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.eyalshemuel.wholebrainmobile.brain.BrainController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * BioSpeech sensorimotor cortex actuator.
 *
 * There is deliberately no Android TextToSpeech dependency here. Teaching records real
 * microphone PCM; the native brain aligns it to sub-word motor primitives and learned
 * co-articulation and articulatory motor programs. Speaking creates a new phonological/prosodic plan,
 * drives an internal vocal-tract plant, and closes auditory/somatosensory feedback loops. AudioTrack is only the
 * physical speaker actuator. Whole-phrase PCM recall is not used by this active path.
 */
data class SpeechOutputState(
    val ready: Boolean = false,
    val synthesizing: Boolean = false, // neural recall/composition in progress
    val speaking: Boolean = false,
    val learning: Boolean = false,
    val progress: Float = 0f,
    val currentText: String = "",
    val voiceName: String = "BioSpeech Sensorimotor Cortex",
    val waveform: List<Float> = emptyList(),
    val learnedUnits: Int = 0,
    val coveragePercent: Int = 0,
    val plannedUnits: Int = 0,
    val learningText: String = "",
    val learningSeconds: Float = 0f,
    val fastLearning: Boolean = false,
    val fastIndex: Int = 0,
    val fastTotal: Int = FastSpeechCurriculum.hebrew.size,
    val missingUnits: List<String> = emptyList(),
    val error: String? = null,
)

class SpeechOutputEngine(
    private val context: Context,
    private val brain: BrainController,
) {
    private val prefs = context.getSharedPreferences("wholebrain-speech", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "WholeBrain-NeuralSpeech") }
    private val recording = AtomicBoolean(false)
    private var record: AudioRecord? = null
    private var recordThread: Thread? = null
    private var player: AudioTrack? = null
    private var playbackStartedAt = 0L
    private var playbackDurationMs = 0L
    private var fastIndex = 0
    private var fastMode = false
    private var finishedCallback: (() -> Unit)? = null
    private val sampleRate = 16_000
    private val maxRecordSeconds = 5f
    private val minRecordSeconds = 0.28f

    private val _state = MutableStateFlow(
        SpeechOutputState(
            ready = brain.learnedBioSpeechPrimitives() > 0,
            learnedUnits = brain.learnedBioSpeechPrimitives(),
            coveragePercent = coreCoverage(),
        )
    )
    val state: StateFlow<SpeechOutputState> = _state.asStateFlow()

    var actionPhrase0: String = prefs.getString("action_phrase_0", "כן") ?: "כן"
        private set
    var actionPhrase1: String = prefs.getString("action_phrase_1", "לא") ?: "לא"
        private set

    val fastPrompt: String
        get() = FastSpeechCurriculum.hebrew.getOrElse(fastIndex) { "" }

    private val progressTicker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && p.playState == AudioTrack.PLAYSTATE_PLAYING && playbackDurationMs > 0) {
                val elapsed = SystemClock.elapsedRealtime() - playbackStartedAt
                _state.value = _state.value.copy(
                    progress = (elapsed.toFloat() / playbackDurationMs).coerceIn(0f, 1f),
                    speaking = elapsed < playbackDurationMs,
                )
                if (elapsed < playbackDurationMs) main.postDelayed(this, 50)
                else finishPlayback()
            }
        }
    }

    fun refreshLearnedCount() {
        val n = brain.learnedBioSpeechPrimitives()
        _state.value = _state.value.copy(
            learnedUnits = n,
            coveragePercent = coreCoverage(),
            ready = n > 0,
        )
    }

    fun setActionPhrase(action: Int, text: String) {
        val clean = text.trim().take(160)
        if (action == 0) actionPhrase0 = clean else actionPhrase1 = clean
        prefs.edit().putString(if (action == 0) "action_phrase_0" else "action_phrase_1", clean).apply()
    }

    fun speakAction(action: Int) {
        when (action) {
            0 -> speak(actionPhrase0)
            1 -> speak(actionPhrase1)
        }
    }

    fun speak(text: String) {
        val plan = GenerativeSpeechPhonology.plan(text)
        val clean = plan.text
        if (clean.isBlank() || plan.units.isEmpty()) return
        stopPlayback()
        val missing = plan.distinctUnits.filterNot { brain.hasBioSpeechPrimitive(it.key) }
        _state.value = _state.value.copy(
            synthesizing = missing.isEmpty(),
            speaking = false,
            progress = 0f,
            currentText = clean,
            plannedUnits = plan.units.size,
            error = if (missing.isEmpty()) null else "לקורטקס חסרים פרימיטיבים: ${missing.joinToString(" ") { it.label }}",
            missingUnits = missing.map { it.label },
        )
        if (missing.isNotEmpty()) return
        worker.execute {
            val pcm = brain.renderBioSpeech(plan.wire)
            main.post {
                if (pcm.isEmpty()) {
                    _state.value = _state.value.copy(
                        synthesizing = false,
                        speaking = false,
                        error = "ה־VocalMotor לא הצליח ליצור את רצף הדיבור",
                    )
                } else {
                    playPcm(pcm, clean)
                }
            }
        }
    }

    fun stop() {
        stopLearning()
        stopPlayback()
        _state.value = _state.value.copy(synthesizing = false, speaking = false, progress = 0f)
    }

    fun beginFastLearning() {
        fastMode = true
        fastIndex = 0
        _state.value = _state.value.copy(
            fastLearning = true,
            fastIndex = fastIndex,
            fastTotal = FastSpeechCurriculum.hebrew.size,
            learningText = fastPrompt,
            error = null,
        )
    }

    fun stopFastLearning() {
        fastMode = false
        stopLearning()
        _state.value = _state.value.copy(fastLearning = false, learningText = "")
    }

    fun skipFastUnit() {
        if (!fastMode) return
        advanceFastLearning()
    }

    fun startFastUnit(onFinished: () -> Unit): Boolean {
        if (!fastMode) beginFastLearning()
        return startLearning(fastPrompt, onFinished)
    }

    fun startLearning(text: String, onFinished: () -> Unit): Boolean {
        if (recording.get()) return false
        val clean = normalize(text)
        val teachingPlan = GenerativeSpeechPhonology.plan(clean)
        if (clean.isBlank()) {
            _state.value = _state.value.copy(error = "יש להזין מילה או משפט ללמידה")
            return false
        }
        if (teachingPlan.units.isEmpty()) {
            _state.value = _state.value.copy(error = "לא נמצאו יחידות פונולוגיות ללמידה")
            return false
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _state.value = _state.value.copy(error = "נדרשת הרשאת מיקרופון ללמידת דיבור")
            return false
        }
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) {
            _state.value = _state.value.copy(error = "המיקרופון אינו זמין")
            return false
        }
        var active: AudioRecord? = null
        for (source in intArrayOf(MediaRecorder.AudioSource.UNPROCESSED, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)) {
            val candidate = runCatching {
                AudioRecord(source, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096))
            }.getOrNull() ?: continue
            if (candidate.state == AudioRecord.STATE_INITIALIZED) { active = candidate; break } else candidate.release()
        }
        val recorder = active ?: run {
            _state.value = _state.value.copy(error = "לא ניתן לפתוח זרם מיקרופון מקומי")
            return false
        }
        // Prime Language/Semantic/Association before acoustic teaching begins.
        brain.injectTeachingToken(teachingPlan.wire)
        finishedCallback = onFinished
        recording.set(true)
        record = recorder
        _state.value = _state.value.copy(
            learning = true,
            learningText = clean,
            learningSeconds = 0f,
            error = null,
        )
        recorder.startRecording()
        recordThread = thread(name = "WholeBrain-NeuralSpeechLearn", isDaemon = true) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val maxSamples = (sampleRate * maxRecordSeconds).toInt()
            val captured = ShortArray(maxSamples)
            val buf = ShortArray(512)
            var count = 0
            var speechSeen = false
            var trailingSilentSamples = 0
            val started = SystemClock.elapsedRealtime()
            var failure: Throwable? = null
            var teachingChunk = 0
            try {
                while (recording.get() && count < maxSamples) {
                    val n = recorder.read(buf, 0, minOf(buf.size, maxSamples - count), AudioRecord.READ_BLOCKING)
                    if (n <= 0) continue
                    System.arraycopy(buf, 0, captured, count, n)
                    count += n
                    // Live cortical teaching: stream ~15.6 audio chunks/s into Auditory.
                    if ((teachingChunk++ and 1) == 0) brain.injectTeachingAudio(buf.copyOf(n), sampleRate)
                    var energy = 0.0
                    for (i in 0 until n) { val v = buf[i].toDouble() / 32768.0; energy += v*v }
                    val rms = sqrt(energy / n.coerceAtLeast(1))
                    if (rms > 0.018) { speechSeen = true; trailingSilentSamples = 0 }
                    else if (speechSeen) trailingSilentSamples += n
                    val sec = (SystemClock.elapsedRealtime() - started) / 1000f
                    main.post { _state.value = _state.value.copy(learning = true, learningSeconds = sec.coerceAtMost(maxRecordSeconds)) }
                    // Fast set auto-finishes after ~650 ms of silence following speech.
                    if (fastMode && speechSeen && trailingSilentSamples >= (sampleRate * 0.65f).toInt() && sec >= 0.65f) recording.set(false)
                }
            } catch (t: Throwable) { failure = t }
            finally {
                runCatching { recorder.stop() }
                recorder.release()
                if (record === recorder) record = null
                recording.set(false)
                finalizeLearning(clean, captured.copyOf(count), failure, started)
            }
        }
        return true
    }

    fun stopLearning() {
        if (!recording.getAndSet(false)) return
        runCatching { record?.stop() }
    }

    fun clearLearnedSpeech() {
        stop()
        brain.clearSpeechMemory()
        fastMode = false
        fastIndex = 0
        _state.value = SpeechOutputState(voiceName = "BioSpeech Sensorimotor Cortex")
    }

    private fun finalizeLearning(text: String, pcm: ShortArray, failure: Throwable?, started: Long) {
        val seconds = (SystemClock.elapsedRealtime() - started) / 1000f
        var error = failure?.message
        var learned = false
        if (error == null && seconds < minRecordSeconds) error = "ההקלטה קצרה מדי"
        if (error == null && pcm.isNotEmpty()) {
            val plan = GenerativeSpeechPhonology.plan(text)
            learned = brain.learnBioSpeech(plan.wire, pcm, sampleRate)
            if (!learned) error = "המוח דחה את הדוגמה: נדרש דיבור ברור או ארוך יותר"
        }
        main.post {
            val units = brain.learnedBioSpeechPrimitives()
            _state.value = _state.value.copy(
                learning = false,
                learningSeconds = seconds,
                learnedUnits = units,
                coveragePercent = coreCoverage(),
                ready = units > 0,
                error = error,
            )
            if (learned && fastMode) advanceFastLearning()
            finishedCallback?.invoke()
            finishedCallback = null
        }
    }

    private fun advanceFastLearning() {
        fastIndex++
        if (fastIndex >= FastSpeechCurriculum.hebrew.size) {
            fastMode = false
            fastIndex = FastSpeechCurriculum.hebrew.size
            _state.value = _state.value.copy(
                fastLearning = false,
                fastIndex = fastIndex,
                learningText = "",
                learnedUnits = brain.learnedBioSpeechPrimitives(),
                coveragePercent = coreCoverage(),
                ready = brain.learnedBioSpeechPrimitives() > 0,
            )
        } else {
            _state.value = _state.value.copy(
                fastLearning = true,
                fastIndex = fastIndex,
                learningText = fastPrompt,
                learnedUnits = brain.learnedBioSpeechPrimitives(),
                coveragePercent = coreCoverage(),
                ready = brain.learnedBioSpeechPrimitives() > 0,
            )
        }
    }


    private fun playPcm(pcm: ShortArray, text: String) {
        stopPlayback()
        if (pcm.isEmpty()) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val format = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        val track = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(pcm.size * 2)
                .build()
        }.getOrElse {
            _state.value = _state.value.copy(synthesizing = false, error = "פתיחת הרמקול נכשלה: ${it.message}")
            return
        }
        val written = track.write(pcm, 0, pcm.size)
        if (written <= 0) {
            track.release()
            _state.value = _state.value.copy(synthesizing = false, error = "כתיבת PCM לרמקול נכשלה")
            return
        }
        player = track
        playbackStartedAt = SystemClock.elapsedRealtime()
        playbackDurationMs = (pcm.size * 1000L / sampleRate).coerceAtLeast(1L)
        _state.value = _state.value.copy(
            synthesizing = false,
            speaking = true,
            progress = 0f,
            currentText = text,
            waveform = waveform(pcm, 256),
            voiceName = "BioSpeech Sensorimotor Cortex · ${brain.learnedBioSpeechPrimitives()} primitives",
            learnedUnits = brain.learnedBioSpeechPrimitives(),
            coveragePercent = coreCoverage(),
            error = null,
        )
        track.play()
        main.post(progressTicker)
    }

    private fun finishPlayback() {
        val p = player ?: return
        runCatching { p.stop() }
        runCatching { p.release() }
        if (player === p) player = null
        main.removeCallbacks(progressTicker)
        _state.value = _state.value.copy(speaking = false, synthesizing = false, progress = 1f)
    }

    private fun stopPlayback() {
        main.removeCallbacks(progressTicker)
        player?.let { runCatching { it.stop() }; runCatching { it.release() } }
        player = null
        playbackDurationMs = 0
    }

    private fun waveform(pcm: ShortArray, bins: Int): List<Float> {
        if (pcm.isEmpty() || bins <= 0) return emptyList()
        val out = ArrayList<Float>(bins)
        for (b in 0 until bins) {
            val a = b * pcm.size / bins
            val z = ((b + 1) * pcm.size / bins).coerceAtLeast(a + 1).coerceAtMost(pcm.size)
            var peak = 0
            for (i in a until z) peak = maxOf(peak, abs(pcm[i].toInt()))
            out += peak / 32768f
        }
        return out
    }

    private fun coreCoverage(): Int {
        val core = GenerativeSpeechPhonology.coreHebrewUnits
        if (core.isEmpty()) return 0
        val learned = core.count { brain.hasBioSpeechPrimitive(it.key) }
        return ((learned * 100f) / core.size).toInt().coerceIn(0, 100)
    }

    private fun normalize(text: String): String = GenerativeSpeechPhonology.normalize(text)

    fun close() {
        stop()
        worker.shutdownNow()
    }
}
