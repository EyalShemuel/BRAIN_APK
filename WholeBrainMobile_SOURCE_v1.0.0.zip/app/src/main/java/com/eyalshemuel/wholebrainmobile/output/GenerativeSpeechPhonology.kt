package com.eyalshemuel.wholebrainmobile.output

import java.text.Normalizer
import java.util.Locale

/**
 * Lightweight cortical speech planner.
 *
 * This is intentionally not a TTS front-end. It does not choose an external voice or
 * synthesize audio. It turns text into stable sub-word motor symbols plus timing/prosody
 * controls. The native brain learns the acoustic realization of those symbols directly
 * from microphone examples and later generates PCM from the learned VocalMotor state.
 *
 * Hebrew final forms are collapsed to their base grapheme so learning transfers between
 * medial/final positions. Pointed Hebrew teaches explicit vowel motor units (a/e/i/o/u/schwa). Unpointed text still
 * relies on learned co-articulation/context, so this remains a learned approximation rather
 * than a hidden pronunciation dictionary.
 */
data class SpeechMotorUnit(val key: String, val label: String)

data class SpeechMotorPlan(
    val text: String,
    val wire: ByteArray,
    val units: List<SpeechMotorUnit>,
) {
    val distinctUnits: List<SpeechMotorUnit>
        get() = units.distinctBy { it.key }
}

object GenerativeSpeechPhonology {
    private const val SEP = '\u001f'

    private val finalForms = mapOf(
        'ך' to 'כ', 'ם' to 'מ', 'ן' to 'נ', 'ף' to 'פ', 'ץ' to 'צ'
    )

    private val vowelMarks: Map<Char, SpeechMotorUnit> = mapOf(
        '\u05B0' to SpeechMotorUnit("v:schwa", "ְ"),
        '\u05B1' to SpeechMotorUnit("v:e", "ֱ"),
        '\u05B2' to SpeechMotorUnit("v:a", "ֲ"),
        '\u05B3' to SpeechMotorUnit("v:o", "ֳ"),
        '\u05B4' to SpeechMotorUnit("v:i", "ִ"),
        '\u05B5' to SpeechMotorUnit("v:e", "ֵ"),
        '\u05B6' to SpeechMotorUnit("v:e", "ֶ"),
        '\u05B7' to SpeechMotorUnit("v:a", "ַ"),
        '\u05B8' to SpeechMotorUnit("v:a", "ָ"),
        '\u05B9' to SpeechMotorUnit("v:o", "ֹ"),
        '\u05BB' to SpeechMotorUnit("v:u", "ֻ"),
        '\u05C7' to SpeechMotorUnit("v:o", "ׇ"),
    )

    val coreHebrewUnits: List<SpeechMotorUnit> =
        ("אבגדהוזחטיכלמנסעפצקרשת".map { unitForChar(it) } +
         listOf("v:a" to "ַ", "v:e" to "ֶ", "v:i" to "ִ", "v:o" to "ֹ", "v:u" to "ֻ", "v:schwa" to "ְ")
             .map { SpeechMotorUnit(it.first, it.second) }).distinctBy { it.key }

    fun normalize(text: String): String = Normalizer.normalize(text, Normalizer.Form.NFKC)
        .trim()
        .lowercase(Locale.ROOT)
        .replace(Regex("\\s+"), " ")
        .take(500)

    fun plan(raw: String): SpeechMotorPlan {
        val text = normalize(raw)
        if (text.isBlank()) return SpeechMotorPlan(text, ByteArray(0), emptyList())
        val tokens = ArrayList<String>(text.length * 2)
        val units = ArrayList<SpeechMotorUnit>(text.length)
        var boundaryPending = false

        fun flushWordBoundary() {
            if (boundaryPending && tokens.isNotEmpty() && tokens.last() != "#w") tokens += "#w"
            boundaryPending = false
        }

        text.forEach { original ->
            val type = Character.getType(original.code)
            if (type == Character.NON_SPACING_MARK.toInt() ||
                type == Character.COMBINING_SPACING_MARK.toInt() ||
                type == Character.ENCLOSING_MARK.toInt()) {
                // Explicit vowel motor units let pointed teaching examples calibrate the
                // articulatory plant. Dagesh/cantillation remain contextual modifiers.
                vowelMarks[original]?.let { vowel ->
                    flushWordBoundary()
                    tokens += vowel.key
                    units += vowel
                }
                return@forEach
            }
            when {
                original.isLetterOrDigit() -> {
                    flushWordBoundary()
                    val canonical = finalForms[original] ?: original
                    val unit = unitForChar(canonical)
                    tokens += unit.key
                    units += unit
                }
                original.isWhitespace() -> boundaryPending = true
                original == '?' || original == '؟' -> {
                    boundaryPending = false
                    if (tokens.lastOrNull() == "#w") tokens.removeAt(tokens.lastIndex)
                    tokens += "#q"
                }
                original == '!' -> {
                    boundaryPending = false
                    if (tokens.lastOrNull() == "#w") tokens.removeAt(tokens.lastIndex)
                    tokens += "#e"
                }
                original == '.' -> {
                    boundaryPending = false
                    if (tokens.lastOrNull() == "#w") tokens.removeAt(tokens.lastIndex)
                    tokens += "#p"
                }
                original == ',' || original == ';' || original == ':' || original == '،' -> {
                    boundaryPending = false
                    if (tokens.lastOrNull() == "#w") tokens.removeAt(tokens.lastIndex)
                    tokens += "#c"
                }
                else -> boundaryPending = true
            }
        }
        while (tokens.lastOrNull() == "#w") tokens.removeAt(tokens.lastIndex)
        val wire = tokens.joinToString(SEP.toString()).toByteArray(Charsets.US_ASCII)
        return SpeechMotorPlan(text, wire, units)
    }

    private fun unitForChar(c: Char): SpeechMotorUnit {
        val key = "g:${c.code.toString(16).padStart(4, '0')}"
        return SpeechMotorUnit(key, c.toString())
    }
}
