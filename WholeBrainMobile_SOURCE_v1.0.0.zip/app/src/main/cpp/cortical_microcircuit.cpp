#include "cortical_microcircuit.h"
#include <algorithm>
#include <cmath>
#include <numeric>

namespace wb {
namespace {
uint64_t mix(uint64_t x) {
    x += 0x9E3779B97F4A7C15ull;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
    return x ^ (x >> 31);
}

CorticalCellClass inhibitoryClass(CorticalLayer layer, uint64_t h) {
    const uint32_t q = static_cast<uint32_t>((h >> 24) % 1000u);
    switch (layer) {
        case CorticalLayer::L1:
            if (q < 680) return CorticalCellClass::LAMP5;
            if (q < 900) return CorticalCellClass::VIP;
            return CorticalCellClass::SST;
        case CorticalLayer::L23:
            if (q < 360) return CorticalCellClass::PV;
            if (q < 620) return CorticalCellClass::SST;
            if (q < 850) return CorticalCellClass::VIP;
            return CorticalCellClass::LAMP5;
        case CorticalLayer::L4:
            if (q < 500) return CorticalCellClass::PV;
            if (q < 800) return CorticalCellClass::SST;
            if (q < 930) return CorticalCellClass::VIP;
            return CorticalCellClass::LAMP5;
        case CorticalLayer::L5:
            if (q < 430) return CorticalCellClass::PV;
            if (q < 800) return CorticalCellClass::SST;
            if (q < 920) return CorticalCellClass::VIP;
            return CorticalCellClass::LAMP5;
        case CorticalLayer::L6:
        default:
            if (q < 420) return CorticalCellClass::PV;
            if (q < 820) return CorticalCellClass::SST;
            if (q < 910) return CorticalCellClass::VIP;
            return CorticalCellClass::LAMP5;
    }
}

CorticalPhenotype intrinsic(CorticalLayer layer, CorticalCellClass cell, bool exc) {
    CorticalPhenotype p; p.layer=layer; p.cell=cell; p.excitatory=exc;
    switch (cell) {
        case CorticalCellClass::IT:
            p.membraneDecay=0.905f; p.thresholdScale=1.00f; p.refractoryTicks=2;
            p.adaptationIncrement=0.055f; p.adaptationDecay=0.986f; p.apicalDecay=0.945f;
            p.dendriticGain=(layer==CorticalLayer::L5?0.42f:0.28f); break;
        case CorticalCellClass::ET:
            p.membraneDecay=0.918f; p.thresholdScale=1.03f; p.refractoryTicks=2;
            p.adaptationIncrement=0.075f; p.adaptationDecay=0.988f; p.apicalDecay=0.955f;
            p.dendriticGain=0.68f; break;
        case CorticalCellClass::CT:
            p.membraneDecay=0.914f; p.thresholdScale=1.04f; p.refractoryTicks=2;
            p.adaptationIncrement=0.065f; p.adaptationDecay=0.988f; p.apicalDecay=0.952f;
            p.dendriticGain=0.50f; break;
        case CorticalCellClass::PV:
            p.membraneDecay=0.83f; p.thresholdScale=0.86f; p.refractoryTicks=1;
            p.adaptationIncrement=0.015f; p.adaptationDecay=0.970f; p.apicalDecay=0.90f; p.dendriticGain=0.0f; break;
        case CorticalCellClass::SST:
            p.membraneDecay=0.90f; p.thresholdScale=0.95f; p.refractoryTicks=2;
            p.adaptationIncrement=0.04f; p.adaptationDecay=0.982f; p.apicalDecay=0.94f; p.dendriticGain=0.0f; break;
        case CorticalCellClass::VIP:
            p.membraneDecay=0.885f; p.thresholdScale=0.90f; p.refractoryTicks=2;
            p.adaptationIncrement=0.03f; p.adaptationDecay=0.978f; p.apicalDecay=0.93f; p.dendriticGain=0.0f; break;
        case CorticalCellClass::LAMP5:
        default:
            p.membraneDecay=0.925f; p.thresholdScale=0.98f; p.refractoryTicks=2;
            p.adaptationIncrement=0.035f; p.adaptationDecay=0.984f; p.apicalDecay=0.955f; p.dendriticGain=0.0f; break;
    }
    return p;
}
}

std::array<float,5> CorticalMicrocircuit::layerFractions(CorticalAreaKind area) {
    switch (area) {
        case CorticalAreaKind::SensoryGranular: return {0.05f,0.30f,0.20f,0.20f,0.25f};
        case CorticalAreaKind::AgranularMotor:   return {0.06f,0.38f,0.04f,0.27f,0.25f};
        case CorticalAreaKind::Association:
        default:                                return {0.06f,0.34f,0.12f,0.22f,0.26f};
    }
}

uint32_t CorticalMicrocircuit::layerBegin(CorticalAreaKind area, CorticalLayer layer, uint32_t population) {
    const auto f=layerFractions(area); float c=0.0f;
    for(uint32_t i=0;i<static_cast<uint32_t>(layer);++i)c+=f[i];
    return std::min(population,static_cast<uint32_t>(std::floor(c*population)));
}
uint32_t CorticalMicrocircuit::layerEnd(CorticalAreaKind area, CorticalLayer layer, uint32_t population) {
    if(layer==CorticalLayer::L6) return population;
    const auto f=layerFractions(area); float c=0.0f;
    for(uint32_t i=0;i<=static_cast<uint32_t>(layer);++i)c+=f[i];
    return std::min(population,static_cast<uint32_t>(std::floor(c*population)));
}

CorticalPhenotype CorticalMicrocircuit::phenotype(CorticalAreaKind area, uint32_t localIndex, uint32_t population, uint64_t seed) {
    if(!population) return intrinsic(CorticalLayer::L23,CorticalCellClass::IT,true);
    localIndex=std::min(localIndex,population-1);
    CorticalLayer layer=CorticalLayer::L6;
    for(uint32_t l=0;l<5;++l){
        auto L=static_cast<CorticalLayer>(l);
        if(localIndex<layerEnd(area,L,population)){layer=L;break;}
    }
    const uint64_t h=mix(seed ^ (uint64_t(localIndex)<<1) ^ uint64_t(population)*0xD6E8FEB86659FD93ull);
    float excFrac=0.80f;
    if(layer==CorticalLayer::L1) excFrac=0.04f;
    else if(layer==CorticalLayer::L23) excFrac=0.82f;
    else if(layer==CorticalLayer::L4) excFrac=0.84f;
    else if(layer==CorticalLayer::L5) excFrac=0.80f;
    else if(layer==CorticalLayer::L6) excFrac=0.79f;
    const bool exc=(h & 0xFFFFu)<static_cast<uint64_t>(excFrac*65535.0f);
    if(!exc) return intrinsic(layer,inhibitoryClass(layer,h),false);
    CorticalCellClass cls=CorticalCellClass::IT;
    const uint32_t q=static_cast<uint32_t>((h>>16)%1000u);
    if(layer==CorticalLayer::L5 && q>=620) cls=CorticalCellClass::ET;
    else if(layer==CorticalLayer::L6 && q>=420) cls=CorticalCellClass::CT;
    return intrinsic(layer,cls,true);
}

CorticalSynapseRule CorticalMicrocircuit::localRule(const CorticalPhenotype& src) {
    CorticalSynapseRule r;
    switch(src.cell){
        case CorticalCellClass::PV:
            r.targetLayer=src.layer; r.preferredTarget=CorticalCellClass::IT; r.compartment=DendriticCompartment::Soma; r.weightScale=1.20f; break;
        case CorticalCellClass::SST:
            r.targetLayer=(src.layer==CorticalLayer::L23?CorticalLayer::L23:CorticalLayer::L5); r.preferredTarget=CorticalCellClass::IT; r.compartment=DendriticCompartment::Apical; r.weightScale=0.95f; break;
        case CorticalCellClass::VIP:
            r.targetLayer=CorticalLayer::L23; r.preferredTarget=CorticalCellClass::SST; r.compartment=DendriticCompartment::Soma; r.weightScale=0.82f; break;
        case CorticalCellClass::LAMP5:
            r.targetLayer=CorticalLayer::L23; r.preferredTarget=CorticalCellClass::IT; r.compartment=DendriticCompartment::Apical; r.weightScale=0.78f; break;
        case CorticalCellClass::ET:
            r.targetLayer=CorticalLayer::L6; r.preferredTarget=CorticalCellClass::CT; r.compartment=DendriticCompartment::Soma; r.weightScale=1.02f; break;
        case CorticalCellClass::CT:
            r.targetLayer=CorticalLayer::L4; r.preferredTarget=CorticalCellClass::IT; r.compartment=DendriticCompartment::Soma; r.weightScale=0.92f; break;
        case CorticalCellClass::IT:
        default:
            if(src.layer==CorticalLayer::L4) r.targetLayer=CorticalLayer::L23;
            else if(src.layer==CorticalLayer::L23) r.targetLayer=CorticalLayer::L5;
            else if(src.layer==CorticalLayer::L5) r.targetLayer=CorticalLayer::L23;
            else r.targetLayer=CorticalLayer::L23;
            r.preferredTarget=CorticalCellClass::IT; r.compartment=DendriticCompartment::Soma; r.weightScale=1.0f; break;
    }
    return r;
}

CorticalSynapseRule CorticalMicrocircuit::longRangeRule(const CorticalPhenotype&, bool feedback) {
    CorticalSynapseRule r;
    if(feedback){
        r.targetLayer=CorticalLayer::L23; r.preferredTarget=CorticalCellClass::IT;
        r.compartment=DendriticCompartment::Apical; r.weightScale=0.72f;
    }else{
        r.targetLayer=CorticalLayer::L4; r.preferredTarget=CorticalCellClass::IT;
        r.compartment=DendriticCompartment::Soma; r.weightScale=0.88f;
    }
    return r;
}

float CorticalMicrocircuit::dendriticCoincidence(const CorticalPhenotype& p, float soma, float apical) {
    if(!p.excitatory || p.dendriticGain<=0.0f || apical<=0.0f) return soma;
    const float basalGate=std::clamp((soma-0.18f)/0.45f,0.0f,1.0f);
    const float apicalGate=std::clamp((apical-0.08f)/0.42f,0.0f,1.0f);
    return soma + p.dendriticGain*basalGate*apicalGate;
}

float CorticalMicrocircuit::inhibitionScale(CorticalCellClass src, CorticalCellClass dst) {
    if(src==CorticalCellClass::VIP) return dst==CorticalCellClass::SST?1.45f:(dst==CorticalCellClass::PV?0.80f:0.22f);
    if(src==CorticalCellClass::PV) return (dst==CorticalCellClass::IT||dst==CorticalCellClass::ET||dst==CorticalCellClass::CT)?1.22f:0.72f;
    if(src==CorticalCellClass::SST) return (dst==CorticalCellClass::IT||dst==CorticalCellClass::ET||dst==CorticalCellClass::CT)?1.05f:0.65f;
    if(src==CorticalCellClass::LAMP5) return (dst==CorticalCellClass::IT||dst==CorticalCellClass::ET)?0.90f:0.55f;
    return 1.0f;
}

uint32_t CorticalMicrocircuit::conductionDelayTicks(bool local, uint32_t recurrentDelayMax, uint64_t hash, uint32_t hierarchyDistance) {
    recurrentDelayMax=std::max<uint32_t>(1,recurrentDelayMax);
    if(local) return 1u + static_cast<uint32_t>(hash % std::min<uint32_t>(3,recurrentDelayMax));
    const uint32_t base=std::min<uint32_t>(recurrentDelayMax,1u+std::min<uint32_t>(4,hierarchyDistance));
    const uint32_t room=recurrentDelayMax>=base?recurrentDelayMax-base:0;
    return base + (room?static_cast<uint32_t>((hash>>17)%(room+1)):0u);
}

bool CorticalMicrocircuit::classMatches(const CorticalPhenotype& p, CorticalCellClass wanted){
    if(wanted==CorticalCellClass::IT && p.excitatory) return p.cell==CorticalCellClass::IT || p.cell==CorticalCellClass::ET || p.cell==CorticalCellClass::CT;
    return p.cell==wanted;
}

} // namespace wb
