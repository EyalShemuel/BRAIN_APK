#include "biospeech_model.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstring>
#include <limits>
#include <numeric>

namespace wb {
namespace {
constexpr uint32_t kMagic = 0x42535031u; // BSP1
constexpr uint32_t kVersion = 1;
constexpr double kPi = 3.14159265358979323846;

template <typename T>
void append(std::vector<uint8_t>& out, const T& v) {
    const auto* p = reinterpret_cast<const uint8_t*>(&v);
    out.insert(out.end(), p, p + sizeof(T));
}

template <typename T>
bool read(std::span<const uint8_t> blob, size_t& off, T& v) {
    if (off + sizeof(T) > blob.size()) return false;
    std::memcpy(&v, blob.data() + off, sizeof(T));
    off += sizeof(T);
    return true;
}

float clamp01(float v) { return std::clamp(v, 0.0f, 1.0f); }
float clamp11(float v) { return std::clamp(v, -1.0f, 1.0f); }

bool boundary(const std::string& t) { return !t.empty() && t[0] == '#'; }

std::array<float,3> estimateFormants(const std::array<float,10>& a) {
    struct Peak { float mag; float hz; };
    std::vector<Peak> peaks;
    peaks.reserve(80);
    float prev2 = 0.0f, prev1 = 0.0f;
    float prevHz = 200.0f;
    for (int hz=200; hz<=3600; hz+=40) {
        const double w = 2.0*kPi*double(hz)/16000.0;
        std::complex<double> den(1.0,0.0);
        for (size_t k=0;k<a.size();++k) {
            const double ang = -w*double(k+1);
            den -= double(a[k])*std::complex<double>(std::cos(ang),std::sin(ang));
        }
        const float mag = static_cast<float>(1.0/std::max(1e-5,std::abs(den)));
        if (prev1 > prev2 && prev1 > mag) peaks.push_back({prev1,prevHz});
        prev2=prev1; prev1=mag; prevHz=float(hz);
    }
    std::sort(peaks.begin(),peaks.end(),[](const Peak& x,const Peak& y){return x.mag>y.mag;});
    std::array<float,3> f{500.0f,1500.0f,2500.0f};
    std::vector<float> chosen;
    for (const auto& p:peaks) {
        bool far=true; for(float c:chosen) if(std::abs(c-p.hz)<250.0f) far=false;
        if(far){chosen.push_back(p.hz); if(chosen.size()==3) break;}
    }
    if(!chosen.empty()) {
        std::sort(chosen.begin(),chosen.end());
        for(size_t i=0;i<std::min<size_t>(3,chosen.size());++i) f[i]=chosen[i];
        if(chosen.size()==1){f[1]=std::max(1000.0f,f[0]+700.0f);f[2]=std::max(2200.0f,f[1]+800.0f);}
        else if(chosen.size()==2){f[2]=std::max(2200.0f,f[1]+800.0f);}
    }
    f[0]=std::clamp(f[0],200.0f,1100.0f);
    f[1]=std::clamp(f[1],650.0f,3000.0f);
    f[2]=std::clamp(f[2],1800.0f,3800.0f);
    return f;
}
}

uint64_t BioSpeechModel::mix64(uint64_t x) {
    x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27; x *= 0x94d049bb133111ebULL;
    x ^= x >> 31; return x;
}

uint64_t BioSpeechModel::hashUnit(std::span<const uint8_t> unit) {
    uint64_t h=0xB105F33DULL;
    for(uint8_t b:unit) h=mix64(h ^ (uint64_t(b)+0x9e3779b97f4a7c15ULL));
    return h;
}

uint64_t BioSpeechModel::transitionKey(uint64_t a,uint64_t b) {
    return mix64(a ^ (b+0x9e3779b97f4a7c15ULL+(a<<6)+(a>>2)));
}

std::vector<std::string> BioSpeechModel::planTokens(std::span<const uint8_t> plan) {
    std::vector<std::string> out; std::string cur;
    for(uint8_t b:plan) {
        if(b==0x1f){ if(!cur.empty()){out.push_back(cur);cur.clear();} }
        else if(b>=0x20 && b<0x7f) cur.push_back(char(b));
    }
    if(!cur.empty()) out.push_back(cur);
    return out;
}

std::vector<int16_t> BioSpeechModel::canonicalPcm(std::span<const int16_t> pcm,int sampleRate) {
    if(pcm.size()<160 || sampleRate<8000 || sampleRate>96000) return {};
    int peak=0; for(int16_t v:pcm) peak=std::max(peak,std::abs(int(v)));
    if(peak<192) return {};
    size_t first=0,last=pcm.size(); const int threshold=std::max(128,peak/40);
    while(first<last && std::abs(int(pcm[first]))<threshold) ++first;
    while(last>first && std::abs(int(pcm[last-1]))<threshold) --last;
    if(last<=first) return {};
    const size_t pad=size_t(sampleRate/40); first=first>pad?first-pad:0; last=std::min(pcm.size(),last+pad);
    const size_t n=last-first;
    size_t dst=size_t(std::llround(double(n)*kRate/double(sampleRate)));
    dst=std::clamp<size_t>(dst,160,kRate*15);
    std::vector<int16_t> out(dst);
    for(size_t i=0;i<dst;++i){
        const double pos=double(i)*sampleRate/double(kRate); const size_t a=std::min(n-1,size_t(pos));
        const size_t b=std::min(n-1,a+1); const double f=pos-double(a);
        out[i]=int16_t(std::clamp((1.0-f)*pcm[first+a]+f*pcm[first+b],-32767.0,32767.0));
    }
    return out;
}

std::vector<BioSpeechModel::AuditoryTarget> BioSpeechModel::analyze(std::span<const int16_t> pcm) {
    std::vector<AuditoryTarget> out;
    if(pcm.empty()) return out;
    const size_t count=std::min(kMaxFrames,std::max<size_t>(1,(pcm.size()+kHop-1)/kHop));
    out.reserve(count);
    std::array<double,kWindow> x{};
    for(size_t fi=0;fi<count;++fi){
        const size_t start=fi*kHop; double rms=0.0;
        for(int n=0;n<kWindow;++n){
            const size_t idx=start+size_t(n); const double raw=idx<pcm.size()?double(pcm[idx])/32768.0:0.0;
            const double w=0.54-0.46*std::cos(2.0*kPi*double(n)/double(kWindow-1)); x[n]=raw*w; rms+=raw*raw;
        }
        rms=std::sqrt(rms/double(kWindow));
        AuditoryTarget t; t.rms=float(std::clamp(rms,0.0,0.95));
        int bestLag=0; double best=0.0;
        for(int lag=40;lag<=266;++lag){
            double c=0,aa=0,bb=0; for(int n=lag;n<kWindow;++n){c+=x[n]*x[n-lag];aa+=x[n]*x[n];bb+=x[n-lag]*x[n-lag];}
            const double q=c/std::sqrt(std::max(1e-12,aa*bb)); if(q>best){best=q;bestLag=lag;}
        }
        t.voiced=float(std::clamp((best-0.16)/0.64,0.0,1.0));
        t.f0=(bestLag>0 && t.voiced>0.10f)?float(kRate/double(bestLag)):0.0f;

        std::array<double,kLpcOrder+1> r{};
        for(int k=0;k<=kLpcOrder;++k){double acc=0;for(int n=k;n<kWindow;++n)acc+=x[n]*x[n-k];r[k]=acc;}
        std::array<double,kLpcOrder+1> a{};a[0]=1.0;double err=std::max(r[0],1e-9);
        for(int i=1;i<=kLpcOrder;++i){
            double acc=r[i];for(int j=1;j<i;++j)acc-=a[j]*r[i-j];
            const double refl=std::clamp(acc/std::max(err,1e-9),-0.92,0.92);auto next=a;next[i]=refl;
            for(int j=1;j<i;++j) next[j]=a[j]-refl*a[i-j];
            a=next;
            err*=std::max(0.08,1.0-refl*refl);
        }
        std::array<float,kLpcOrder> af{};for(int k=0;k<kLpcOrder;++k)af[k]=float(a[k+1]);
        const auto form=estimateFormants(af);t.f1=form[0];t.f2=form[1];t.f3=form[2];
        // Low F1 with a strong low-frequency envelope is a useful coarse nasal cue.
        t.nasal=clamp01(float((650.0-t.f1)/500.0)*0.35f + (1.0f-t.voiced)*0.08f);
        out.push_back(t);
    }
    return out;
}

BioSpeechModel::MotorCommand BioSpeechModel::clampMotor(MotorCommand c){
    c.tongueX=clamp11(c.tongueX);c.tongueY=clamp11(c.tongueY);c.tongueTip=clamp11(c.tongueTip);
    c.jaw=clamp01(c.jaw);c.lipAperture=clamp01(c.lipAperture);c.lipRound=clamp01(c.lipRound);c.velum=clamp01(c.velum);
    c.glottalTension=clamp01(c.glottalTension);c.adduction=clamp01(c.adduction);c.pressure=clamp01(c.pressure);return c;
}

BioSpeechModel::PlantState BioSpeechModel::plant(const MotorCommand& command){
    PlantState s; s.actual=clampMotor(command); const auto& m=s.actual; auto& a=s.acoustic;
    a.f0=75.0f+285.0f*m.glottalTension;
    a.rms=0.015f+0.68f*m.pressure*(0.35f+0.65f*m.adduction);
    a.voiced=clamp01(0.08f+0.92f*m.adduction);
    // Coarse articulatory-to-formant plant. It is continuous and invertible enough for
    // closed-loop learning, but intentionally remains a simplified biomechanical proxy.
    a.f1=250.0f+620.0f*m.jaw+180.0f*m.lipAperture+170.0f*(1.0f-(m.tongueY+1.0f)*0.5f)+110.0f*m.velum;
    a.f2=900.0f+1250.0f*((m.tongueX+1.0f)*0.5f)+220.0f*m.tongueTip-430.0f*m.lipRound-110.0f*m.jaw;
    a.f3=2100.0f+520.0f*(1.0f-m.lipRound)+230.0f*m.tongueTip+120.0f*m.lipAperture;
    a.f1=std::clamp(a.f1,200.0f,1200.0f);a.f2=std::clamp(a.f2,650.0f,3100.0f);a.f3=std::clamp(a.f3,1800.0f,3900.0f);
    a.nasal=clamp01(m.velum);
    return s;
}

BioSpeechModel::MotorCommand BioSpeechModel::inverseArticulation(const AuditoryTarget& t){
    MotorCommand m;
    m.glottalTension=clamp01((t.f0-75.0f)/285.0f);
    m.adduction=clamp01((t.voiced-0.08f)/0.92f);
    m.pressure=clamp01((t.rms-0.015f)/0.68f/std::max(0.35f,0.35f+0.65f*m.adduction));
    m.velum=clamp01(t.nasal);
    m.jaw=clamp01(0.30f + 0.55f*clamp01((t.f1-300.0f)/760.0f));
    m.lipAperture=clamp01(0.25f+0.45f*m.jaw);
    m.lipRound=clamp01((2750.0f-t.f3)/850.0f);
    m.tongueX=clamp11(((t.f2+430.0f*m.lipRound+110.0f*m.jaw-900.0f)/1250.0f)*2.0f-1.0f);
    m.tongueTip=clamp11((t.f3-2450.0f+520.0f*m.lipRound)/420.0f);
    m.tongueY=clamp11(1.0f-2.0f*clamp01((t.f1-250.0f-620.0f*m.jaw-180.0f*m.lipAperture-110.0f*m.velum)/170.0f));
    // Four local forward-model correction passes approximate cerebellar calibration.
    for(int i=0;i<4;++i){
        const auto p=plant(m).acoustic;
        m.jaw += (t.f1-p.f1)/900.0f*0.45f;
        m.tongueY -= (t.f1-p.f1)/900.0f*0.18f;
        m.tongueX += (t.f2-p.f2)/1500.0f*0.42f;
        m.lipRound -= (t.f2-p.f2)/1500.0f*0.15f;
        m.tongueTip += (t.f3-p.f3)/1200.0f*0.25f;
        m.lipRound -= (t.f3-p.f3)/1200.0f*0.18f;
        m=clampMotor(m);
    }
    // Keep a physiologic operating margin so mechanical perturbations can be
    // compensated in both opening and closing directions instead of saturating at 0/1.
    m.jaw=std::clamp(m.jaw,0.20f,0.90f);
    m.lipAperture=std::clamp(m.lipAperture,0.08f,0.95f);
    return m;
}

double BioSpeechModel::auditoryError(const AuditoryTarget& a,const AuditoryTarget& b){
    const double e0=(a.f0-b.f0)/220.0, e1=(a.f1-b.f1)/700.0, e2=(a.f2-b.f2)/1400.0, e3=(a.f3-b.f3)/1500.0;
    const double er=(a.rms-b.rms)/0.5, ev=(a.voiced-b.voiced), en=(a.nasal-b.nasal);
    return std::sqrt((e0*e0+e1*e1+e2*e2+e3*e3+er*er+ev*ev+0.5*en*en)/6.5);
}

BioSpeechModel::MotorCommand BioSpeechModel::adapt(const MotorCommand& planned,const AuditoryTarget& desired,
    const Perturbation& perturbation,uint32_t lesionMask,double* before,double* after,double* somato,double* comp){
    (void)desired; // offline learning calibrated `planned`; online feedback predicts its sensory consequence.
    const AuditoryTarget expected=plant(planned).acoustic;
    MotorCommand actual0=planned;
    actual0.jaw=clamp01(actual0.jaw+perturbation.jawOffset);
    auto sensed0=plant(actual0).acoustic;
    sensed0.f1+=perturbation.auditoryF1ShiftHz;
    sensed0.f2+=perturbation.auditoryF2ShiftHz;
    if(before) *before=auditoryError(expected,sensed0);
    if(somato) *somato=std::abs(double(actual0.jaw-planned.jaw));

    MotorCommand corrected=planned;
    if(!(lesionMask&LesionCerebellum)){
        // The fast loop tries to restore the predicted sensory consequence of the motor
        // program, while slow learning has already calibrated that motor program to the
        // teacher. Auditory and somatosensory channels can compensate independently.
        for(int iter=0;iter<4;++iter){
            MotorCommand actual=corrected;
            actual.jaw=clamp01(actual.jaw+perturbation.jawOffset);
            auto sensed=plant(actual).acoustic;
            sensed.f1+=perturbation.auditoryF1ShiftHz;
            sensed.f2+=perturbation.auditoryF2ShiftHz;

            if(!(lesionMask&LesionSomatosensory)) {
                // S1/proprioceptive feedback corrects the *remaining* mechanical
                // displacement, not the original disturbance on every pass.  This
                // prevents fixed-gain over-correction and models a residual closed loop.
                const float jawResidual=actual.jaw-planned.jaw;
                corrected.jaw -= jawResidual*0.62f;
            }
            if(!(lesionMask&LesionAuditory)){
                const float e1=expected.f1-sensed.f1;
                const float e2=expected.f2-sensed.f2;
                const float e3=expected.f3-sensed.f3;
                corrected.jaw += e1/900.0f*0.52f;
                corrected.tongueY -= e1/900.0f*0.18f;
                corrected.tongueX += e2/1500.0f*0.48f;
                corrected.lipRound -= e2/1500.0f*0.18f;
                corrected.tongueTip += e3/1500.0f*0.22f;
                corrected.lipRound -= e3/1500.0f*0.15f;
            }
            corrected=clampMotor(corrected);
        }
    }
    MotorCommand actual2=corrected;
    actual2.jaw=clamp01(actual2.jaw+perturbation.jawOffset);
    auto sensed2=plant(actual2).acoustic;
    sensed2.f1+=perturbation.auditoryF1ShiftHz;
    sensed2.f2+=perturbation.auditoryF2ShiftHz;
    if(after) *after=auditoryError(expected,sensed2);
    if(comp){
        *comp=std::abs(double(corrected.jaw-planned.jaw))+
              std::abs(double(corrected.tongueX-planned.tongueX))+
              std::abs(double(corrected.lipRound-planned.lipRound));
    }
    return corrected;
}

BioSpeechModel::Primitive BioSpeechModel::makePrimitive(std::span<const int16_t> segment){
    Primitive p; const auto targets=analyze(segment);p.frames.reserve(targets.size());
    for(const auto& t:targets)p.frames.push_back({t,inverseArticulation(t)});
    return p;
}

void BioSpeechModel::averagePrimitive(Primitive& dst,const Primitive& src){
    if(dst.frames.empty()){dst=src;return;} if(src.frames.empty())return;
    const uint16_t old=dst.observations; const uint16_t next=std::min<uint16_t>(16,old+1); const float alpha=1.0f/float(next);
    const size_t n=std::min(dst.frames.size(),src.frames.size());
    auto mix=[&](float& a,float b){a+=(b-a)*alpha;};
    for(size_t i=0;i<n;++i){auto& d=dst.frames[i];const auto& s=src.frames[i];
        mix(d.target.f0,s.target.f0);mix(d.target.rms,s.target.rms);mix(d.target.voiced,s.target.voiced);mix(d.target.f1,s.target.f1);mix(d.target.f2,s.target.f2);mix(d.target.f3,s.target.f3);mix(d.target.nasal,s.target.nasal);
        mix(d.command.tongueX,s.command.tongueX);mix(d.command.tongueY,s.command.tongueY);mix(d.command.tongueTip,s.command.tongueTip);mix(d.command.jaw,s.command.jaw);mix(d.command.lipAperture,s.command.lipAperture);mix(d.command.lipRound,s.command.lipRound);mix(d.command.velum,s.command.velum);mix(d.command.glottalTension,s.command.glottalTension);mix(d.command.adduction,s.command.adduction);mix(d.command.pressure,s.command.pressure);
    }
    dst.observations=next;
}

BioSpeechModel::Primitive BioSpeechModel::makeTransition(const Primitive& a,const Primitive& b){
    Primitive t; if(a.frames.empty()||b.frames.empty())return t;
    const size_t n=std::min<size_t>(6,std::min(a.frames.size(),b.frames.size()));t.frames.reserve(n);
    for(size_t i=0;i<n;++i){
        const auto& x=a.frames[a.frames.size()-n+i];const auto& y=b.frames[i];const float u=float(i+1)/float(n+1);MotorFrame z=x;
        auto m=[&](float p,float q){return p+(q-p)*u;};
        z.target.f0=m(x.target.f0,y.target.f0);z.target.rms=m(x.target.rms,y.target.rms);z.target.voiced=m(x.target.voiced,y.target.voiced);z.target.f1=m(x.target.f1,y.target.f1);z.target.f2=m(x.target.f2,y.target.f2);z.target.f3=m(x.target.f3,y.target.f3);z.target.nasal=m(x.target.nasal,y.target.nasal);
        z.command.tongueX=m(x.command.tongueX,y.command.tongueX);z.command.tongueY=m(x.command.tongueY,y.command.tongueY);z.command.tongueTip=m(x.command.tongueTip,y.command.tongueTip);z.command.jaw=m(x.command.jaw,y.command.jaw);z.command.lipAperture=m(x.command.lipAperture,y.command.lipAperture);z.command.lipRound=m(x.command.lipRound,y.command.lipRound);z.command.velum=m(x.command.velum,y.command.velum);z.command.glottalTension=m(x.command.glottalTension,y.command.glottalTension);z.command.adduction=m(x.command.adduction,y.command.adduction);z.command.pressure=m(x.command.pressure,y.command.pressure);
        t.frames.push_back(z);
    }return t;
}

bool BioSpeechModel::learn(std::span<const uint8_t> plan,std::span<const int16_t> pcm,int sampleRate){
    auto tokens=planTokens(plan);std::vector<std::string> units;for(const auto& t:tokens)if(!boundary(t))units.push_back(t);
    auto canon=canonicalPcm(pcm,sampleRate);if(units.empty()||canon.size()<units.size()*160)return false;
    std::vector<uint64_t> keys;keys.reserve(units.size());
    for(size_t i=0;i<units.size();++i){
        const size_t a=i*canon.size()/units.size();const size_t b=(i+1)*canon.size()/units.size();if(b<=a+80)continue;
        const auto bytes=std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(units[i].data()),units[i].size());const uint64_t key=hashUnit(bytes);
        const auto p=makePrimitive(std::span<const int16_t>(canon.data()+a,b-a));if(p.frames.empty())continue;
        auto it=primitives_.find(key);if(it==primitives_.end())primitives_[key]=p;else averagePrimitive(it->second,p);keys.push_back(key);
    }
    for(size_t i=1;i<keys.size();++i){const uint64_t k=transitionKey(keys[i-1],keys[i]);auto p=makeTransition(primitives_[keys[i-1]],primitives_[keys[i]]);if(p.frames.empty())continue;auto it=transitions_.find(k);if(it==transitions_.end())transitions_[k]=p;else averagePrimitive(it->second,p);}
    return !keys.empty();
}

double BioSpeechModel::resonatorStep(double x,double frequency,double bandwidth,Resonator& s){
    const double r=std::exp(-kPi*bandwidth/double(kRate));const double c=2.0*r*std::cos(2.0*kPi*frequency/double(kRate));
    const double y=(1.0-r)*x+c*s.y1-r*r*s.y2;s.y2=s.y1;s.y1=y;return y;
}

std::vector<int16_t> BioSpeechModel::synthesizeFrames(std::span<const MotorFrame> frames,const Perturbation& perturbation,uint32_t lesionMask,bool question,size_t unitIndex,size_t unitCount,Diagnostics* diag){
    std::vector<int16_t> out;out.reserve(frames.size()*kHop);if(frames.empty())return out;
    Resonator r1,r2,r3,rn;double phase=0;uint64_t rng=0xB105F33DULL+unitIndex*7919;
    for(size_t fi=0;fi<frames.size();++fi){
        MotorFrame frame=frames[fi];const double pos=(unitCount<=1)?1.0:double(unitIndex)/double(unitCount-1);
        if(pos>0.70){const float u=float((pos-0.70)/0.30);frame.command.glottalTension=clamp01(frame.command.glottalTension+(question?0.10f:-0.045f)*u);}
        double eb=0,ea=0,se=0,cm=0;const auto corrected=adapt(frame.command,frame.target,perturbation,lesionMask,&eb,&ea,&se,&cm);
        if(diag){diag->auditoryErrorBefore+=eb;diag->auditoryErrorAfter+=ea;diag->somatosensoryError+=se;diag->compensationMagnitude+=cm;diag->renderedFrames++;}
        MotorCommand actual=corrected;actual.jaw=clamp01(actual.jaw+perturbation.jawOffset);const auto p=plant(actual).acoustic;
        // BG lesion: delayed/weak initiation; cerebellar lesion: deterministic timing jitter.
        const bool gateDrop=(lesionMask&LesionBasalGanglia) && fi<2;
        int samples=kHop;if(lesionMask&LesionCerebellum)samples+=(fi%3==0?12:(fi%3==1?-8:0));samples=std::max(80,samples);
        for(int n=0;n<samples;++n){
            rng=mix64(rng+uint64_t(n)+fi*131);const double noise=(double((rng>>11)&0x1fffff)/1048576.0)-1.0;
            const double f0=std::clamp<double>(p.f0,65.0,420.0);phase+=2.0*kPi*f0/double(kRate);if(phase>2.0*kPi)phase-=2.0*kPi;
            const double pulse=std::sin(phase)+0.34*std::sin(2*phase)+0.16*std::sin(3*phase);
            double src=(p.voiced*pulse+(1.0-p.voiced)*0.7*noise)*(gateDrop?0.05:1.0);
            double y=resonatorStep(src,p.f1,80.0,r1);y=resonatorStep(y,p.f2,110.0,r2);y=resonatorStep(y,p.f3,160.0,r3);
            if(p.nasal>0.05)y=(1.0-p.nasal*0.45)*y+p.nasal*0.45*resonatorStep(src,300.0,120.0,rn);
            const double amp=std::clamp<double>(p.rms*1.9,0.01,0.80);y=std::tanh(y*8.0)*amp;
            out.push_back(int16_t(std::clamp(y*30000.0,-32767.0,32767.0)));if(out.size()>=kMaxGeneratedSamples)return out;
        }
    }
    return out;
}

void BioSpeechModel::appendCrossfade(std::vector<int16_t>& out,std::span<const int16_t> piece,size_t fade){
    if(piece.empty()) return;
    if(out.empty()){out.insert(out.end(),piece.begin(),piece.end());return;}
    fade=std::min({fade,out.size(),piece.size()});
    const size_t start=out.size()-fade;for(size_t i=0;i<fade;++i){const double u=double(i+1)/double(fade+1);out[start+i]=int16_t((1-u)*out[start+i]+u*piece[i]);}
    out.insert(out.end(),piece.begin()+static_cast<std::ptrdiff_t>(fade),piece.end());
}
void BioSpeechModel::appendSilence(std::vector<int16_t>& out,size_t n){out.insert(out.end(),std::min(n,kMaxGeneratedSamples-out.size()),0);}

std::vector<int16_t> BioSpeechModel::render(std::span<const uint8_t> plan){
    diagnostics_={};diagnostics_.lesionMask=lesionMask_;if(lesionMask_&LesionPlanner||lesionMask_&LesionVocalMotor)return {};
    const auto tokens=planTokens(plan);size_t unitCount=0;for(const auto& t:tokens)if(!boundary(t))++unitCount;if(!unitCount)return {};
    for(const auto& t:tokens)if(!boundary(t)){const auto b=std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(t.data()),t.size());if(!hasPrimitive(b))return {};}
    const bool question=std::find(tokens.begin(),tokens.end(),"#q")!=tokens.end();
    std::vector<int16_t> out;uint64_t prev=0;bool havePrev=false;size_t idx=0;
    for(const auto& t:tokens){
        if(boundary(t)){if(t=="#w")appendSilence(out,kRate*28/1000);else if(t=="#c")appendSilence(out,kRate*75/1000);else if(t=="#p")appendSilence(out,kRate*130/1000);else if(t=="#q")appendSilence(out,kRate*105/1000);else if(t=="#e")appendSilence(out,kRate*65/1000);continue;}
        const auto b=std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(t.data()),t.size());const uint64_t key=hashUnit(b);
        if(havePrev){auto it=transitions_.find(transitionKey(prev,key));if(it!=transitions_.end()){auto bridge=synthesizeFrames(it->second.frames,perturbation_,lesionMask_,question,idx,unitCount,&diagnostics_);appendCrossfade(out,bridge,kRate*5/1000);}}
        auto piece=synthesizeFrames(primitives_.at(key).frames,perturbation_,lesionMask_,question,idx,unitCount,&diagnostics_);appendCrossfade(out,piece,kRate*9/1000);prev=key;havePrev=true;++idx;if(out.size()>=kMaxGeneratedSamples)break;
    }
    if(diagnostics_.renderedFrames){const double n=diagnostics_.renderedFrames;diagnostics_.auditoryErrorBefore/=n;diagnostics_.auditoryErrorAfter/=n;diagnostics_.somatosensoryError/=n;diagnostics_.compensationMagnitude/=n;}
    return out;
}

bool BioSpeechModel::hasPrimitive(std::span<const uint8_t> unit) const{return !unit.empty()&&primitives_.find(hashUnit(unit))!=primitives_.end();}
uint64_t BioSpeechModel::memoryBytes() const{uint64_t b=0;for(const auto& [_,p]:primitives_)b+=sizeof(Primitive)+p.frames.capacity()*sizeof(MotorFrame);for(const auto& [_,p]:transitions_)b+=sizeof(Primitive)+p.frames.capacity()*sizeof(MotorFrame);return b;}
void BioSpeechModel::clear(){primitives_.clear();transitions_.clear();diagnostics_={};perturbation_={};lesionMask_=0;}

std::vector<uint8_t> BioSpeechModel::serialize() const{
    std::vector<uint8_t> out;append(out,kMagic);append(out,kVersion);
    auto table=[&](const auto& map){uint32_t count=uint32_t(map.size());append(out,count);std::vector<uint64_t> keys;for(auto&[k,_]:map)keys.push_back(k);std::sort(keys.begin(),keys.end());for(uint64_t k:keys){append(out,k);const auto&p=map.at(k);append(out,p.observations);uint32_t n=uint32_t(p.frames.size());append(out,n);for(const auto&f:p.frames){
            append(out,f.target.f0);append(out,f.target.rms);append(out,f.target.voiced);append(out,f.target.f1);append(out,f.target.f2);append(out,f.target.f3);append(out,f.target.nasal);
            append(out,f.command.tongueX);append(out,f.command.tongueY);append(out,f.command.tongueTip);append(out,f.command.jaw);append(out,f.command.lipAperture);append(out,f.command.lipRound);append(out,f.command.velum);append(out,f.command.glottalTension);append(out,f.command.adduction);append(out,f.command.pressure);
        }}};
    table(primitives_);table(transitions_);return out;
}

bool BioSpeechModel::restore(std::span<const uint8_t> blob){
    size_t off=0;uint32_t magic=0,ver=0;if(!read(blob,off,magic)||!read(blob,off,ver)||magic!=kMagic||ver!=kVersion)return false;clear();
    auto table=[&](auto& map,uint32_t max)->bool{uint32_t count=0;if(!read(blob,off,count)||count>max)return false;for(uint32_t i=0;i<count;++i){uint64_t k=0;uint16_t obs=0;uint32_t n=0;if(!read(blob,off,k)||!read(blob,off,obs)||!read(blob,off,n)||obs<1||obs>16||n<1||n>kMaxFrames)return false;Primitive p;p.observations=obs;p.frames.resize(n);for(auto&f:p.frames){
            float* vals[]={&f.target.f0,&f.target.rms,&f.target.voiced,&f.target.f1,&f.target.f2,&f.target.f3,&f.target.nasal,
                          &f.command.tongueX,&f.command.tongueY,&f.command.tongueTip,&f.command.jaw,&f.command.lipAperture,&f.command.lipRound,&f.command.velum,&f.command.glottalTension,&f.command.adduction,&f.command.pressure};
            for(float* v:vals)if(!read(blob,off,*v)||!std::isfinite(*v))return false;
            f.command=clampMotor(f.command);
        }map[k]=std::move(p);}return true;};
    if(!table(primitives_,512)||!table(transitions_,4096)) return false;
    return off==blob.size();
}

} // namespace wb
