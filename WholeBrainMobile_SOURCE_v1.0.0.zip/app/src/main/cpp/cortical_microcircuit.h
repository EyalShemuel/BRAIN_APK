#pragma once
#include <array>
#include <cstdint>

namespace wb {

enum class CorticalAreaKind : uint8_t { SensoryGranular = 0, Association = 1, AgranularMotor = 2 };
enum class CorticalLayer : uint8_t { L1 = 0, L23 = 1, L4 = 2, L5 = 3, L6 = 4, Count = 5 };
enum class CorticalCellClass : uint8_t { IT = 0, ET = 1, CT = 2, PV = 3, SST = 4, VIP = 5, LAMP5 = 6, Count = 7 };
enum class DendriticCompartment : uint8_t { Soma = 0, Apical = 1 };

struct CorticalPhenotype {
    CorticalLayer layer = CorticalLayer::L23;
    CorticalCellClass cell = CorticalCellClass::IT;
    bool excitatory = true;
    float membraneDecay = 0.90f;
    float thresholdScale = 1.0f;
    uint8_t refractoryTicks = 2;
    float adaptationIncrement = 0.05f;
    float adaptationDecay = 0.985f;
    float apicalDecay = 0.94f;
    float dendriticGain = 0.25f;
};

struct CorticalSynapseRule {
    CorticalLayer targetLayer = CorticalLayer::L23;
    CorticalCellClass preferredTarget = CorticalCellClass::IT;
    DendriticCompartment compartment = DendriticCompartment::Soma;
    float weightScale = 1.0f;
};

class CorticalMicrocircuit {
public:
    static std::array<float,5> layerFractions(CorticalAreaKind area);
    static CorticalPhenotype phenotype(CorticalAreaKind area, uint32_t localIndex, uint32_t population, uint64_t seed);
    static CorticalSynapseRule localRule(const CorticalPhenotype& src);
    static CorticalSynapseRule longRangeRule(const CorticalPhenotype& src, bool feedback);
    static float dendriticCoincidence(const CorticalPhenotype& p, float soma, float apical);
    static float inhibitionScale(CorticalCellClass src, CorticalCellClass dst);
    static uint32_t conductionDelayTicks(bool local, uint32_t recurrentDelayMax, uint64_t hash, uint32_t hierarchyDistance = 1);
    static uint32_t layerBegin(CorticalAreaKind area, CorticalLayer layer, uint32_t population);
    static uint32_t layerEnd(CorticalAreaKind area, CorticalLayer layer, uint32_t population);
    static bool classMatches(const CorticalPhenotype& p, CorticalCellClass wanted);
};

} // namespace wb
