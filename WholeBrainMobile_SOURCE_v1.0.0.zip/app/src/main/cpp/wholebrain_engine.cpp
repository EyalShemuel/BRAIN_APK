#include "wholebrain_engine.h"
#include "sensor_encoders.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <iomanip>
#include <limits>
#include <numeric>
#include <sstream>

namespace wb {
namespace {
constexpr std::array<uint32_t, 15> kRegionWidths = {
    35,24,47,18,59,30,35,18,12,29,12,6,18,6,6
};
constexpr uint32_t kRegionWidthSum = 355;
constexpr uint64_t kMaxNeurons = 71000000ull;
constexpr uint32_t kMaxFanout = 4096;
constexpr uint32_t kSerializationMagic = 0x57424D31u; // WBM1
constexpr uint32_t kSerializationVersion = 5; // v5: v4 state + BioSpeech articulatory cortex/plant
constexpr uint32_t kGenerativeSpeechSerializationVersion = 4;
constexpr uint32_t kLegacySpeechSerializationVersion = 3;
constexpr uint32_t kPreviousSerializationVersion = 2;
constexpr uint32_t kNeuralSpeechRate = 16000;
constexpr uint32_t kMaxSpeechUnits = 128;
constexpr uint32_t kMaxSpeechSamples = kNeuralSpeechRate * 4; // four seconds per legacy learned phrase
constexpr uint32_t kMaxSpeechPrimitives = 384;
constexpr uint32_t kMaxSpeechTransitions = 3072;
constexpr uint32_t kMaxPrimitiveSamples = kNeuralSpeechRate * 3 / 4; // 750 ms analysis window
constexpr uint32_t kSpeechFrameSamples = 320; // 20 ms LPC analysis frame
constexpr uint32_t kSpeechHopSamples = 160;   // 10 ms motor/acoustic frame step
constexpr uint32_t kMaxPrimitiveFrames = 80;
constexpr uint32_t kMaxGeneratedSamples = kNeuralSpeechRate * 15; // 15 s utterance safety cap

inline float fastDecay(float v, uint32_t dt, float decay) {
    if (dt == 0) return v;
    if (dt > 128) return 0.0f;
    return v * std::pow(decay, static_cast<float>(dt));
}

template <typename T>
void appendBytes(std::vector<uint8_t>& out, const T& value) {
    const auto* p = reinterpret_cast<const uint8_t*>(&value);
    out.insert(out.end(), p, p + sizeof(T));
}

template <typename T>
bool readBytes(std::span<const uint8_t> blob, size_t& off, T& out) {
    if (off + sizeof(T) > blob.size()) return false;
    std::memcpy(&out, blob.data() + off, sizeof(T)); off += sizeof(T); return true;
}

int motionSensorSlot(int type) {
    switch (type) {
        case 1: case 35: return 0;
        case 10: return 1;
        case 9: return 2;
        case 4: case 16: return 3;
        case 3: case 11: case 27: case 28: return 4;
        case 15: case 37: return 5;
        case 20: case 42: return 6;
        case 2: case 14: return 7;
        case 38: case 40: return 0;
        case 39: case 41: return 3;
        default: return -1;
    }
}

float motionDeltaScale(int type) {
    switch (type) {
        case 4: case 16: return 0.55f;
        case 11: case 15: case 20: case 28: case 37: return 0.10f;
        case 3: case 27: case 42: return 5.0f;
        case 2: case 14: return 8.0f;
        case 39: case 41: return 0.55f;
        case 9: return 2.2f;
        default: return 2.0f;
    }
}

constexpr uint32_t kMotionSlots = 8;
constexpr uint32_t kEnvironmentSlots = 20;

int environmentSlot(int type) {
    switch (type) {
        case 5: return 0; case 6: return 1; case 7: return 2; case 8: return 3;
        case 12: return 4; case 13: return 5; case 17: return 6; case 18: return 7;
        case 19: return 8; case 21: return 9; case 22: return 10; case 23: return 11;
        case 24: return 12; case 25: return 13; case 26: return 14; case 29: return 15;
        case 30: return 16; case 31: return 17; case 34: return 18; case 36: return 19;
        default: return -1;
    }
}

float normalizedEnvironmentLevel(int type, float x) {
    switch (type) {
        case 5:  return std::clamp(std::log1p(std::max(0.0f,x)) / std::log1p(20000.0f), 0.0f, 1.0f);
        case 6:  return std::clamp((x - 850.0f) / 250.0f, 0.0f, 1.0f);
        case 7: case 13: return std::clamp((x + 20.0f) / 80.0f, 0.0f, 1.0f);
        case 8:  return 1.0f - std::clamp(x / 10.0f, 0.0f, 1.0f);
        case 12: return std::clamp(x / 100.0f, 0.0f, 1.0f);
        case 17: case 18: case 22: case 23: case 24: case 25: case 26: case 29: case 30: case 31: return x > 0.0f ? 1.0f : 0.0f;
        case 19: return std::clamp(std::fmod(std::max(0.0f,x), 100.0f) / 100.0f, 0.0f, 1.0f);
        case 21: return std::clamp((x - 35.0f) / 165.0f, 0.0f, 1.0f);
        case 34: return x > 0.5f ? 1.0f : 0.0f;
        case 36: return std::clamp(x / 360.0f, 0.0f, 1.0f);
        default: return std::clamp(0.5f + 0.5f * std::tanh(x / 10.0f), 0.0f, 1.0f);
    }
}

inline void updateEma(double& ema, double sample, double keep = 0.90) {
    ema = ema == 0.0 ? sample : keep * ema + (1.0 - keep) * sample;
}

uint32_t unitIndex(uint64_t h, uint32_t n) {
    if (!n) return 0;
    constexpr double inv53 = 1.0 / 9007199254740992.0;
    const double u = double(h >> 11) * inv53;
    return std::min<uint32_t>(n-1, static_cast<uint32_t>(u * n));
}

std::vector<int16_t> speechCanonicalPcm(std::span<const int16_t> pcm, int sampleRate) {
    if (pcm.size() < 160 || sampleRate < 8000 || sampleRate > 96000) return {};
    int32_t peak = 0;
    for (int16_t v : pcm) peak = std::max<int32_t>(peak, std::abs(int32_t(v)));
    if (peak < 256) return {};
    const int32_t trimThreshold = std::max<int32_t>(192, peak / 32);
    size_t first = 0, last = pcm.size();
    while (first < last && std::abs(int32_t(pcm[first])) < trimThreshold) ++first;
    while (last > first && std::abs(int32_t(pcm[last-1])) < trimThreshold) --last;
    if (last <= first) return {};
    const size_t pad = static_cast<size_t>(sampleRate / 20); // 50 ms context
    first = first > pad ? first - pad : 0;
    last = std::min(pcm.size(), last + pad);
    const size_t srcN = last - first;
    size_t dstN = static_cast<size_t>(std::llround(double(srcN) * kNeuralSpeechRate / sampleRate));
    dstN = std::clamp<size_t>(dstN, 160, kMaxSpeechSamples);
    std::vector<int16_t> out(dstN);
    for (size_t i=0;i<dstN;++i) {
        const double srcPos = double(i) * sampleRate / kNeuralSpeechRate;
        const size_t a = std::min(srcN-1, static_cast<size_t>(srcPos));
        const size_t b = std::min(srcN-1, a+1);
        const double f = srcPos - double(a);
        const double v = (1.0-f)*pcm[first+a] + f*pcm[first+b];
        out[i] = static_cast<int16_t>(std::clamp(v, -32767.0, 32767.0));
    }
    int32_t outPeak=0; for(int16_t v:out) outPeak=std::max<int32_t>(outPeak,std::abs(int32_t(v)));
    if(outPeak>512) {
        const double gain=std::min(2.5, 28000.0/double(outPeak));
        for(auto& v:out) v=static_cast<int16_t>(std::clamp(double(v)*gain,-32767.0,32767.0));
    }
    return out;
}

int8_t speechCompand(int16_t sample) {
    const double x = std::clamp(double(sample)/32768.0, -1.0, 1.0);
    const double q = std::copysign(std::sqrt(std::abs(x)), x);
    return static_cast<int8_t>(std::clamp<int>(int(std::lround(q*127.0)), -127, 127));
}

int16_t speechExpand(int8_t code) {
    const double q = double(code)/127.0;
    const double x = std::copysign(q*q, q);
    return static_cast<int16_t>(std::clamp<int>(int(std::lround(x*32767.0)), -32767, 32767));
}

std::vector<std::string> speechPlanTokens(std::span<const uint8_t> plan) {
    std::vector<std::string> out;
    std::string current;
    current.reserve(24);
    for (uint8_t b : plan) {
        if (b == 0x1f) {
            if (!current.empty()) { out.push_back(current); current.clear(); }
        } else if (b >= 0x20 && b < 0x7f) {
            current.push_back(static_cast<char>(b));
        }
    }
    if (!current.empty()) out.push_back(current);
    return out;
}

bool speechControl(const std::string& token) { return !token.empty() && token.front() == '#'; }

void speechAppendSilence(std::vector<int16_t>& out, size_t samples) {
    if (out.size() >= kMaxGeneratedSamples) return;
    samples=std::min(samples,size_t(kMaxGeneratedSamples)-out.size());
    out.insert(out.end(),samples,0);
}

void speechAppendCrossfade(std::vector<int16_t>& out, std::span<const int16_t> piece, size_t fade) {
    if(piece.empty() || out.size()>=kMaxGeneratedSamples) return;
    const size_t room=size_t(kMaxGeneratedSamples)-out.size();
    const size_t take=std::min(piece.size(),room+std::min(fade,out.size()));
    if(!take) return;
    const size_t f=std::min({fade,out.size(),take});
    if(f) {
        const size_t base=out.size()-f;
        for(size_t i=0;i<f;++i) {
            const double a=double(f-i)/double(f+1);
            const double b=1.0-a;
            out[base+i]=static_cast<int16_t>(std::clamp(a*out[base+i]+b*piece[i],-32767.0,32767.0));
        }
    }
    const size_t start=f;
    const size_t appendN=std::min(take-start,size_t(kMaxGeneratedSamples)-out.size());
    out.insert(out.end(),piece.begin()+static_cast<std::ptrdiff_t>(start),piece.begin()+static_cast<std::ptrdiff_t>(start+appendN));
}

double speechWindowEnergy(std::span<const int16_t> pcm,size_t center,size_t half) {
    if(pcm.empty()) return 0.0;
    const size_t a=center>half?center-half:0;
    const size_t b=std::min(pcm.size(),center+half+1);
    double e=0.0;
    for(size_t i=a;i<b;++i) { const double v=double(pcm[i])/32768.0; e += v*v; }
    return e/double(std::max<size_t>(1,b-a));
}

std::vector<size_t> speechAlignmentBoundaries(std::span<const int16_t> pcm,size_t units) {
    std::vector<size_t> b(units+1);
    if(!units || pcm.empty()) return b;
    b.front()=0; b.back()=pcm.size();
    const size_t nominal=std::max<size_t>(1,pcm.size()/units);
    const size_t minSpan=std::max<size_t>(80,nominal/3);
    const size_t radius=std::max<size_t>(80,nominal/3);
    const size_t energyHalf=80; // 5 ms at 16 kHz
    for(size_t i=1;i<units;++i) {
        const size_t target=pcm.size()*i/units;
        size_t lo=target>radius?target-radius:0;
        size_t hi=std::min(pcm.size()-1,target+radius);
        lo=std::max(lo,b[i-1]+minSpan);
        const size_t latest=pcm.size()-(units-i)*minSpan;
        hi=std::min(hi,latest);
        if(lo>hi) { b[i]=std::min(target,latest); continue; }
        size_t best=lo; double bestScore=std::numeric_limits<double>::infinity();
        for(size_t x=lo;x<=hi;x+=16) {
            const double dist=std::abs(double(x)-double(target))/double(std::max<size_t>(1,radius));
            const double score=speechWindowEnergy(pcm,x,energyHalf)+0.015*dist;
            if(score<bestScore){bestScore=score;best=x;}
            if(hi-x<16) break;
        }
        b[i]=best;
    }
    return b;
}

void speechFadeEdges(std::vector<int16_t>& pcm,size_t fade) {
    const size_t f=std::min(fade,pcm.size()/2);
    for(size_t i=0;i<f;++i) {
        const double g=double(i+1)/double(f+1);
        pcm[i]=static_cast<int16_t>(pcm[i]*g);
        pcm[pcm.size()-1-i]=static_cast<int16_t>(pcm[pcm.size()-1-i]*g);
    }
}
}

uint64_t BrainEngine::mix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ull;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
    return x ^ (x >> 31);
}

uint32_t BrainEngine::deterministicTarget(uint32_t source, uint32_t slot,
                                          uint32_t n, uint64_t seed) {
    if (!n) return 0;
    const uint64_t x = mix64(seed ^ (uint64_t(source) << 32) ^ uint64_t(slot) * 0xD6E8FEB86659FD93ull);
    return static_cast<uint32_t>(x % n);
}

float BrainEngine::core53ErrorUpdate(float differential, uint16_t count, int chosen, float eta) {
    const float direction = chosen == 1 ? +1.0f : -1.0f;
    return std::clamp(differential + direction * 2.0f * eta * count, -2.0f, 2.0f);
}

uint32_t BrainEngine::topographicLocal(uint32_t regionSize, uint32_t cellIndex, uint32_t cellCount, uint32_t role, uint32_t roleCount) {
    if (!regionSize || !cellCount) return 0;
    cellIndex = std::min(cellIndex, cellCount - 1);
    const uint32_t a = std::min<uint32_t>(static_cast<uint32_t>(uint64_t(regionSize) * cellIndex / cellCount), regionSize - 1);
    const uint32_t rawB = static_cast<uint32_t>(uint64_t(regionSize) * (cellIndex + 1) / cellCount);
    const uint32_t b = std::max<uint32_t>(a + 1, std::min<uint32_t>(rawB, regionSize));
    const uint32_t width = b - a;
    if (width <= 1 || roleCount <= 1) return a;
    role = std::min(role, roleCount - 1);
    return a + static_cast<uint32_t>(uint64_t(role) * (width - 1) / (roleCount - 1));
}

BrainEngine::BrainEngine(const EngineConfig& config) : cfg_(config) {
    cfg_.neurons = std::clamp<uint64_t>(cfg_.neurons, 1024ull, kMaxNeurons);
    cfg_.fanout = std::clamp<uint32_t>(cfg_.fanout, 64u, kMaxFanout);
    cfg_.recurrentDelayMax = std::clamp<uint32_t>(cfg_.recurrentDelayMax, 1u, 32u);
    buildRegions();
    membrane_.assign(cfg_.neurons, 0.0f);
    apicalDendrite_.assign(cfg_.neurons, 0.0f);
    adaptation_.assign(cfg_.neurons, 0.0f);
    lastUpdateTick_.assign(cfg_.neurons, 0);
    lastSpikeTick_.assign(cfg_.neurons, 0);
    touchMarker_.assign(cfg_.neurons, 0);
    eventRing_.resize(cfg_.recurrentDelayMax + 2);
    association_ = regions_[static_cast<size_t>(Region::Association)];
    motor_ = regions_[static_cast<size_t>(Region::Motor)];
    vocalMotor_ = regions_[static_cast<size_t>(Region::VocalMotor)];
    const uint32_t assocN = association_.end - association_.begin;
    motorDifferential_.assign(assocN, 0.0f);
    featureCounts_.assign(assocN, 0);
    touched_.reserve(65536);
    featureTouched_.reserve(8192);
    lastFeature_.reserve(8192);
}

void BrainEngine::buildRegions() {
    uint64_t cursor = 0;
    for (size_t r = 0; r < kRegionWidths.size(); ++r) {
        uint64_t next = (r + 1 == kRegionWidths.size())
            ? cfg_.neurons
            : (cfg_.neurons * std::accumulate(kRegionWidths.begin(), kRegionWidths.begin()+r+1, 0ull)) / kRegionWidthSum;
        regions_[r] = {static_cast<uint32_t>(cursor), static_cast<uint32_t>(next)};
        cursor = next;
    }
}

Region BrainEngine::regionOf(uint32_t neuron) const {
    for (size_t r = 0; r < regions_.size(); ++r) if (neuron < regions_[r].end) return static_cast<Region>(r);
    return Region::Brainstem;
}

uint32_t BrainEngine::regionSize(Region region) const {
    const auto rr = regions_[static_cast<size_t>(region)];
    return rr.end - rr.begin;
}

bool BrainEngine::isCorticalRegion(Region region) const {
    switch(region){
        case Region::Visual: case Region::Auditory: case Region::Language:
        case Region::Somatosensory: case Region::Association: case Region::Pfc:
        case Region::Motor: case Region::VocalMotor: case Region::Semantic:
            return true;
        default: return false;
    }
}

CorticalAreaKind BrainEngine::corticalAreaKind(Region region) const {
    switch(region){
        case Region::Visual: case Region::Auditory: case Region::Somatosensory:
            return CorticalAreaKind::SensoryGranular;
        case Region::Motor: case Region::VocalMotor:
            return CorticalAreaKind::AgranularMotor;
        default:
            return CorticalAreaKind::Association;
    }
}

int BrainEngine::corticalHierarchy(Region region) const {
    switch(region){
        case Region::Visual: case Region::Auditory: case Region::Somatosensory: return 0;
        case Region::Language: case Region::Motor: case Region::VocalMotor: return 1;
        case Region::Association: case Region::Semantic: return 2;
        case Region::Pfc: return 3;
        default: return 1;
    }
}

CorticalPhenotype BrainEngine::corticalPhenotype(uint32_t neuron) const {
    const Region r=regionOf(neuron);
    if(!cfg_.biologicalCortex || !isCorticalRegion(r)){
        CorticalPhenotype p;
        const uint64_t h=mix64(cfg_.seed ^ (uint64_t(neuron)*0x9E3779B97F4A7C15ull));
        p.excitatory=(h&0xFFFFu)<static_cast<uint64_t>(cfg_.excitatoryFraction*65535.0f);
        p.cell=p.excitatory?CorticalCellClass::IT:CorticalCellClass::PV;
        p.layer=CorticalLayer::L23;
        p.membraneDecay=cfg_.membraneDecay; p.thresholdScale=1.0f; p.refractoryTicks=cfg_.refractoryTicks;
        p.adaptationIncrement=0.0f; p.adaptationDecay=1.0f; p.apicalDecay=0.0f; p.dendriticGain=0.0f;
        return p;
    }
    const auto rr=regions_[static_cast<size_t>(r)];
    return CorticalMicrocircuit::phenotype(corticalAreaKind(r),neuron-rr.begin,rr.end-rr.begin,cfg_.seed ^ (uint64_t(static_cast<uint8_t>(r))<<48));
}

bool BrainEngine::isExcitatory(uint32_t neuron) const {
    return corticalPhenotype(neuron).excitatory;
}

uint32_t BrainEngine::structuredCorticalTarget(Region targetRegion, CorticalLayer layer, CorticalCellClass preferred, uint64_t hash) const {
    const auto rr=regions_[static_cast<size_t>(targetRegion)];
    const uint32_t n=rr.end-rr.begin;
    if(!n) return rr.begin;
    const auto area=corticalAreaKind(targetRegion);
    const uint32_t lb=CorticalMicrocircuit::layerBegin(area,layer,n);
    const uint32_t le=std::max<uint32_t>(lb+1,CorticalMicrocircuit::layerEnd(area,layer,n));
    const uint32_t width=le-lb;
    uint32_t fallback=rr.begin+lb+static_cast<uint32_t>(hash%width);
    for(uint32_t attempt=0;attempt<8;++attempt){
        const uint64_t h=mix64(hash ^ uint64_t(attempt)*0xA24BAED4963EE407ull);
        const uint32_t cand=rr.begin+lb+static_cast<uint32_t>(h%width);
        if(CorticalMicrocircuit::classMatches(corticalPhenotype(cand),preferred)) return cand;
    }
    return fallback;
}

float BrainEngine::thresholdFor(uint32_t neuron) const {
    const Region r = regionOf(neuron);
    if (r == Region::Association) return 0.92f;
    if (r == Region::Pfc) return 1.08f;
    if (r == Region::VocalMotor) return 0.35f;
    if (r == Region::Motor) {
        const uint32_t m = motor_.end - motor_.begin;
        const uint32_t half = std::max<uint32_t>(1, m / 2);
        const uint32_t local = neuron - motor_.begin;
        const uint32_t within = local % half;
        const float t = half <= 1 ? 0.0f : float(within) / float(half - 1);
        return 0.05f + 0.75f * t;
    }
    return cfg_.threshold;
}

void BrainEngine::schedule(uint32_t target, float weight, uint32_t delayTicks, DendriticCompartment compartment) {
    if (target >= cfg_.neurons) return;
    delayTicks = std::clamp<uint32_t>(delayTicks, 0u, cfg_.recurrentDelayMax + 1);
    eventRing_[(tick_ + delayTicks) % eventRing_.size()].push_back({target, weight, static_cast<uint8_t>(compartment)});
}

uint32_t BrainEngine::injectPopulation(Region region, uint64_t key, float magnitude, uint32_t count, float gain) {
    // Legacy deterministic population primitive is preserved for the validated
    // synthetic/learning token path. New physical senses do not use this mapper.
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || magnitude <= 0 || gain <= 0) return 0;
    count = std::min(count, n);
    for (uint32_t i = 0; i < count; ++i) {
        const uint32_t local = static_cast<uint32_t>(mix64(key ^ (uint64_t(i) * 0xA24BAED4963EE407ull)) % n);
        schedule(rr.begin + local, gain * magnitude, 0);
    }
    return count;
}

uint32_t BrainEngine::injectChannelPopulation(Region region, uint32_t channel, uint32_t channelCount,
                                              float magnitude, float density, float gain, uint64_t salt,
                                              uint32_t maxCount) {
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || !channelCount || magnitude <= 0.0f || gain <= 0.0f) return 0;
    channel = std::min(channel, channelCount - 1);
    const uint32_t a = rr.begin + static_cast<uint32_t>(uint64_t(n) * channel / channelCount);
    const uint32_t rawB = rr.begin + static_cast<uint32_t>(uint64_t(n) * (channel + 1) / channelCount);
    const uint32_t b = std::max<uint32_t>(a + 1, std::min<uint32_t>(rawB, rr.end));
    const uint32_t width = b - a;
    uint32_t count = static_cast<uint32_t>(std::lround(width * density * std::clamp(magnitude,0.0f,1.0f)));
    count = std::clamp<uint32_t>(count, 1u, std::min<uint32_t>(maxCount, width));
    const float drive = gain * std::clamp(0.58f + 0.62f * magnitude, 0.0f, 1.35f);
    for (uint32_t i=0;i<count;++i) {
        const uint64_t h = mix64(salt ^ uint64_t(channel) * 0x9E3779B97F4A7C15ull ^ i);
        const uint32_t jitter = width > 1 ? unitIndex(h,width) : 0;
        const uint32_t evenly = static_cast<uint32_t>(uint64_t(i) * width / count);
        const uint32_t local = (evenly + jitter / std::max<uint32_t>(1,count)) % width;
        schedule(a + local, drive, 0);
    }
    return count;
}

uint32_t BrainEngine::injectDistributedSubrange(Region region, uint32_t bank, uint32_t banks,
                                                uint64_t key, float magnitude, float density, float gain,
                                                uint32_t maxCount) {
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || !banks || magnitude <= 0.0f) return 0;
    bank = std::min(bank, banks - 1);
    const uint32_t a = rr.begin + static_cast<uint32_t>(uint64_t(n) * bank / banks);
    const uint32_t rawB = rr.begin + static_cast<uint32_t>(uint64_t(n) * (bank + 1) / banks);
    const uint32_t b = std::max<uint32_t>(a + 1, std::min<uint32_t>(rawB, rr.end));
    const uint32_t width = b - a;
    uint32_t count = static_cast<uint32_t>(std::lround(width * density * std::clamp(magnitude,0.0f,1.0f)));
    count = std::clamp<uint32_t>(count, 1u, std::min<uint32_t>(maxCount, width));
    const float drive = gain * std::clamp(0.62f + 0.58f * magnitude, 0.0f, 1.35f);
    for (uint32_t i=0;i<count;++i) {
        const uint64_t h = mix64(key ^ uint64_t(i) * 0xD6E8FEB86659FD93ull);
        const uint32_t local = width > 1 ? unitIndex(h,width) : 0;
        schedule(a + local, drive, 0);
    }
    return count;
}


uint32_t BrainEngine::injectSpeechMicrocircuit(Region region, uint32_t layer, uint32_t cellClass,
                                                uint64_t key, float magnitude, float gain,
                                                uint32_t maxCount) {
    const auto rr=regions_[static_cast<size_t>(region)];
    const uint32_t n=rr.end-rr.begin;
    if(!n||layer>3||cellClass>3||magnitude<=0.0f||gain<=0.0f||!maxCount) return 0;
    const uint32_t a=rr.begin+static_cast<uint32_t>(uint64_t(n)*layer/4);
    const uint32_t rawB=rr.begin+static_cast<uint32_t>(uint64_t(n)*(layer+1)/4);
    const uint32_t b=std::max<uint32_t>(a+1,std::min<uint32_t>(rawB,rr.end));
    const uint32_t width=b-a;
    auto cls=[&](uint32_t neuron)->uint32_t{
        if(isExcitatory(neuron)) return 0;
        const uint64_t h=mix64(cfg_.seed^uint64_t(neuron)*0xA24BAED4963EE407ull);
        const uint32_t q=static_cast<uint32_t>(h%100u);
        if(q<40) return 1; // PV ~40% of inhibitory pool
        if(q<75) return 2; // SST ~35%
        return 3;          // VIP/other ~25%
    };
    const float drive=gain*std::clamp(0.58f+0.62f*magnitude,0.0f,1.35f);
    uint32_t count=0;
    std::array<uint32_t,16> chosen{};
    for(uint32_t attempt=0;attempt<maxCount*64 && count<maxCount;++attempt){
        const uint64_t h=mix64(key^uint64_t(attempt)*0x9E3779B97F4A7C15ull);
        const uint32_t neuron=a+(width>1?unitIndex(h,width):0);
        if(cls(neuron)!=cellClass) continue;
        bool duplicate=false;for(uint32_t i=0;i<count;++i)if(chosen[i]==neuron){duplicate=true;break;}
        if(duplicate) continue;
        if(count<chosen.size()) chosen[count]=neuron;
        schedule(neuron,drive,0);++count;
    }
    return count;
}

uint32_t BrainEngine::injectTopographicCell(Region region, uint32_t x, uint32_t y,
                                            uint32_t width, uint32_t height,
                                            uint32_t role, uint32_t roleCount,
                                            float magnitude, float gain) {
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || !width || !height || x >= width || y >= height || magnitude <= 0.0f) return 0;
    const uint32_t cell = y * width + x;
    uint32_t target=rr.begin;
    const float drive = gain * std::clamp(0.55f + 0.68f * magnitude, 0.0f, 1.40f);
    if(cfg_.biologicalCortex && (region==Region::Visual || region==Region::Somatosensory)){
        const auto area=corticalAreaKind(region);
        const uint32_t lb=CorticalMicrocircuit::layerBegin(area,CorticalLayer::L4,n);
        const uint32_t le=std::max<uint32_t>(lb+1,CorticalMicrocircuit::layerEnd(area,CorticalLayer::L4,n));
        const uint32_t ln=le-lb;
        const uint32_t local=topographicLocal(ln,cell,width*height,role,roleCount);
        target=rr.begin+lb+std::min(local,ln-1);
        schedule(target, drive, 0);
        // Primary thalamic afferents also contact deep corticothalamic populations.
        // A weaker L6 copy preserves sensory visibility at small scales without
        // broadcasting current through unrelated cortical layers.
        if(n<6000){
            const uint32_t l6b=CorticalMicrocircuit::layerBegin(area,CorticalLayer::L6,n);
            const uint32_t l6e=std::max<uint32_t>(l6b+1,CorticalMicrocircuit::layerEnd(area,CorticalLayer::L6,n));
            const uint32_t l6n=l6e-l6b;
            const uint32_t l6local=topographicLocal(l6n,cell,width*height,role,roleCount);
            const uint32_t deep=rr.begin+l6b+std::min(l6local,l6n-1);
            if(deep!=target){ schedule(deep,0.72f*drive,0); return 2; }
        }
        return 1;
    }else{
        const uint32_t local = topographicLocal(n, cell, width*height, role, roleCount);
        target=rr.begin+std::min(local,n-1);
        schedule(target, drive, 0);
        return 1;
    }
}

uint32_t BrainEngine::injectVisualFeature(uint64_t key, float magnitude, int width, int height) {
    return injectTopographicCell(Region::Visual,
        enc::visionX(key), enc::visionY(key),
        static_cast<uint32_t>(width), static_cast<uint32_t>(height),
        enc::visionChannel(key), enc::kVisionChannels,
        magnitude, cfg_.visionGain);
}

uint32_t BrainEngine::injectAudioBand(uint32_t band, float magnitude, float onset) {
    band = std::min<uint32_t>(band, enc::kAudioBands - 1);
    if(!cfg_.biologicalCortex) {
        uint32_t n = injectChannelPopulation(Region::Auditory, band, enc::kAudioBands,
                                             magnitude, 0.018f, cfg_.audioGain,
                                             0x415544494Full, 12);
        if (onset > 0.18f) n += injectChannelPopulation(Region::Auditory, band, enc::kAudioBands,
                                     onset, 0.008f, cfg_.audioGain,0x4F4E534554ull, 6);
        return n;
    }
    const auto rr=regions_[static_cast<size_t>(Region::Auditory)];
    const uint32_t total=rr.end-rr.begin;
    const auto area=corticalAreaKind(Region::Auditory);
    const uint32_t lb=CorticalMicrocircuit::layerBegin(area,CorticalLayer::L4,total);
    const uint32_t le=std::max<uint32_t>(lb+1,CorticalMicrocircuit::layerEnd(area,CorticalLayer::L4,total));
    const uint32_t ln=le-lb;
    auto driveBand=[&](float mag,float density,uint64_t salt,uint32_t maxCount){
        if(mag<=0.0f || !ln) return 0u;
        const uint32_t a=lb+static_cast<uint32_t>(uint64_t(ln)*band/enc::kAudioBands);
        const uint32_t b=std::max<uint32_t>(a+1,std::min<uint32_t>(le,lb+static_cast<uint32_t>(uint64_t(ln)*(band+1)/enc::kAudioBands)));
        const uint32_t w=b-a;
        uint32_t count=static_cast<uint32_t>(std::lround(w*density*std::clamp(mag,0.0f,1.0f)));
        count=std::clamp<uint32_t>(count,1u,std::min<uint32_t>(maxCount,w));
        const float q=cfg_.audioGain*std::clamp(0.58f+0.62f*mag,0.0f,1.35f);
        for(uint32_t i=0;i<count;++i){
            const uint64_t h=mix64(salt^uint64_t(band)*0x9E3779B97F4A7C15ull^i);
            schedule(rr.begin+a+(w>1?unitIndex(h,w):0),q,0);
        }
        return count;
    };
    uint32_t n=driveBand(magnitude,0.018f,0x415544494Full,12);
    if(onset>0.18f)n+=driveBand(onset,0.008f,0x4F4E534554ull,6);
    return n;
}

void BrainEngine::noteCameraFrame() {
    std::lock_guard lock(mutex_);
    ++pendingCameraFrames_;
}

void BrainEngine::injectVision(std::span<const uint8_t> pixels, int width, int height) {
    std::lock_guard lock(mutex_);
    ++pendingVisionFrames_;
    const auto features = enc::visionFeatures(pixels, previousVision_, width, height, 768);
    pendingVisionFeatures_ += features.size();
    for (const auto& f : features) pendingVisionInjections_ += injectVisualFeature(f.key, f.magnitude, width, height);
    previousVision_.assign(pixels.begin(), pixels.end());
}

void BrainEngine::injectAudio(std::span<const int16_t> pcm, int sampleRate) {
    std::lock_guard lock(mutex_);
    ++pendingAudioChunks_;
    const auto bands = enc::audioBands(pcm, sampleRate, enc::kAudioBands, 16);
    pendingAudioBands_ += bands.size();
    std::array<float,enc::kAudioBands> current{};
    for (const auto& f : bands) {
        const uint32_t b = std::min<uint32_t>(static_cast<uint32_t>(f.key), enc::kAudioBands-1);
        current[b] = std::max(current[b], f.magnitude);
    }
    for (uint32_t b=0;b<enc::kAudioBands;++b) {
        if (current[b] <= 0.0f) continue;
        const float onset = havePreviousAudio_ ? std::max(0.0f, current[b] - previousAudioBands_[b]) : current[b];
        pendingAudioInjections_ += injectAudioBand(b,current[b],onset);
    }
    previousAudioBands_ = current;
    havePreviousAudio_ = true;
}

void BrainEngine::injectSensor(int sensorType, float x, float y, float z) {
    std::lock_guard lock(mutex_);
    const int slot = motionSensorSlot(sensorType);
    if (slot >= 0) {
        ++pendingImuEvents_;
        const std::array<float,3> now{x,y,z};
        auto it = previousMotionSensor_.find(sensorType);
        if (it == previousMotionSensor_.end()) { previousMotionSensor_[sensorType] = now; return; }
        const std::array<float,3> d{x-it->second[0], y-it->second[1], z-it->second[2]};
        it->second = now;
        const float scale = motionDeltaScale(sensorType);
        bool changed=false;
        for (uint32_t axis=0;axis<3;++axis) {
            const float mag = std::clamp(std::abs(d[axis]) / std::max(1e-5f,scale), 0.0f, 1.0f);
            if (mag < 0.045f) continue;
            changed=true;
            const uint32_t polarity = d[axis] >= 0 ? 0u : 1u;
            const uint32_t channel = static_cast<uint32_t>(slot) * 6u + axis*2u + polarity;
            pendingImuInjections_ += injectChannelPopulation(Region::Somatosensory,channel,kMotionSlots*6u,mag,0.020f,cfg_.imuGain,0x534F4D41ull,8);
            pendingImuInjections_ += injectChannelPopulation(Region::Cerebellum,channel,kMotionSlots*6u,mag,0.024f,cfg_.imuGain,0x43455245ull,10);
        }
        if (changed) {
            ++pendingImuChanges_;
            const float coarse = std::clamp(std::sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]) / std::max(1e-5f,scale),0.0f,1.0f);
            pendingImuInjections_ += injectChannelPopulation(Region::Brainstem,static_cast<uint32_t>(slot),kMotionSlots,coarse,0.012f,cfg_.imuGain,0x425241494Eull,4);
        }
        return;
    }
    injectEnvironment(sensorType,x,y,z);
}

void BrainEngine::injectEnvironment(int sensorType, float x, float y, float z) {
    ++pendingEnvironmentEvents_;
    if (sensorType == 10001) {
        const std::array<float,3> levels{
            std::clamp(x,0.0f,1.0f),
            std::clamp((y + 10.0f)/70.0f,0.0f,1.0f),
            std::clamp((z - 3.0f)/1.6f,0.0f,1.0f)};
        for (uint32_t i=0;i<3;++i) pendingEnvironmentInjections_ += injectChannelPopulation(Region::Brainstem,i,8,levels[i],0.020f,cfg_.environmentGain,0x42415454ull+i,6);
        ++pendingEnvironmentChanges_;
        return;
    }
    if (sensorType == 10002) {
        const float level = std::clamp(x/6.0f,0.0f,1.0f);
        pendingEnvironmentInjections_ += injectChannelPopulation(Region::Brainstem,3,8,std::max(0.15f,level),0.020f,cfg_.environmentGain,0x544845524Dull,6);
        ++pendingEnvironmentChanges_;
        return;
    }

    const int slot = environmentSlot(sensorType);
    if (slot < 0) return;
    const float level = normalizedEnvironmentLevel(sensorType,x);
    auto it = previousEnvironmentLevel_.find(sensorType);
    const bool first = it == previousEnvironmentLevel_.end();
    const float prev = first ? level : it->second;
    previousEnvironmentLevel_[sensorType] = level;
    float delta = level - prev;
    if (sensorType == 19 && !first && x > 0) delta = std::max(delta,0.25f);
    const bool eventSensor = sensorType==17 || sensorType==18 || (sensorType>=22 && sensorType<=26) || sensorType==29 || sensorType==30 || sensorType==31 || sensorType==34;
    if (!first && !eventSensor && std::abs(delta) < 0.015f) return;
    ++pendingEnvironmentChanges_;
    pendingEnvironmentInjections_ += injectChannelPopulation(Region::Thalamus,static_cast<uint32_t>(slot),kEnvironmentSlots,
                                                              std::max(0.12f,level),0.018f,cfg_.environmentGain,0x454E564Cull,8);
    if (!first && std::abs(delta) >= 0.015f) {
        const uint32_t ch = static_cast<uint32_t>(slot)*2u + (delta>=0?0u:1u);
        pendingEnvironmentInjections_ += injectChannelPopulation(Region::Somatosensory,ch,kEnvironmentSlots*2u,
                                                                  std::clamp(std::abs(delta)*4.0f,0.0f,1.0f),0.018f,cfg_.environmentGain,0x44454C5441ull,6);
    }
}

void BrainEngine::injectTouch(float xNorm, float yNorm, float pressure) {
    std::lock_guard lock(mutex_);
    ++pendingTouchEvents_;
    xNorm=std::clamp(xNorm,0.0f,1.0f); yNorm=std::clamp(yNorm,0.0f,1.0f);
    const bool down = pressure > 0.0f;
    const uint32_t gx=std::min<uint32_t>(31,static_cast<uint32_t>(xNorm*32.0f));
    const uint32_t gy=std::min<uint32_t>(17,static_cast<uint32_t>(yNorm*18.0f));
    constexpr uint32_t roles=8;
    if (down) {
        const float p=std::clamp(pressure,0.05f,1.0f);
        pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,previousTouch_.active?1u:0u,roles,1.0f,cfg_.touchGain);
        if (p>0.25f) pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,2,roles,p,cfg_.touchGain);
        if (previousTouch_.active) {
            const float dx=xNorm-previousTouch_.x, dy=yNorm-previousTouch_.y;
            if (std::abs(dx)>0.004f) pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,dx>=0?3u:4u,roles,std::min(1.0f,std::abs(dx)*18.0f),cfg_.touchGain);
            if (std::abs(dy)>0.004f) pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,dy>=0?5u:6u,roles,std::min(1.0f,std::abs(dy)*18.0f),cfg_.touchGain);
        }
        previousTouch_={xNorm,yNorm,p,true};
    } else if (previousTouch_.active) {
        const uint32_t px=std::min<uint32_t>(31,static_cast<uint32_t>(previousTouch_.x*32.0f));
        const uint32_t py=std::min<uint32_t>(17,static_cast<uint32_t>(previousTouch_.y*18.0f));
        pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,px,py,32,18,7,roles,1.0f,cfg_.touchGain);
        previousTouch_={xNorm,yNorm,0.0f,false};
    }
}

void BrainEngine::injectLocation(double latitude, double longitude, float speed, float bearing) {
    std::lock_guard lock(mutex_);
    ++pendingLocationEvents_;
    const double latRad = latitude * M_PI / 180.0;
    const double north = latitude * 110540.0;
    const double east = longitude * 111320.0 * std::cos(latRad);
    constexpr std::array<double,3> scales{200.0,50.0,10.0};
    for (uint32_t bank=0;bank<scales.size();++bank) {
        const int64_t tx=static_cast<int64_t>(std::floor(east/scales[bank]));
        const int64_t ty=static_cast<int64_t>(std::floor(north/scales[bank]));
        const uint64_t key=mix64(uint64_t(tx) ^ (uint64_t(ty)<<29) ^ uint64_t(bank)*0x9E3779B97F4A7C15ull);
        pendingLocationInjections_ += injectDistributedSubrange(Region::Hippocampus,bank,scales.size(),key,1.0f,0.0025f,cfg_.locationGain,24);
        if (bank==0) pendingLocationInjections_ += injectDistributedSubrange(Region::Semantic,0,4,key^0x504C414345ull,0.8f,0.0015f,cfg_.tokenGain,16);
    }
    if (speed > 0.15f) {
        const float smag=std::clamp(speed/8.0f,0.0f,1.0f);
        const uint32_t dir=static_cast<uint32_t>(std::fmod(std::max(0.0f,bearing),360.0f)/45.0f)%8u;
        pendingLocationInjections_ += injectChannelPopulation(Region::Cerebellum,dir,8,smag,0.012f,cfg_.locationGain,0x475053444952ull,8);
        pendingLocationInjections_ += injectChannelPopulation(Region::Thalamus,0,8,smag,0.010f,cfg_.locationGain,0x475053535044ull,6);
    }
}

void BrainEngine::injectToken(uint32_t channel, std::span<const uint8_t> bytes) {
    std::lock_guard lock(mutex_);
    const uint64_t key = enc::hashBytes(channel, bytes);
    if (channel == 9) {
        // Scientific regression lock: keep the exact pre-v3 cue injection used by
        // the reward-learning smoke/CORE53 bridge. Physical senses use new topology.
        injectPopulation(Region::Semantic, key, 0.8f, 8, cfg_.sensorGain);
        injectPopulation(Region::Association, key ^ 0xA550Cull, 0.45f, 6, cfg_.sensorGain);
        return;
    }
    const uint32_t bank = channel % 16u;
    const uint32_t sem = injectDistributedSubrange(Region::Semantic,bank,16,key,1.0f,0.0040f,cfg_.tokenGain,32);
    const uint32_t assoc = injectDistributedSubrange(Region::Association,bank,16,key^0xA550Cull,0.85f,0.0025f,cfg_.tokenGain,48);
    if (channel>=1 && channel<=4) {
        ++pendingExternalTokens_;
        pendingExternalInjections_ += sem + assoc;
    }
}

bool BrainEngine::learnSpeech(std::span<const uint8_t> token, std::span<const int16_t> pcm, int sampleRate) {
    if (token.empty() || token.size() > 512) return false;
    const auto canonical = speechCanonicalPcm(pcm, sampleRate);
    if (canonical.empty()) return false;
    std::lock_guard lock(mutex_);
    const uint64_t key = enc::hashBytes(0x53504545u, token);
    SpeechEngram e;
    e.sampleRate = kNeuralSpeechRate;
    e.compandedPcm.resize(canonical.size());
    for (size_t i=0;i<canonical.size();++i) e.compandedPcm[i] = speechCompand(canonical[i]);
    if (speechEngrams_.size() >= kMaxSpeechUnits && speechEngrams_.find(key) == speechEngrams_.end()) {
        auto victim = std::min_element(speechEngrams_.begin(), speechEngrams_.end(),
            [](const auto& a,const auto& b){ return a.first < b.first; });
        if (victim != speechEngrams_.end()) speechEngrams_.erase(victim);
    }
    speechEngrams_[key] = std::move(e);

    // Teaching is multisensory: language + semantic cue, the heard waveform, and a
    // dedicated VocalMotor engram.  The returned audio later comes only from this
    // learned brain state; Android TextToSpeech is not part of the path.
    injectPopulation(Region::Language,key,1.0f,12,cfg_.tokenGain);
    injectPopulation(Region::Semantic,key^0x53454D414E54ull,0.9f,10,cfg_.tokenGain);
    injectPopulation(Region::Association,key^0x4153534F43ull,0.65f,8,cfg_.tokenGain);
    injectPopulation(Region::VocalMotor,key^0x564F43414Cull,1.0f,24,1.45f);

    ++pendingAudioChunks_;
    const auto bands = enc::audioBands(canonical, kNeuralSpeechRate, enc::kAudioBands, 16);
    pendingAudioBands_ += bands.size();
    std::array<float,enc::kAudioBands> current{};
    for (const auto& f : bands) {
        const uint32_t b = std::min<uint32_t>(static_cast<uint32_t>(f.key), enc::kAudioBands-1);
        current[b] = std::max(current[b], f.magnitude);
    }
    for (uint32_t b=0;b<enc::kAudioBands;++b) if (current[b] > 0.0f)
        pendingAudioInjections_ += injectAudioBand(b,current[b],current[b]);
    previousAudioBands_ = current;
    havePreviousAudio_ = true;
    return true;
}

std::vector<int16_t> BrainEngine::renderSpeech(std::span<const uint8_t> token) {
    if (token.empty() || token.size() > 512) return {};
    std::lock_guard lock(mutex_);
    const uint64_t key = enc::hashBytes(0x53504545u, token);
    const auto it = speechEngrams_.find(key);
    if (it == speechEngrams_.end()) return {};

    // Legacy v0.7 exact recall is retained only for state compatibility/testing.
    injectPopulation(Region::Language,key,0.9f,10,cfg_.tokenGain);
    injectPopulation(Region::Semantic,key^0x53454D414E54ull,0.8f,8,cfg_.tokenGain);
    injectPopulation(Region::VocalMotor,key^0x564F43414Cull,1.0f,24,1.45f);
    ++speechRenderCount_;

    std::vector<int16_t> out(it->second.compandedPcm.size());
    for (size_t i=0;i<out.size();++i) out[i] = speechExpand(it->second.compandedPcm[i]);
    return out;
}

uint64_t BrainEngine::speechPrimitiveKey(std::span<const uint8_t> unit) {
    return enc::hashBytes(0x47535055u, unit); // GSPU: generative speech primitive unit
}

uint64_t BrainEngine::speechTransitionKey(uint64_t a, uint64_t b) {
    return mix64(a ^ (b + 0x9E3779B97F4A7C15ull + (a<<6) + (a>>2)));
}

std::vector<BrainEngine::SpeechAcousticFrame> BrainEngine::analyzeSpeechFrames(std::span<const int16_t> pcm) {
    std::vector<SpeechAcousticFrame> frames;
    if(pcm.empty()) return frames;
    const size_t frameCount=std::min<size_t>(kMaxPrimitiveFrames,
        std::max<size_t>(1,(pcm.size()+kSpeechHopSamples-1)/kSpeechHopSamples));
    frames.reserve(frameCount);
    std::array<double,kSpeechFrameSamples> x{};
    for(size_t fi=0;fi<frameCount;++fi) {
        const size_t start=fi*kSpeechHopSamples;
        double rms=0.0;
        for(size_t n=0;n<kSpeechFrameSamples;++n) {
            const size_t idx=start+n;
            const double raw=idx<pcm.size()?double(pcm[idx])/32768.0:0.0;
            const double w=0.54-0.46*std::cos(2.0*M_PI*double(n)/double(kSpeechFrameSamples-1));
            x[n]=raw*w;
            rms += raw*raw;
        }
        rms=std::sqrt(rms/double(kSpeechFrameSamples));
        SpeechAcousticFrame f; f.rms=static_cast<float>(std::clamp(rms,0.0,0.95));

        // Causal pitch/voicing estimate on the same local frame.
        double r0=0.0; for(double v:x) r0+=v*v;
        int bestLag=0; double bestCorr=0.0;
        if(r0>1e-8) {
            const int minLag=40;  // 400 Hz
            const int maxLag=266; // ~60 Hz
            for(int lag=minLag;lag<=maxLag;++lag) {
                double c=0.0,ea=0.0,eb=0.0;
                for(int n=lag;n<int(kSpeechFrameSamples);++n) {
                    c += x[n]*x[n-lag]; ea += x[n]*x[n]; eb += x[n-lag]*x[n-lag];
                }
                const double norm=c/std::sqrt(std::max(1e-12,ea*eb));
                if(norm>bestCorr){bestCorr=norm;bestLag=lag;}
            }
        }
        f.voiced=static_cast<float>(std::clamp((bestCorr-0.18)/0.62,0.0,1.0));
        f.f0Hz=(bestLag>0 && f.voiced>0.12f)?float(kNeuralSpeechRate/double(bestLag)):0.0f;

        // 10th-order LPC predictor; reflection coefficients are clipped for stability.
        std::array<double,kSpeechLpcOrder+1> r{};
        for(size_t k=0;k<=kSpeechLpcOrder;++k) {
            double acc=0.0;
            for(size_t n=k;n<kSpeechFrameSamples;++n) acc+=x[n]*x[n-k];
            r[k]=acc;
        }
        std::array<double,kSpeechLpcOrder+1> a{}; a[0]=1.0;
        double err=std::max(r[0],1e-9);
        for(size_t i=1;i<=kSpeechLpcOrder;++i) {
            double acc=r[i];
            for(size_t j=1;j<i;++j) acc-=a[j]*r[i-j];
            double refl=std::clamp(acc/std::max(err,1e-9),-0.92,0.92);
            auto next=a;
            next[i]=refl;
            for(size_t j=1;j<i;++j) next[j]=a[j]-refl*a[i-j];
            a=next;
            err*=std::max(0.08,1.0-refl*refl);
        }
        for(size_t k=0;k<kSpeechLpcOrder;++k) f.lpc[k]=static_cast<float>(std::clamp(a[k+1],-1.5,1.5));
        frames.push_back(f);
    }
    return frames;
}

std::vector<int16_t> BrainEngine::synthesizeSpeechFrames(std::span<const SpeechAcousticFrame> frames, uint64_t seed, double rate) {
    if(frames.empty()) return {};
    rate=std::clamp(rate,0.82,1.18);
    const size_t outFrames=std::max<size_t>(1,std::min<size_t>(kMaxPrimitiveFrames,
        static_cast<size_t>(std::llround(double(frames.size())/rate))));
    std::vector<int16_t> out; out.reserve(outFrames*kSpeechHopSamples);
    std::array<double,kSpeechLpcOrder> history{};
    double phase=0.0;
    uint64_t rng=seed^0x564F434F444552ull;
    for(size_t of=0;of<outFrames;++of) {
        const double srcPos=std::min<double>(frames.size()-1,double(of)*rate);
        const size_t ia=static_cast<size_t>(srcPos);
        const size_t ib=std::min(frames.size()-1,ia+1);
        const double mix=srcPos-double(ia);
        SpeechAcousticFrame f;
        f.f0Hz=float((1.0-mix)*frames[ia].f0Hz+mix*frames[ib].f0Hz);
        f.rms=float((1.0-mix)*frames[ia].rms+mix*frames[ib].rms);
        f.voiced=float((1.0-mix)*frames[ia].voiced+mix*frames[ib].voiced);
        for(size_t k=0;k<kSpeechLpcOrder;++k) f.lpc[k]=float((1.0-mix)*frames[ia].lpc[k]+mix*frames[ib].lpc[k]);

        std::array<double,kSpeechHopSamples> block{};
        double energy=0.0;
        const double f0=std::clamp<double>(f.f0Hz*rate,60.0,420.0);
        for(size_t n=0;n<kSpeechHopSamples;++n) {
            rng=mix64(rng+n+of*131);
            const double noise=(double(int64_t(rng>>11)&0x1fffff)/1048576.0)-1.0;
            double voicedSrc=0.0;
            if(f.voiced>0.08f && f.f0Hz>0.0f) {
                phase += 2.0*M_PI*f0/double(kNeuralSpeechRate);
                if(phase>2.0*M_PI) phase-=2.0*M_PI;
                voicedSrc=std::sin(phase)+0.32*std::sin(2.0*phase)+0.14*std::sin(3.0*phase);
            }
            const double excitation=(f.voiced*voicedSrc + (1.0-f.voiced)*0.85*noise)*0.08;
            double y=excitation;
            for(size_t k=0;k<kSpeechLpcOrder;++k) y += double(f.lpc[k])*history[k];
            y=std::clamp(y,-4.0,4.0);
            for(size_t k=kSpeechLpcOrder-1;k>0;--k) history[k]=history[k-1];
            history[0]=y;
            block[n]=y; energy+=y*y;
        }
        const double got=std::sqrt(energy/double(kSpeechHopSamples));
        const double target=std::clamp<double>(f.rms*0.92,0.003,0.70);
        const double gain=got>1e-7?std::clamp(target/got,0.05,8.0):0.0;
        for(double y:block) out.push_back(static_cast<int16_t>(std::clamp(y*gain*32767.0,-32767.0,32767.0)));
    }
    speechFadeEdges(out,kNeuralSpeechRate*4/1000);
    return out;
}

void BrainEngine::learnPrimitive(std::unordered_map<uint64_t, SpeechPrimitive>& table, uint64_t key, std::span<const int16_t> pcm) {
    if (pcm.size() < 80) return;
    std::vector<int16_t> clipped;
    if (pcm.size() > kMaxPrimitiveSamples) {
        const size_t start=(pcm.size()-kMaxPrimitiveSamples)/2;
        clipped.assign(pcm.begin()+static_cast<std::ptrdiff_t>(start),pcm.begin()+static_cast<std::ptrdiff_t>(start+kMaxPrimitiveSamples));
        pcm=clipped;
    }
    auto incoming=analyzeSpeechFrames(pcm);
    if(incoming.empty()) return;
    auto it=table.find(key);
    if(it==table.end()) {
        const size_t cap = (&table == &speechPrimitives_) ? kMaxSpeechPrimitives : kMaxSpeechTransitions;
        if(table.size()>=cap) {
            auto victim=std::min_element(table.begin(),table.end(),[](const auto& a,const auto& b){
                if(a.second.observations!=b.second.observations) return a.second.observations<b.second.observations;
                return a.first<b.first;
            });
            if(victim!=table.end()) table.erase(victim);
        }
        SpeechPrimitive p; p.sampleRate=kNeuralSpeechRate; p.observations=1; p.frames=std::move(incoming);
        table[key]=std::move(p);
        return;
    }

    const size_t target=it->second.frames.size();
    if(!target) { it->second.frames=std::move(incoming); it->second.observations=1; return; }
    const uint16_t obs=std::min<uint16_t>(it->second.observations,15);
    for(size_t i=0;i<target;++i) {
        const double pos=(target<=1||incoming.size()<=1)?0.0:double(i)*(incoming.size()-1)/double(target-1);
        const size_t a=std::min(incoming.size()-1,static_cast<size_t>(pos));
        const size_t b=std::min(incoming.size()-1,a+1);
        const double m=pos-double(a);
        SpeechAcousticFrame v;
        v.f0Hz=float((1.0-m)*incoming[a].f0Hz+m*incoming[b].f0Hz);
        v.rms=float((1.0-m)*incoming[a].rms+m*incoming[b].rms);
        v.voiced=float((1.0-m)*incoming[a].voiced+m*incoming[b].voiced);
        for(size_t k=0;k<kSpeechLpcOrder;++k) v.lpc[k]=float((1.0-m)*incoming[a].lpc[k]+m*incoming[b].lpc[k]);
        auto& d=it->second.frames[i];
        d.f0Hz=(d.f0Hz*obs+v.f0Hz)/float(obs+1);
        d.rms=(d.rms*obs+v.rms)/float(obs+1);
        d.voiced=(d.voiced*obs+v.voiced)/float(obs+1);
        for(size_t k=0;k<kSpeechLpcOrder;++k) d.lpc[k]=(d.lpc[k]*obs+v.lpc[k])/float(obs+1);
    }
    it->second.observations=std::min<uint16_t>(uint16_t(obs+1),uint16_t(16));
}

bool BrainEngine::learnGenerativeSpeech(std::span<const uint8_t> plan, std::span<const int16_t> pcm, int sampleRate) {
    if(plan.empty() || plan.size()>8192) return false;
    const auto canonical=speechCanonicalPcm(pcm,sampleRate);
    if(canonical.empty()) return false;
    const auto tokens=speechPlanTokens(plan);
    if(tokens.empty()) return false;

    struct UnitRef { std::string token; bool sameWordAsPrevious=false; };
    std::vector<UnitRef> units; units.reserve(tokens.size());
    bool boundary=true;
    for(const auto& t:tokens) {
        if(speechControl(t)) { boundary=true; continue; }
        units.push_back({t,!boundary && !units.empty()});
        boundary=false;
    }
    if(units.empty() || units.size()>160) return false;
    if(canonical.size() < units.size()*80) return false;
    const auto bounds=speechAlignmentBoundaries(canonical,units.size());

    std::lock_guard lock(mutex_);
    constexpr size_t context=kNeuralSpeechRate*12/1000; // 12 ms context around a grapheme
    constexpr size_t transHalf=kNeuralSpeechRate*28/1000; // 56 ms learned co-articulation bridge
    std::vector<uint64_t> keys(units.size());
    for(size_t i=0;i<units.size();++i) {
        const auto bytes=std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(units[i].token.data()),units[i].token.size());
        const uint64_t key=speechPrimitiveKey(bytes); keys[i]=key;
        const size_t a=bounds[i]>context?bounds[i]-context:0;
        const size_t z=std::min(canonical.size(),bounds[i+1]+context);
        if(z>a) learnPrimitive(speechPrimitives_,key,std::span<const int16_t>(canonical.data()+a,z-a));

        // Teaching drives the cortical chain. Small populations avoid recurrent overload.
        injectPopulation(Region::Language,key,1.0f,6,cfg_.tokenGain);
        injectPopulation(Region::Semantic,key^0x53454D414E54ull,0.85f,5,cfg_.tokenGain);
        injectPopulation(Region::Association,key^0x4153534F43ull,0.70f,5,cfg_.tokenGain);
        injectPopulation(Region::Pfc,key^0x504C414Eull,0.55f,4,cfg_.tokenGain);
        injectPopulation(Region::Cerebellum,key^0x54494D45ull,0.45f,4,cfg_.tokenGain);
        injectPopulation(Region::VocalMotor,key^0x564F43414Cull,1.0f,8,1.25f);

        if(i>0 && units[i].sameWordAsPrevious) {
            const size_t c=bounds[i];
            const size_t ta=c>transHalf?c-transHalf:0;
            const size_t tz=std::min(canonical.size(),c+transHalf);
            if(tz>ta) learnPrimitive(speechTransitions_,speechTransitionKey(keys[i-1],key),
                                     std::span<const int16_t>(canonical.data()+ta,tz-ta));
        }
    }

    // Heard target also enters Auditory so the learned motor plan remains multisensory.
    ++pendingAudioChunks_;
    const auto bands=enc::audioBands(canonical,kNeuralSpeechRate,enc::kAudioBands,16);
    pendingAudioBands_ += bands.size();
    std::array<float,enc::kAudioBands> current{};
    for(const auto& f:bands){const uint32_t b=std::min<uint32_t>(uint32_t(f.key),enc::kAudioBands-1);current[b]=std::max(current[b],f.magnitude);}
    for(uint32_t b=0;b<enc::kAudioBands;++b) if(current[b]>0.0f) pendingAudioInjections_ += injectAudioBand(b,current[b],current[b]);
    previousAudioBands_=current; havePreviousAudio_=true;
    return true;
}

std::vector<int16_t> BrainEngine::renderGenerativeSpeech(std::span<const uint8_t> plan) {
    if(plan.empty() || plan.size()>8192) return {};
    const auto tokens=speechPlanTokens(plan);
    if(tokens.empty()) return {};
    size_t totalUnits=0; bool question=false;
    for(const auto& t:tokens){ if(!speechControl(t)) ++totalUnits; else if(t=="#q") question=true; }
    if(!totalUnits) return {};

    std::lock_guard lock(mutex_);
    // Missing primitive means the cortex has not learned enough to generate this utterance.
    for(const auto& t:tokens) if(!speechControl(t)) {
        const auto bytes=std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(t.data()),t.size());
        if(speechPrimitives_.find(speechPrimitiveKey(bytes))==speechPrimitives_.end()) return {};
    }

    std::vector<int16_t> out; out.reserve(std::min<size_t>(kMaxGeneratedSamples,totalUnits*1800));
    uint64_t previousKey=0; bool havePrevious=false; size_t unitIndexNow=0;
    constexpr size_t baseFade=kNeuralSpeechRate*12/1000;
    constexpr size_t bridgeFade=kNeuralSpeechRate*7/1000;
    for(const auto& t:tokens) {
        if(speechControl(t)) {
            if(t=="#w") speechAppendSilence(out,kNeuralSpeechRate*32/1000);
            else if(t=="#c") speechAppendSilence(out,kNeuralSpeechRate*90/1000);
            else if(t=="#p") speechAppendSilence(out,kNeuralSpeechRate*155/1000);
            else if(t=="#q") speechAppendSilence(out,kNeuralSpeechRate*125/1000);
            else if(t=="#e") speechAppendSilence(out,kNeuralSpeechRate*75/1000);
            havePrevious=false; previousKey=0;
            continue;
        }
        const auto bytes=std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(t.data()),t.size());
        const uint64_t key=speechPrimitiveKey(bytes);

        // Sequence-level prosody: a statement settles at the end; a question rises.
        // `rate` modulates both motor timing and the reconstructed F0 trajectory.
        const double pos=totalUnits<=1?1.0:double(unitIndexNow)/double(totalUnits-1);
        double rate=1.0;
        if(pos>0.72) {
            const double tpos=(pos-0.72)/0.28;
            rate = question ? (1.0 + 0.085*tpos) : (1.0 - 0.045*tpos);
        }
        auto piece=synthesizeSpeechFrames(speechPrimitives_.at(key).frames,key,rate);

        if(havePrevious) {
            const auto tr=speechTransitions_.find(speechTransitionKey(previousKey,key));
            if(tr!=speechTransitions_.end()) {
                auto bridge=synthesizeSpeechFrames(tr->second.frames,speechTransitionKey(previousKey,key),1.0);
                const size_t wanted=std::min<size_t>(bridge.size(),kNeuralSpeechRate*45/1000);
                if(wanted && bridge.size()>wanted) {
                    const size_t start=(bridge.size()-wanted)/2;
                    std::vector<int16_t> mid(bridge.begin()+static_cast<std::ptrdiff_t>(start),bridge.begin()+static_cast<std::ptrdiff_t>(start+wanted));
                    speechAppendCrossfade(out,mid,bridgeFade);
                } else speechAppendCrossfade(out,bridge,bridgeFade);
            }
        }
        speechAppendCrossfade(out,piece,baseFade);

        // Generation drives plan, timing and motor populations independently of Android audio.
        injectPopulation(Region::Language,key,0.85f,5,cfg_.tokenGain);
        injectPopulation(Region::Semantic,key^0x53454D414E54ull,0.75f,4,cfg_.tokenGain);
        injectPopulation(Region::Association,key^0x4153534F43ull,0.65f,4,cfg_.tokenGain);
        injectPopulation(Region::Pfc,key^0x504C414Eull,0.60f,4,cfg_.tokenGain);
        injectPopulation(Region::Cerebellum,key^0x50524F53ull,0.55f,4,cfg_.tokenGain);
        injectPopulation(Region::VocalMotor,key^0x564F43414Cull,1.0f,9,1.30f);
        previousKey=key; havePrevious=true; ++unitIndexNow;
        if(out.size()>=kMaxGeneratedSamples) break;
    }
    if(out.empty()) return {};
    speechFadeEdges(out,kNeuralSpeechRate*8/1000);
    ++speechRenderCount_; ++generatedSpeechCount_;
    return out;
}


bool BrainEngine::learnBioSpeech(std::span<const uint8_t> plan, std::span<const int16_t> pcm, int sampleRate) {
    if (plan.empty() || plan.size() > 8192 || pcm.empty()) return false;
    std::lock_guard lock(mutex_);
    if (!bioSpeech_.learn(plan, pcm, sampleRate)) return false;

    // Teaching traverses lamina-like subranges instead of treating each named region as
    // a monolithic population. Banks are a compact approximation of L4 -> L2/3 -> L5/L6.
    const auto tokens = speechPlanTokens(plan);
    for (const auto& t : tokens) {
        if (speechControl(t)) continue;
        const auto bytes = std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(t.data()), t.size());
        const uint64_t key = enc::hashBytes(0x42494F53u, bytes);
        injectDistributedSubrange(Region::Auditory, 0, 4, key ^ 0x4C34u, 0.85f, 0.10f, cfg_.audioGain, 8);       // L4 sensory input
        injectDistributedSubrange(Region::Auditory, 1, 4, key ^ 0x4C3233u, 0.75f, 0.08f, cfg_.audioGain, 7);     // L2/3 feature state
        injectSpeechMicrocircuit(Region::Auditory,0,0,key^0x41344C,0.85f,cfg_.audioGain,6); // L4 pyramidal
        injectSpeechMicrocircuit(Region::Auditory,1,0,key^0x413233,0.72f,cfg_.audioGain,6);// L2/3 pyramidal
        injectSpeechMicrocircuit(Region::Auditory,1,1,key^0x415056,0.55f,cfg_.audioGain,3);// PV timing/inhibition
        injectDistributedSubrange(Region::Language, 1, 4, key ^ 0x50484F4Eu, 0.90f, 0.10f, cfg_.tokenGain, 7);   // phonological plan
        injectSpeechMicrocircuit(Region::Language,1,0,key^0x4C3233,0.85f,cfg_.tokenGain,6); // L2/3 pyramidal
        injectSpeechMicrocircuit(Region::Language,1,3,key^0x4C564950,0.45f,cfg_.tokenGain,2);// VIP disinhibition
        injectSpeechMicrocircuit(Region::Language,3,0,key^0x4C36,0.50f,cfg_.tokenGain,4);   // L6 corticothalamic proxy
        injectDistributedSubrange(Region::Pfc, 1, 4, key ^ 0x534551u, 0.72f, 0.08f, cfg_.tokenGain, 6);          // sequence plan
        injectDistributedSubrange(Region::BasalGanglia, 0, 2, key ^ 0x47415445u, 0.60f, 0.07f, 1.0f, 5);        // gating/initiation
        injectDistributedSubrange(Region::Thalamus, 0, 2, key ^ 0x5448414Cu, 0.58f, 0.07f, 1.0f, 5);            // cortico-thalamic relay
        injectDistributedSubrange(Region::Cerebellum, 1, 3, key ^ 0x465744u, 0.65f, 0.08f, 1.0f, 6);            // forward model
        injectDistributedSubrange(Region::Motor, 2, 4, key ^ 0x56504D43u, 0.78f, 0.10f, cfg_.motorGain*0.18f, 7);// vPMC-like program
        injectSpeechMicrocircuit(Region::Motor,1,0,key^0x56504D3233,0.68f,0.90f,5); // vPMC L2/3 plan
        injectSpeechMicrocircuit(Region::Motor,2,0,key^0x56504D35,0.82f,1.00f,6);   // vPMC L5 output
        injectSpeechMicrocircuit(Region::Motor,2,2,key^0x56504D535354,0.38f,0.90f,2);// SST surround
        injectDistributedSubrange(Region::VocalMotor, 2, 4, key ^ 0x564D31u, 1.00f, 0.13f, 1.25f, 9);            // vM1-like command
        injectSpeechMicrocircuit(Region::VocalMotor,2,0,key^0x564D314C35,1.00f,1.25f,7);// vM1 L5 pyramidal
        injectSpeechMicrocircuit(Region::VocalMotor,2,1,key^0x564D315056,0.50f,1.00f,2);// PV temporal precision
        injectDistributedSubrange(Region::Somatosensory, 0, 4, key ^ 0x5331u, 0.55f, 0.07f, cfg_.touchGain, 5);  // articulator state
    }
    return true;
}

std::vector<int16_t> BrainEngine::renderBioSpeech(std::span<const uint8_t> plan) {
    if (plan.empty() || plan.size() > 8192) return {};
    std::lock_guard lock(mutex_);
    auto pcm = bioSpeech_.render(plan);
    if (pcm.empty()) return {};
    ++bioSpeechRenderCount_;

    const auto tokens = speechPlanTokens(plan);
    for (const auto& t : tokens) {
        if (speechControl(t)) continue;
        const auto bytes = std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(t.data()), t.size());
        const uint64_t key = enc::hashBytes(0x42494F53u, bytes);
        injectDistributedSubrange(Region::Language, 1, 4, key ^ 0x50484F4Eu, 0.82f, 0.09f, cfg_.tokenGain, 6);
        injectDistributedSubrange(Region::Pfc, 2, 4, key ^ 0x504C414Eu, 0.70f, 0.08f, cfg_.tokenGain, 6);
        injectDistributedSubrange(Region::BasalGanglia, 0, 2, key ^ 0x47415445u, 0.62f, 0.07f, 1.0f, 5);
        injectDistributedSubrange(Region::Thalamus, 1, 2, key ^ 0x5448414Cu, 0.55f, 0.07f, 1.0f, 5);
        injectDistributedSubrange(Region::Motor, 2, 4, key ^ 0x56504D43u, 0.78f, 0.10f, cfg_.motorGain*0.18f, 7);
        injectSpeechMicrocircuit(Region::Pfc,1,0,key^0x5046433233,0.66f,cfg_.tokenGain,5);
        injectSpeechMicrocircuit(Region::Pfc,2,0,key^0x50464335,0.72f,cfg_.tokenGain,5);
        injectSpeechMicrocircuit(Region::Motor,1,0,key^0x56504D3233,0.68f,0.90f,5);
        injectSpeechMicrocircuit(Region::Motor,2,0,key^0x56504D35,0.84f,1.00f,6);
        injectDistributedSubrange(Region::VocalMotor, 3, 4, key ^ 0x564D31u, 1.00f, 0.14f, 1.30f, 9);
        injectSpeechMicrocircuit(Region::VocalMotor,2,0,key^0x564D314C35,1.00f,1.30f,7);
        injectSpeechMicrocircuit(Region::VocalMotor,2,1,key^0x564D315056,0.52f,1.00f,2);
        injectDistributedSubrange(Region::Brainstem, 0, 2, key ^ 0x4E55434Cu, 0.62f, 0.08f, 1.0f, 5);
    }

    // Prediction-error populations are driven by the actual closed-loop result.
    const auto d = bioSpeech_.diagnostics();
    const float ae = static_cast<float>(std::clamp(d.auditoryErrorAfter, 0.0, 1.0));
    const float se = static_cast<float>(std::clamp(d.somatosensoryError, 0.0, 1.0));
    if (ae > 1e-4f) {
        injectDistributedSubrange(Region::Auditory, 2, 4, 0x415544455252ull, ae, 0.08f, cfg_.audioGain, 7);
        injectDistributedSubrange(Region::Cerebellum, 2, 3, 0x4342455252ull, ae, 0.08f, 1.0f, 7);
    }
    if (se > 1e-4f) {
        injectDistributedSubrange(Region::Somatosensory, 1, 4, 0x534F4D455252ull, se, 0.08f, cfg_.touchGain, 7);
        injectDistributedSubrange(Region::Cerebellum, 2, 3, 0x534F4D4342ull, se, 0.07f, 1.0f, 6);
    }
    return pcm;
}

bool BrainEngine::hasBioSpeechPrimitive(std::span<const uint8_t> unit) const {
    std::lock_guard lock(mutex_);
    return bioSpeech_.hasPrimitive(unit);
}

uint32_t BrainEngine::learnedBioSpeechPrimitives() const {
    std::lock_guard lock(mutex_);
    return bioSpeech_.primitiveCount();
}

void BrainEngine::setBioSpeechPerturbation(float auditoryF1ShiftHz, float auditoryF2ShiftHz, float jawOffset) {
    std::lock_guard lock(mutex_);
    BioSpeechModel::Perturbation p;
    p.auditoryF1ShiftHz = std::clamp(auditoryF1ShiftHz, -500.0f, 500.0f);
    p.auditoryF2ShiftHz = std::clamp(auditoryF2ShiftHz, -800.0f, 800.0f);
    p.jawOffset = std::clamp(jawOffset, -0.5f, 0.5f);
    bioSpeech_.setPerturbation(p);
}

void BrainEngine::setBioSpeechLesionMask(uint32_t mask) {
    std::lock_guard lock(mutex_);
    bioSpeech_.setLesionMask(mask & 0x3Fu);
}

BioSpeechModel::Diagnostics BrainEngine::bioSpeechDiagnostics() const {
    std::lock_guard lock(mutex_);
    return bioSpeech_.diagnostics();
}

bool BrainEngine::hasSpeechPrimitive(std::span<const uint8_t> unit) const {
    if(unit.empty()||unit.size()>64) return false;
    std::lock_guard lock(mutex_);
    return speechPrimitives_.find(speechPrimitiveKey(unit))!=speechPrimitives_.end();
}

uint32_t BrainEngine::learnedSpeechPrimitives() const {
    std::lock_guard lock(mutex_);
    return static_cast<uint32_t>(speechPrimitives_.size());
}

void BrainEngine::clearSpeech() {
    std::lock_guard lock(mutex_);
    speechEngrams_.clear();
    speechPrimitives_.clear();
    speechTransitions_.clear();
    bioSpeech_.clear();
    speechRenderCount_ = 0;
    generatedSpeechCount_ = 0;
    bioSpeechRenderCount_ = 0;
}

uint32_t BrainEngine::learnedSpeechUnits() const {
    std::lock_guard lock(mutex_);
    return static_cast<uint32_t>(speechEngrams_.size()+speechPrimitives_.size()+speechTransitions_.size()+bioSpeech_.primitiveCount()+bioSpeech_.transitionCount());
}

void BrainEngine::resetDiagnostics() {
    std::lock_guard lock(mutex_);
    emaRegionSpikesPerSecond_.fill(0.0);
    emaCameraFramesPerSecond_ = emaVisionFramesPerSecond_ = 0.0;
    emaVisionFeaturesPerSecond_ = emaVisionInjectionsPerSecond_ = 0.0;
    emaAudioChunksPerSecond_ = emaAudioBandsPerSecond_ = emaAudioInjectionsPerSecond_ = 0.0;
    emaTouchEventsPerSecond_ = emaTouchInjectionsPerSecond_ = 0.0;
    emaImuEventsPerSecond_ = emaImuChangesPerSecond_ = emaImuInjectionsPerSecond_ = 0.0;
    emaEnvironmentEventsPerSecond_ = emaEnvironmentChangesPerSecond_ = emaEnvironmentInjectionsPerSecond_ = 0.0;
    emaLocationEventsPerSecond_ = emaLocationInjectionsPerSecond_ = 0.0;
    emaExternalTokensPerSecond_ = emaExternalInjectionsPerSecond_ = 0.0;
    pendingCameraFrames_ = pendingVisionFrames_ = pendingVisionFeatures_ = pendingVisionInjections_ = 0;
    pendingAudioChunks_ = pendingAudioBands_ = pendingAudioInjections_ = 0;
    pendingTouchEvents_ = pendingTouchInjections_ = 0;
    pendingImuEvents_ = pendingImuChanges_ = pendingImuInjections_ = 0;
    pendingEnvironmentEvents_ = pendingEnvironmentChanges_ = pendingEnvironmentInjections_ = 0;
    pendingLocationEvents_ = pendingLocationInjections_ = 0;
    pendingExternalTokens_ = pendingExternalInjections_ = 0;
    previousVision_.clear();
    previousAudioBands_.fill(0.0f); havePreviousAudio_=false;
    previousMotionSensor_.clear(); previousEnvironmentLevel_.clear(); previousTouch_={};
}

void BrainEngine::applyLazyDecay(uint32_t neuron) {
    const uint32_t last = lastUpdateTick_[neuron];
    const uint32_t dt = static_cast<uint32_t>(tick_ - last);
    if (dt) {
        const auto p=corticalPhenotype(neuron);
        membrane_[neuron] = fastDecay(membrane_[neuron], dt, p.membraneDecay);
        apicalDendrite_[neuron] = fastDecay(apicalDendrite_[neuron], dt, p.apicalDecay);
        adaptation_[neuron] = fastDecay(adaptation_[neuron], dt, p.adaptationDecay);
    }
    lastUpdateTick_[neuron] = static_cast<uint32_t>(tick_);
}

void BrainEngine::fire(uint32_t neuron, std::vector<uint32_t>& fired) {
    const auto p=corticalPhenotype(neuron);
    membrane_[neuron] = cfg_.resetPotential;
    if(p.excitatory) apicalDendrite_[neuron] *= 0.35f;
    adaptation_[neuron] = std::min(1.5f, adaptation_[neuron] + p.adaptationIncrement);
    lastSpikeTick_[neuron] = static_cast<uint32_t>(tick_);
    fired.push_back(neuron);
}

void BrainEngine::propagate(std::span<const uint32_t> fired, std::vector<TraceEdge>* traceEdges) {
    const uint32_t localSlots = static_cast<uint32_t>(cfg_.fanout * cfg_.localFraction);
    const uint32_t structuredLocalSlots = static_cast<uint32_t>(localSlots * std::clamp(cfg_.structuredCorticalFraction,0.0f,0.75f));
    if (traceEdges) {
        size_t expected = 0;
        if (fired.size() <= (std::numeric_limits<size_t>::max() / std::max<uint32_t>(1,cfg_.fanout)))
            expected = fired.size() * size_t(cfg_.fanout);
        traceEdges->clear();
        traceEdges->reserve(expected);
    }
    for (uint32_t src : fired) {
        const Region sr = regionOf(src);
        // Dedicated action output pool remains isolated from common-mode recurrent noise.
        // VocalMotor is driven by the explicit BioSpeech motor program.
        if (sr == Region::Motor || sr == Region::VocalMotor) continue;
        const auto sp = corticalPhenotype(src);
        const bool srcCortical = cfg_.biologicalCortex && isCorticalRegion(sr);
        const bool exc = sp.excitatory;
        const float baseWeight = exc ? cfg_.excitatoryWeight : -cfg_.inhibitoryWeight;
        const auto rr = regions_[static_cast<size_t>(sr)];
        const uint32_t localN = std::max<uint32_t>(1, rr.end - rr.begin);
        for (uint32_t slot = 0; slot < cfg_.fanout; ++slot) {
            const uint64_t h = mix64(cfg_.seed ^ (uint64_t(src) << 32) ^ uint64_t(slot) * 0xD6E8FEB86659FD93ull);
            uint32_t target = 0;
            float weightScale = 1.0f;
            DendriticCompartment compartment = DendriticCompartment::Soma;
            bool local = slot < localSlots;
            bool structured = false;

            if (srcCortical && local && slot < structuredLocalSlots) {
                const auto rule=CorticalMicrocircuit::localRule(sp);
                target=structuredCorticalTarget(sr,rule.targetLayer,rule.preferredTarget,h);
                weightScale=rule.weightScale;
                compartment=rule.compartment;
                structured=true;
            } else if (srcCortical && !exc && !local) {
                // Cortical inhibitory interneurons are local: redirect nominal long-range
                // inhibitory slots back into the local laminar microcircuit.
                const auto rule=CorticalMicrocircuit::localRule(sp);
                target=structuredCorticalTarget(sr,rule.targetLayer,rule.preferredTarget,h);
                weightScale=rule.weightScale;
                compartment=rule.compartment;
                local=true; structured=true;
            } else if (local) {
                target = rr.begin + static_cast<uint32_t>(h % localN);
            } else {
                target = static_cast<uint32_t>(h % cfg_.neurons);
                const Region tr=regionOf(target);
                if (cfg_.biologicalCortex && isCorticalRegion(tr)) {
                    if (sr==Region::Thalamus) {
                        const CorticalLayer layer=((h>>12)&1ull)?CorticalLayer::L4:CorticalLayer::L6;
                        target=structuredCorticalTarget(tr,layer,CorticalCellClass::IT,h);
                        weightScale=0.92f; compartment=DendriticCompartment::Soma; structured=true;
                    } else if (srcCortical) {
                        const bool feedback=corticalHierarchy(sr)>corticalHierarchy(tr);
                        const auto rule=CorticalMicrocircuit::longRangeRule(sp,feedback);
                        target=structuredCorticalTarget(tr,rule.targetLayer,rule.preferredTarget,h);
                        weightScale=rule.weightScale; compartment=rule.compartment; structured=true;
                    }
                }
            }
            // Motor output pools are isolated from unrelated recurrent common-mode noise.
            if (target >= motor_.begin && target < motor_.end) continue;
            if (cfg_.biologicalCortex && srcCortical && !exc && isCorticalRegion(regionOf(target))) {
                weightScale *= CorticalMicrocircuit::inhibitionScale(sp.cell,corticalPhenotype(target).cell);
            }
            const Region tr=regionOf(target);
            const uint32_t hierarchyDistance=(isCorticalRegion(sr)&&isCorticalRegion(tr))
                ? static_cast<uint32_t>(std::abs(corticalHierarchy(sr)-corticalHierarchy(tr))+1) : 1u;
            const uint32_t delay = CorticalMicrocircuit::conductionDelayTicks(local,cfg_.recurrentDelayMax,h,hierarchyDistance);
            schedule(target, baseWeight*weightScale, delay, compartment);
            if(structured) ++corticalStructuredEdges_;
            if (traceEdges) traceEdges->push_back({src,target,static_cast<uint16_t>(delay),static_cast<int8_t>(exc?1:-1)});
            ++edgeEventsTotal_;
        }
    }
}

void BrainEngine::processMotor(std::span<const uint32_t> fired) {
    for (uint32_t n : fired) {
        if (n >= association_.begin && n < association_.end && isExcitatory(n)) {
            const uint32_t ix = n - association_.begin;
            motorEvidence_ += motorDifferential_[ix];
            if (featureCounts_[ix] == 0) featureTouched_.push_back(ix);
            if (featureCounts_[ix] != std::numeric_limits<uint16_t>::max()) ++featureCounts_[ix];
        } else if (n >= motor_.begin && n < motor_.end) {
            const uint32_t half = std::max<uint32_t>(1, (motor_.end - motor_.begin)/2);
            const int a = (n - motor_.begin) < half ? 0 : 1;
            ++motorSpikesWindow_[a];
        }
    }

    // Convert only differential evidence into opponent E/I population current.
    if (std::abs(motorEvidence_) > 1e-9) {
        const uint32_t half = std::max<uint32_t>(1, (motor_.end - motor_.begin)/2);
        const float q = std::min<float>(2.5f, std::abs(float(motorEvidence_)) * cfg_.motorGain);
        const int favored = motorEvidence_ > 0 ? 0 : 1;
        const uint32_t begin = motor_.begin + (favored ? half : 0);
        const uint32_t end = favored ? motor_.end : std::min(motor_.begin + half, motor_.end);
        for (uint32_t n = begin; n < end; ++n) schedule(n, q, 1);
        motorEvidence_ = 0.0;
    }
}

void BrainEngine::resetCurrentFeature() {
    for (uint32_t ix : featureTouched_) featureCounts_[ix] = 0;
    featureTouched_.clear();
}

void BrainEngine::finishActionWindow() {
    lastFeature_.clear();
    lastFeature_.reserve(featureTouched_.size());
    for (uint32_t ix : featureTouched_) if (featureCounts_[ix]) lastFeature_.push_back({ix, featureCounts_[ix]});
    const int64_t margin = int64_t(motorSpikesWindow_[0]) - int64_t(motorSpikesWindow_[1]);
    lastMotorMargin_ = double(margin);
    if (lastFeature_.empty()) lastAction_ = -1;
    else if (margin > 0) lastAction_ = 0;
    else if (margin < 0) lastAction_ = 1;
    else if (mode_ == RunMode::Learn) lastAction_ = int(mix64(cfg_.seed ^ tick_) & 1ull); // explicit exploration only while learning
    else lastAction_ = -1;
    ++actionEpoch_;
    motorSpikesWindow_ = {0,0};
    resetCurrentFeature();
}

void BrainEngine::step() {
    const auto t0 = std::chrono::steady_clock::now();
    std::lock_guard lock(mutex_);
    const uint64_t edgesBefore = edgeEventsTotal_;
    auto& bucket = eventRing_[tick_ % eventRing_.size()];
    touched_.clear();
    if (++touchEpoch_ == 0) { std::fill(touchMarker_.begin(), touchMarker_.end(), 0); touchEpoch_ = 1; }
    for (const auto& e : bucket) {
        const uint32_t n = e.target;
        applyLazyDecay(n);
        const bool apical = e.compartment == static_cast<uint8_t>(DendriticCompartment::Apical) &&
                            cfg_.biologicalCortex && isCorticalRegion(regionOf(n));
        if (apical) {
            apicalDendrite_[n] += e.weight;
            ++corticalApicalEvents_;
        } else membrane_[n] += e.weight;
        if (touchMarker_[n] != touchEpoch_) { touchMarker_[n] = touchEpoch_; touched_.push_back(n); }
    }
    bucket.clear();

    std::vector<uint32_t> fired;
    fired.reserve(touched_.size()/4 + 16);
    for (uint32_t n : touched_) {
        const auto p=corticalPhenotype(n);
        const uint32_t since = static_cast<uint32_t>(tick_ - lastSpikeTick_[n]);
        if (since <= p.refractoryTicks) continue;
        const float before=membrane_[n];
        const float integrated=CorticalMicrocircuit::dendriticCoincidence(p,before,apicalDendrite_[n]);
        if(integrated>before+1e-6f){ membrane_[n]=integrated; ++corticalDendriticCoincidences_; }
        const float threshold=thresholdFor(n)*p.thresholdScale + adaptation_[n];
        if (membrane_[n] >= threshold) fire(n, fired);
    }
    spikesLastStep_ = static_cast<uint32_t>(fired.size());
    spikesTotal_ += fired.size();

    std::array<uint32_t, static_cast<size_t>(Region::Count)> regionCounts{};
    for (uint32_t n : fired) {
        const Region r=regionOf(n);
        ++regionCounts[static_cast<size_t>(r)];
        if(cfg_.biologicalCortex && isCorticalRegion(r)){
            const auto p=corticalPhenotype(n);
            ++corticalLayerSpikes_[static_cast<size_t>(p.layer)];
            ++corticalCellSpikes_[static_cast<size_t>(p.cell)];
        }
    }

    processMotor(fired);
    if (traceEnabled_) {
        TraceFrame frame;
        frame.tick = tick_;
        frame.fired = fired;
        propagate(fired, &frame.edges);
        traceFrames_.push_back(std::move(frame));
        while (traceFrames_.size() > kTraceHistoryFrames) traceFrames_.pop_front();
    } else {
        propagate(fired, nullptr);
    }
    ++tick_;
    if (cfg_.actionWindowTicks && tick_ % cfg_.actionWindowTicks == 0) finishActionWindow();

    const auto t1 = std::chrono::steady_clock::now();
    lastStepMs_ = std::chrono::duration<double, std::milli>(t1 - t0).count();
    emaStepMs_ = emaStepMs_ == 0 ? lastStepMs_ : 0.95*emaStepMs_ + 0.05*lastStepMs_;
    const double sec = std::max(1e-6, cfg_.timestepMs / 1000.0);
    const double sps = fired.size()/sec;
    updateEma(emaSpikesPerSecond_, sps);
    const double eps = double(edgeEventsTotal_ - edgesBefore) / sec;
    updateEma(emaEdgesPerSecond_, eps);
    for (size_t r=0; r<regionCounts.size(); ++r) updateEma(emaRegionSpikesPerSecond_[r], regionCounts[r]/sec);

    updateEma(emaCameraFramesPerSecond_, pendingCameraFrames_/sec);
    updateEma(emaVisionFramesPerSecond_, pendingVisionFrames_/sec);
    updateEma(emaVisionFeaturesPerSecond_, pendingVisionFeatures_/sec);
    updateEma(emaVisionInjectionsPerSecond_, pendingVisionInjections_/sec);
    updateEma(emaAudioChunksPerSecond_, pendingAudioChunks_/sec);
    updateEma(emaAudioBandsPerSecond_, pendingAudioBands_/sec);
    updateEma(emaAudioInjectionsPerSecond_, pendingAudioInjections_/sec);
    updateEma(emaTouchEventsPerSecond_, pendingTouchEvents_/sec);
    updateEma(emaTouchInjectionsPerSecond_, pendingTouchInjections_/sec);
    updateEma(emaImuEventsPerSecond_, pendingImuEvents_/sec);
    updateEma(emaImuChangesPerSecond_, pendingImuChanges_/sec);
    updateEma(emaImuInjectionsPerSecond_, pendingImuInjections_/sec);
    updateEma(emaEnvironmentEventsPerSecond_, pendingEnvironmentEvents_/sec);
    updateEma(emaEnvironmentChangesPerSecond_, pendingEnvironmentChanges_/sec);
    updateEma(emaEnvironmentInjectionsPerSecond_, pendingEnvironmentInjections_/sec);
    updateEma(emaLocationEventsPerSecond_, pendingLocationEvents_/sec);
    updateEma(emaLocationInjectionsPerSecond_, pendingLocationInjections_/sec);
    updateEma(emaExternalTokensPerSecond_, pendingExternalTokens_/sec);
    updateEma(emaExternalInjectionsPerSecond_, pendingExternalInjections_/sec);

    pendingCameraFrames_ = pendingVisionFrames_ = pendingVisionFeatures_ = pendingVisionInjections_ = 0;
    pendingAudioChunks_ = pendingAudioBands_ = pendingAudioInjections_ = 0;
    pendingTouchEvents_ = pendingTouchInjections_ = 0;
    pendingImuEvents_ = pendingImuChanges_ = pendingImuInjections_ = 0;
    pendingEnvironmentEvents_ = pendingEnvironmentChanges_ = pendingEnvironmentInjections_ = 0;
    pendingLocationEvents_ = pendingLocationInjections_ = 0;
    pendingExternalTokens_ = pendingExternalInjections_ = 0;
}

void BrainEngine::setTraceEnabled(bool enabled) {
    std::lock_guard lock(mutex_);
    traceEnabled_ = enabled;
    traceFrames_.clear();
}

std::vector<int32_t> BrainEngine::traceFrame(size_t back) const {
    std::lock_guard lock(mutex_);
    if (!traceEnabled_ || traceFrames_.empty() || back >= traceFrames_.size()) return {};
    const auto& f = traceFrames_[traceFrames_.size() - 1 - back];
    // Binary int layout:
    // [version, tickLo, tickHi, neuronCount, edgeCount, totalNeurons, historyDepth,
    //  fired neuron ids..., edge(source,target,delay,sign)*]
    constexpr int32_t version = 1;
    const size_t header = 7;
    const size_t edgeInts = 4;
    if (f.edges.size() > (std::numeric_limits<size_t>::max() - header - f.fired.size()) / edgeInts) return {};
    std::vector<int32_t> out;
    out.reserve(header + f.fired.size() + edgeInts * f.edges.size());
    out.push_back(version);
    out.push_back(static_cast<int32_t>(f.tick & 0xffffffffull));
    out.push_back(static_cast<int32_t>((f.tick >> 32) & 0xffffffffull));
    out.push_back(static_cast<int32_t>(f.fired.size()));
    out.push_back(static_cast<int32_t>(f.edges.size()));
    out.push_back(static_cast<int32_t>(std::min<uint64_t>(cfg_.neurons, uint64_t(std::numeric_limits<int32_t>::max()))));
    out.push_back(static_cast<int32_t>(traceFrames_.size()));
    for (uint32_t n : f.fired) out.push_back(static_cast<int32_t>(n));
    for (const auto& e : f.edges) {
        out.push_back(static_cast<int32_t>(e.source));
        out.push_back(static_cast<int32_t>(e.target));
        out.push_back(static_cast<int32_t>(e.delay));
        out.push_back(static_cast<int32_t>(e.sign));
    }
    return out;
}

void BrainEngine::reward(bool positive) {
    std::lock_guard lock(mutex_);
    if (lastAction_ < 0 || lastFeature_.empty()) return;
    if (!positive && (mode_ == RunMode::Learn || mode_ == RunMode::Act)) {
        for (const auto& f : lastFeature_) {
            if (f.index >= motorDifferential_.size()) continue;
            float& d = motorDifferential_[f.index];
            d = core53ErrorUpdate(d, f.count, lastAction_, cfg_.learningRate);
        }
        ++reinforcedEpisodes_;
    }
}

void BrainEngine::setMode(RunMode mode) { std::lock_guard lock(mutex_); mode_ = mode; }
RunMode BrainEngine::mode() const { std::lock_guard lock(mutex_); return mode_; }

uint64_t BrainEngine::memoryBytesUnsafe() const {
    uint64_t bytes = membrane_.capacity()*sizeof(float) + apicalDendrite_.capacity()*sizeof(float) +
        adaptation_.capacity()*sizeof(float) + lastUpdateTick_.capacity()*sizeof(uint32_t) +
        lastSpikeTick_.capacity()*sizeof(uint32_t) + touchMarker_.capacity()*sizeof(uint16_t) +
        motorDifferential_.capacity()*sizeof(float) + featureCounts_.capacity()*sizeof(uint16_t) +
        previousVision_.capacity();
    for (const auto& [_, e] : speechEngrams_) bytes += sizeof(SpeechEngram) + e.compandedPcm.capacity();
    for (const auto& [_, e] : speechPrimitives_) bytes += sizeof(SpeechPrimitive) + e.frames.capacity()*sizeof(SpeechAcousticFrame);
    for (const auto& [_, e] : speechTransitions_) bytes += sizeof(SpeechPrimitive) + e.frames.capacity()*sizeof(SpeechAcousticFrame);
    bytes += bioSpeech_.memoryBytes();
    for (auto& b : eventRing_) bytes += b.capacity()*sizeof(Event);
    return bytes;
}

Stats BrainEngine::stats() const {
    std::lock_guard lock(mutex_);
    uint64_t q = 0; for (const auto& b : eventRing_) q += b.size();
    Stats s;
    s.neurons = cfg_.neurons; s.logicalSynapses = cfg_.neurons * uint64_t(cfg_.fanout);
    s.tick=tick_; s.spikesTotal=spikesTotal_; s.edgeEventsTotal=edgeEventsTotal_;
    s.spikesLastStep=spikesLastStep_; s.queuedEvents=q; s.lastStepMs=lastStepMs_;
    s.spikesPerSecond=emaSpikesPerSecond_; s.edgesPerSecond=emaEdgesPerSecond_;
    s.stepHz=emaStepMs_>0 ? 1000.0/emaStepMs_ : 0.0;
    s.regionSpikesPerSecond=emaRegionSpikesPerSecond_;
    s.cameraFramesPerSecond=emaCameraFramesPerSecond_; s.visionFramesPerSecond=emaVisionFramesPerSecond_;
    s.visionFeaturesPerSecond=emaVisionFeaturesPerSecond_; s.visionInjectionsPerSecond=emaVisionInjectionsPerSecond_;
    s.audioChunksPerSecond=emaAudioChunksPerSecond_; s.audioBandsPerSecond=emaAudioBandsPerSecond_;
    s.audioInjectionsPerSecond=emaAudioInjectionsPerSecond_;
    s.touchEventsPerSecond=emaTouchEventsPerSecond_; s.touchInjectionsPerSecond=emaTouchInjectionsPerSecond_;
    s.imuEventsPerSecond=emaImuEventsPerSecond_; s.imuChangesPerSecond=emaImuChangesPerSecond_; s.imuInjectionsPerSecond=emaImuInjectionsPerSecond_;
    s.environmentEventsPerSecond=emaEnvironmentEventsPerSecond_; s.environmentChangesPerSecond=emaEnvironmentChangesPerSecond_; s.environmentInjectionsPerSecond=emaEnvironmentInjectionsPerSecond_;
    s.locationEventsPerSecond=emaLocationEventsPerSecond_; s.locationInjectionsPerSecond=emaLocationInjectionsPerSecond_;
    s.externalTokensPerSecond=emaExternalTokensPerSecond_; s.externalInjectionsPerSecond=emaExternalInjectionsPerSecond_;
    s.currentAction=lastAction_; s.actionEpoch=actionEpoch_;
    s.motorMargin=lastMotorMargin_;
    double dsum=0.0; for(float d: motorDifferential_) dsum += std::abs(double(d));
    s.motorDifferential = motorDifferential_.empty()?0.0:dsum/motorDifferential_.size();
    s.reinforcedEpisodes=reinforcedEpisodes_;
    s.learnedSpeechPrimitives=static_cast<uint32_t>(speechPrimitives_.size());
    s.learnedSpeechTransitions=static_cast<uint32_t>(speechTransitions_.size());
    s.learnedSpeechUnits=static_cast<uint32_t>(speechEngrams_.size()+speechPrimitives_.size()+speechTransitions_.size()+bioSpeech_.primitiveCount()+bioSpeech_.transitionCount());
    for(const auto& [_,e]:speechEngrams_) s.speechMemoryBytes += e.compandedPcm.size();
    for(const auto& [_,e]:speechPrimitives_) s.speechMemoryBytes += e.frames.size()*sizeof(SpeechAcousticFrame);
    for(const auto& [_,e]:speechTransitions_) s.speechMemoryBytes += e.frames.size()*sizeof(SpeechAcousticFrame);
    s.speechRenderCount=speechRenderCount_; s.generatedSpeechCount=generatedSpeechCount_;
    s.learnedBioSpeechPrimitives=bioSpeech_.primitiveCount();
    s.learnedBioSpeechTransitions=bioSpeech_.transitionCount();
    s.bioSpeechMemoryBytes=bioSpeech_.memoryBytes();
    s.bioSpeechRenderCount=bioSpeechRenderCount_;
    const auto bd=bioSpeech_.diagnostics();
    s.bioSpeechAuditoryErrorBefore=bd.auditoryErrorBefore;
    s.bioSpeechAuditoryErrorAfter=bd.auditoryErrorAfter;
    s.bioSpeechSomatosensoryError=bd.somatosensoryError;
    s.bioSpeechCompensation=bd.compensationMagnitude;
    s.bioSpeechLesionMask=bd.lesionMask;
    s.corticalApicalEvents=corticalApicalEvents_;
    s.corticalDendriticCoincidences=corticalDendriticCoincidences_;
    s.corticalStructuredEdges=corticalStructuredEdges_;
    s.corticalLayerSpikes=corticalLayerSpikes_;
    s.corticalCellSpikes=corticalCellSpikes_;
    s.memoryBytes=memoryBytesUnsafe(); s.mode=mode_; return s;
}

std::string BrainEngine::statsJson() const {
    const auto s=stats(); std::ostringstream o; o<<std::fixed<<std::setprecision(3);
    o<<"{\"neurons\":"<<s.neurons<<",\"logicalSynapses\":"<<s.logicalSynapses
     <<",\"tick\":"<<s.tick<<",\"spikesTotal\":"<<s.spikesTotal
     <<",\"edgeEventsTotal\":"<<s.edgeEventsTotal<<",\"spikesLastStep\":"<<s.spikesLastStep
     <<",\"queuedEvents\":"<<s.queuedEvents<<",\"lastStepMs\":"<<s.lastStepMs
     <<",\"spikesPerSecond\":"<<s.spikesPerSecond<<",\"edgesPerSecond\":"<<s.edgesPerSecond
     <<",\"stepHz\":"<<s.stepHz<<",\"regionSpikesPerSecond\":[";
    for (size_t i=0;i<s.regionSpikesPerSecond.size();++i) { if(i) o<<','; o<<s.regionSpikesPerSecond[i]; }
    o<<"]"
     <<",\"cameraFramesPerSecond\":"<<s.cameraFramesPerSecond
     <<",\"visionFramesPerSecond\":"<<s.visionFramesPerSecond
     <<",\"visionFeaturesPerSecond\":"<<s.visionFeaturesPerSecond
     <<",\"visionInjectionsPerSecond\":"<<s.visionInjectionsPerSecond
     <<",\"audioChunksPerSecond\":"<<s.audioChunksPerSecond
     <<",\"audioBandsPerSecond\":"<<s.audioBandsPerSecond
     <<",\"audioInjectionsPerSecond\":"<<s.audioInjectionsPerSecond
     <<",\"touchEventsPerSecond\":"<<s.touchEventsPerSecond
     <<",\"touchInjectionsPerSecond\":"<<s.touchInjectionsPerSecond
     <<",\"imuEventsPerSecond\":"<<s.imuEventsPerSecond
     <<",\"imuChangesPerSecond\":"<<s.imuChangesPerSecond
     <<",\"imuInjectionsPerSecond\":"<<s.imuInjectionsPerSecond
     <<",\"environmentEventsPerSecond\":"<<s.environmentEventsPerSecond
     <<",\"environmentChangesPerSecond\":"<<s.environmentChangesPerSecond
     <<",\"environmentInjectionsPerSecond\":"<<s.environmentInjectionsPerSecond
     <<",\"locationEventsPerSecond\":"<<s.locationEventsPerSecond
     <<",\"locationInjectionsPerSecond\":"<<s.locationInjectionsPerSecond
     <<",\"externalTokensPerSecond\":"<<s.externalTokensPerSecond
     <<",\"externalInjectionsPerSecond\":"<<s.externalInjectionsPerSecond
     <<",\"currentAction\":"<<s.currentAction<<",\"actionEpoch\":"<<s.actionEpoch
     <<",\"motorMargin\":"<<s.motorMargin<<",\"motorDifferential\":"<<s.motorDifferential<<",\"reinforcedEpisodes\":"<<s.reinforcedEpisodes
     <<",\"learnedSpeechUnits\":"<<s.learnedSpeechUnits<<",\"learnedSpeechPrimitives\":"<<s.learnedSpeechPrimitives<<",\"learnedSpeechTransitions\":"<<s.learnedSpeechTransitions
     <<",\"speechMemoryBytes\":"<<s.speechMemoryBytes<<",\"speechRenderCount\":"<<s.speechRenderCount<<",\"generatedSpeechCount\":"<<s.generatedSpeechCount
     <<",\"learnedBioSpeechPrimitives\":"<<s.learnedBioSpeechPrimitives<<",\"learnedBioSpeechTransitions\":"<<s.learnedBioSpeechTransitions
     <<",\"bioSpeechMemoryBytes\":"<<s.bioSpeechMemoryBytes<<",\"bioSpeechRenderCount\":"<<s.bioSpeechRenderCount
     <<",\"bioSpeechAuditoryErrorBefore\":"<<s.bioSpeechAuditoryErrorBefore<<",\"bioSpeechAuditoryErrorAfter\":"<<s.bioSpeechAuditoryErrorAfter
     <<",\"bioSpeechSomatosensoryError\":"<<s.bioSpeechSomatosensoryError<<",\"bioSpeechCompensation\":"<<s.bioSpeechCompensation<<",\"bioSpeechLesionMask\":"<<s.bioSpeechLesionMask
     <<",\"corticalApicalEvents\":"<<s.corticalApicalEvents<<",\"corticalDendriticCoincidences\":"<<s.corticalDendriticCoincidences
     <<",\"corticalStructuredEdges\":"<<s.corticalStructuredEdges<<",\"corticalLayerSpikes\":[";
    for(size_t i=0;i<s.corticalLayerSpikes.size();++i){if(i)o<<',';o<<s.corticalLayerSpikes[i];}
    o<<"],\"corticalCellSpikes\":[";
    for(size_t i=0;i<s.corticalCellSpikes.size();++i){if(i)o<<',';o<<s.corticalCellSpikes[i];}
    o<<"],\"memoryBytes\":"<<s.memoryBytes<<",\"mode\":"<<int(s.mode)<<"}";
    return o.str();
}

std::vector<uint8_t> BrainEngine::serializePlasticity() const {
    std::lock_guard lock(mutex_); std::vector<uint8_t> out;
    size_t speechBytes=0;
    for(const auto& [_,e]:speechEngrams_) speechBytes += 16 + e.compandedPcm.size();
    for(const auto& [_,e]:speechPrimitives_) speechBytes += 18 + e.frames.size()*(3+kSpeechLpcOrder)*sizeof(float);
    for(const auto& [_,e]:speechTransitions_) speechBytes += 18 + e.frames.size()*(3+kSpeechLpcOrder)*sizeof(float);
    const auto bioBlob=bioSpeech_.serialize();
    out.reserve(60 + motorDifferential_.size()*sizeof(float) + speechBytes + bioBlob.size());
    appendBytes(out,kSerializationMagic); appendBytes(out,kSerializationVersion);
    appendBytes(out,cfg_.neurons); appendBytes(out,cfg_.fanout); appendBytes(out,cfg_.seed);
    const uint32_t n=static_cast<uint32_t>(motorDifferential_.size()); appendBytes(out,n);
    const auto* p=reinterpret_cast<const uint8_t*>(motorDifferential_.data()); out.insert(out.end(),p,p+n*sizeof(float));

    std::vector<uint64_t> keys; keys.reserve(speechEngrams_.size());
    for(const auto& [key,_]:speechEngrams_) keys.push_back(key);
    std::sort(keys.begin(),keys.end());
    const uint32_t legacyCount=static_cast<uint32_t>(keys.size()); appendBytes(out,legacyCount);
    for(uint64_t key:keys) {
        const auto& e=speechEngrams_.at(key);
        appendBytes(out,key); appendBytes(out,e.sampleRate);
        const uint32_t m=static_cast<uint32_t>(e.compandedPcm.size()); appendBytes(out,m);
        const auto* q=reinterpret_cast<const uint8_t*>(e.compandedPcm.data()); out.insert(out.end(),q,q+m);
    }

    auto appendPrimitiveTable=[&](const auto& table){
        std::vector<uint64_t> ks; ks.reserve(table.size());
        for(const auto& [key,_]:table) ks.push_back(key);
        std::sort(ks.begin(),ks.end());
        const uint32_t count=static_cast<uint32_t>(ks.size()); appendBytes(out,count);
        for(uint64_t key:ks) {
            const auto& e=table.at(key);
            appendBytes(out,key); appendBytes(out,e.sampleRate); appendBytes(out,e.observations);
            const uint32_t m=static_cast<uint32_t>(e.frames.size()); appendBytes(out,m);
            for(const auto& f:e.frames) {
                appendBytes(out,f.f0Hz); appendBytes(out,f.rms); appendBytes(out,f.voiced);
                for(float a:f.lpc) appendBytes(out,a);
            }
        }
    };
    appendPrimitiveTable(speechPrimitives_);
    appendPrimitiveTable(speechTransitions_);
    const uint32_t bioSize=static_cast<uint32_t>(bioBlob.size()); appendBytes(out,bioSize);
    out.insert(out.end(),bioBlob.begin(),bioBlob.end());
    return out;
}

bool BrainEngine::restorePlasticity(std::span<const uint8_t> blob) {
    std::lock_guard lock(mutex_); size_t off=0; uint32_t magic=0,ver=0,n=0,fan=0; uint64_t neurons=0,seed=0;
    if(!readBytes(blob,off,magic)||!readBytes(blob,off,ver)||magic!=kSerializationMagic||
       (ver!=kSerializationVersion && ver!=kGenerativeSpeechSerializationVersion && ver!=kLegacySpeechSerializationVersion && ver!=kPreviousSerializationVersion)) return false;
    if(!readBytes(blob,off,neurons)||!readBytes(blob,off,fan)||!readBytes(blob,off,seed)||!readBytes(blob,off,n)) return false;
    if(neurons!=cfg_.neurons||fan!=cfg_.fanout||seed!=cfg_.seed||n!=motorDifferential_.size()) return false;
    if(off+n*sizeof(float)>blob.size()) return false;
    std::memcpy(motorDifferential_.data(),blob.data()+off,n*sizeof(float)); off += n*sizeof(float);
    speechEngrams_.clear(); speechPrimitives_.clear(); speechTransitions_.clear(); bioSpeech_.clear();
    speechRenderCount_=0; generatedSpeechCount_=0; bioSpeechRenderCount_=0;
    if(ver==kPreviousSerializationVersion) return off==blob.size();

    uint32_t legacyCount=0; if(!readBytes(blob,off,legacyCount) || legacyCount>kMaxSpeechUnits) return false;
    for(uint32_t i=0;i<legacyCount;++i) {
        uint64_t key=0; uint32_t rate=0,m=0;
        if(!readBytes(blob,off,key)||!readBytes(blob,off,rate)||!readBytes(blob,off,m)) return false;
        if(rate<8000||rate>48000||m<160||m>kMaxSpeechSamples||off+m>blob.size()) return false;
        SpeechEngram e; e.sampleRate=rate; e.compandedPcm.resize(m);
        std::memcpy(e.compandedPcm.data(),blob.data()+off,m); off += m;
        speechEngrams_[key]=std::move(e);
    }
    if(ver==kLegacySpeechSerializationVersion) return off==blob.size();

    auto readPrimitiveTable=[&](auto& table,uint32_t maxCount)->bool {
        uint32_t count=0; if(!readBytes(blob,off,count)||count>maxCount) return false;
        for(uint32_t i=0;i<count;++i) {
            uint64_t key=0; uint32_t rate=0,m=0; uint16_t obs=0;
            if(!readBytes(blob,off,key)||!readBytes(blob,off,rate)||!readBytes(blob,off,obs)||!readBytes(blob,off,m)) return false;
            if(rate!=kNeuralSpeechRate||obs<1||obs>16||m<1||m>kMaxPrimitiveFrames) return false;
            SpeechPrimitive e; e.sampleRate=rate; e.observations=obs; e.frames.resize(m);
            for(auto& f:e.frames) {
                if(!readBytes(blob,off,f.f0Hz)||!readBytes(blob,off,f.rms)||!readBytes(blob,off,f.voiced)) return false;
                if(!std::isfinite(f.f0Hz)||!std::isfinite(f.rms)||!std::isfinite(f.voiced)) return false;
                for(float& a:f.lpc) { if(!readBytes(blob,off,a)||!std::isfinite(a)) return false; }
            }
            table[key]=std::move(e);
        }
        return true;
    };
    if(!readPrimitiveTable(speechPrimitives_,kMaxSpeechPrimitives)) return false;
    if(!readPrimitiveTable(speechTransitions_,kMaxSpeechTransitions)) return false;
    if(ver==kGenerativeSpeechSerializationVersion) return off==blob.size();
    uint32_t bioSize=0; if(!readBytes(blob,off,bioSize) || bioSize>64u*1024u*1024u || off+bioSize>blob.size()) return false;
    if(!bioSpeech_.restore(blob.subspan(off,bioSize))) return false;
    off += bioSize;
    return off==blob.size();
}

double BrainEngine::benchmarkEdgeHash(uint64_t edges, uint64_t seed) {
    edges = std::max<uint64_t>(edges, 100000);
    volatile uint64_t sink=0; const auto t0=std::chrono::steady_clock::now();
    for(uint64_t i=0;i<edges;++i) sink ^= mix64(seed ^ i*0xD6E8FEB86659FD93ull);
    const auto t1=std::chrono::steady_clock::now(); (void)sink;
    const double sec=std::chrono::duration<double>(t1-t0).count(); return edges/std::max(sec,1e-9);
}

ScaleRecommendation BrainEngine::recommendScale(uint64_t memoryBudgetBytes, double measuredEdgesPerSecond,
                                                double targetHz, double assumedActiveFraction) {
    ScaleRecommendation r; r.memoryBudgetBytes=memoryBudgetBytes; r.measuredEdgeHashPerSecond=measuredEdgesPerSecond;
    constexpr double bytesPerNeuron=26.0; // v1.0: soma + apical dendrite + adaptation + dense state; event queues excluded
    const uint64_t nMem=std::min<uint64_t>(kMaxNeurons, uint64_t(memoryBudgetBytes/bytesPerNeuron));
    auto nFor=[&](uint32_t k,double safety){
        const double denom=std::max(1.0,double(k)*assumedActiveFraction*targetHz);
        return std::min<uint64_t>(nMem,std::max<uint64_t>(1024,uint64_t(measuredEdgesPerSecond*safety/denom)));
    };
    // Sustained live-sensor validation shows K>256 can enter a recurrent event avalanche
    // on the mobile runtime. Scale neuron count, not fanout, until recurrent normalization
    // is explicitly revalidated at larger K.
    r.balancedFanout=256; r.balancedNeurons=nFor(r.balancedFanout,0.40);
    r.maxFanout=256; r.maxNeurons=nFor(r.maxFanout,0.65);
    r.logicalConnectionsBalanced=r.balancedNeurons*uint64_t(r.balancedFanout);
    r.logicalConnectionsMax=r.maxNeurons*uint64_t(r.maxFanout); return r;
}

std::string recommendationJson(const ScaleRecommendation& r) {
    std::ostringstream o; o<<std::fixed<<std::setprecision(1)
      <<"{\"balancedNeurons\":"<<r.balancedNeurons<<",\"balancedFanout\":"<<r.balancedFanout
      <<",\"maxNeurons\":"<<r.maxNeurons<<",\"maxFanout\":"<<r.maxFanout
      <<",\"logicalConnectionsBalanced\":"<<r.logicalConnectionsBalanced
      <<",\"logicalConnectionsMax\":"<<r.logicalConnectionsMax
      <<",\"edgeHashPerSecond\":"<<r.measuredEdgeHashPerSecond
      <<",\"memoryBudgetBytes\":"<<r.memoryBudgetBytes<<"}"; return o.str();
}

} // namespace wb
