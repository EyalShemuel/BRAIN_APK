#pragma once
#include <array>
#include <cstdint>
#include <span>
#include <string>
#include <unordered_map>
#include <vector>

namespace wb {

// Biologically constrained speech subsystem. It is intentionally a model, not a claim
// of a complete human cortical reconstruction. Motor commands describe an articulatory
// plant; audio is produced from those commands and closed-loop auditory/somatosensory
// error correction rather than from stored waveforms or TTS.
class BioSpeechModel {
public:
    enum Lesion : uint32_t {
        LesionNone = 0,
        LesionAuditory = 1u << 0,
        LesionSomatosensory = 1u << 1,
        LesionCerebellum = 1u << 2,
        LesionBasalGanglia = 1u << 3,
        LesionPlanner = 1u << 4,
        LesionVocalMotor = 1u << 5,
    };

    struct Perturbation {
        float auditoryF1ShiftHz = 0.0f;
        float auditoryF2ShiftHz = 0.0f;
        float jawOffset = 0.0f;
    };

    struct Diagnostics {
        double auditoryErrorBefore = 0.0;
        double auditoryErrorAfter = 0.0;
        double somatosensoryError = 0.0;
        double compensationMagnitude = 0.0;
        uint32_t renderedFrames = 0;
        uint32_t lesionMask = 0;
    };

    bool learn(std::span<const uint8_t> plan, std::span<const int16_t> pcm, int sampleRate);
    std::vector<int16_t> render(std::span<const uint8_t> plan);
    bool hasPrimitive(std::span<const uint8_t> unit) const;
    uint32_t primitiveCount() const { return static_cast<uint32_t>(primitives_.size()); }
    uint32_t transitionCount() const { return static_cast<uint32_t>(transitions_.size()); }
    uint64_t memoryBytes() const;
    void clear();

    void setPerturbation(const Perturbation& p) { perturbation_ = p; }
    Perturbation perturbation() const { return perturbation_; }
    void setLesionMask(uint32_t mask) { lesionMask_ = mask; }
    uint32_t lesionMask() const { return lesionMask_; }
    Diagnostics diagnostics() const { return diagnostics_; }

    std::vector<uint8_t> serialize() const;
    bool restore(std::span<const uint8_t> blob);

private:
    static constexpr int kRate = 16000;
    static constexpr int kHop = 160;      // 10 ms control frame
    static constexpr int kWindow = 320;   // 20 ms auditory analysis
    static constexpr int kLpcOrder = 10;
    static constexpr size_t kMaxFrames = 120;
    static constexpr size_t kMaxGeneratedSamples = kRate * 15;

    struct AuditoryTarget {
        float f0 = 0.0f;
        float rms = 0.0f;
        float voiced = 0.0f;
        float f1 = 500.0f;
        float f2 = 1500.0f;
        float f3 = 2500.0f;
        float nasal = 0.0f;
    };

    struct MotorCommand {
        // normalized articulators. Tongue coordinates/tip are [-1,1], others [0,1].
        float tongueX = 0.0f;
        float tongueY = 0.0f;
        float tongueTip = 0.0f;
        float jaw = 0.35f;
        float lipAperture = 0.45f;
        float lipRound = 0.20f;
        float velum = 0.05f;
        float glottalTension = 0.45f;
        float adduction = 0.75f;
        float pressure = 0.45f;
    };

    struct MotorFrame {
        AuditoryTarget target;
        MotorCommand command;
    };

    struct Primitive {
        uint16_t observations = 1;
        std::vector<MotorFrame> frames;
    };

    struct PlantState {
        AuditoryTarget acoustic;
        MotorCommand actual;
    };

    struct Resonator {
        double y1 = 0.0;
        double y2 = 0.0;
    };

    static std::vector<std::string> planTokens(std::span<const uint8_t> plan);
    static std::vector<int16_t> canonicalPcm(std::span<const int16_t> pcm, int sampleRate);
    static std::vector<AuditoryTarget> analyze(std::span<const int16_t> pcm);
    static MotorCommand inverseArticulation(const AuditoryTarget& target);
    static PlantState plant(const MotorCommand& command);
    static MotorCommand clampMotor(MotorCommand c);
    static MotorCommand adapt(const MotorCommand& planned, const AuditoryTarget& desired,
                              const Perturbation& perturbation, uint32_t lesionMask,
                              double* auditoryBefore, double* auditoryAfter,
                              double* somatoError, double* compensation);
    static double auditoryError(const AuditoryTarget& a, const AuditoryTarget& b);
    static uint64_t hashUnit(std::span<const uint8_t> unit);
    static uint64_t transitionKey(uint64_t a, uint64_t b);
    static uint64_t mix64(uint64_t x);
    static void averagePrimitive(Primitive& dst, const Primitive& src);
    static Primitive makePrimitive(std::span<const int16_t> segment);
    static Primitive makeTransition(const Primitive& a, const Primitive& b);
    static void appendCrossfade(std::vector<int16_t>& out, std::span<const int16_t> piece, size_t fade);
    static void appendSilence(std::vector<int16_t>& out, size_t n);
    static std::vector<int16_t> synthesizeFrames(std::span<const MotorFrame> frames,
                                                 const Perturbation& perturbation,
                                                 uint32_t lesionMask,
                                                 bool question,
                                                 size_t unitIndex,
                                                 size_t unitCount,
                                                 Diagnostics* diag);
    static double resonatorStep(double x, double frequency, double bandwidth, Resonator& s);

    std::unordered_map<uint64_t, Primitive> primitives_;
    std::unordered_map<uint64_t, Primitive> transitions_;
    Perturbation perturbation_{};
    uint32_t lesionMask_ = 0;
    Diagnostics diagnostics_{};
};

} // namespace wb
