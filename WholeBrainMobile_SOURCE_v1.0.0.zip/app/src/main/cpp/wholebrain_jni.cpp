#include <jni.h>
#include <algorithm>
#include <android/log.h>
#include <memory>
#include <string>
#include <vector>
#include "wholebrain_engine.h"

#define LOG_TAG "WholeBrainNative"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
wb::BrainEngine* engine(jlong h) { return reinterpret_cast<wb::BrainEngine*>(h); }
jstring jstr(JNIEnv* env, const std::string& s) { return env->NewStringUTF(s.c_str()); }
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeCreate(
    JNIEnv* env, jobject, jlong neurons, jint fanout, jlong seed) {
    try {
        wb::EngineConfig c; c.neurons=static_cast<uint64_t>(neurons); c.fanout=static_cast<uint32_t>(fanout); c.seed=static_cast<uint64_t>(seed);
        return reinterpret_cast<jlong>(new wb::BrainEngine(c));
    } catch (const std::exception& e) {
        LOGE("create failed: %s", e.what());
        jclass cls=env->FindClass("java/lang/RuntimeException"); env->ThrowNew(cls,e.what()); return 0;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeDestroy(JNIEnv*, jobject, jlong h) {
    delete engine(h);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeStep(JNIEnv*, jobject, jlong h) { if(auto* e=engine(h)) e->step(); }
extern "C" JNIEXPORT jstring JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeStats(JNIEnv* env, jobject, jlong h) {
    return jstr(env, engine(h)?engine(h)->statsJson():"{}");
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSetMode(JNIEnv*, jobject, jlong h, jint mode) {
    if(auto* e=engine(h)) e->setMode(static_cast<wb::RunMode>(std::clamp(mode,0,3)));
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeReward(JNIEnv*, jobject, jlong h, jboolean positive) {
    if(auto* e=engine(h)) e->reward(positive==JNI_TRUE);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSensor(JNIEnv*, jobject, jlong h, jint type, jfloat x,jfloat y,jfloat z) {
    if(auto* e=engine(h)) e->injectSensor(type,x,y,z);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeTouch(JNIEnv*, jobject, jlong h, jfloat x,jfloat y,jfloat p) {
    if(auto* e=engine(h)) e->injectTouch(x,y,p);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLocation(JNIEnv*, jobject, jlong h, jdouble lat,jdouble lon,jfloat speed,jfloat bearing) {
    if(auto* e=engine(h)) e->injectLocation(lat,lon,speed,bearing);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeNoteCameraFrame(JNIEnv*, jobject, jlong h) {
    if(auto* e=engine(h)) e->noteCameraFrame();
}

extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeVision(JNIEnv* env, jobject, jlong h, jbyteArray data, jint w,jint hh) {
    if(!engine(h)||!data) return;
    const jsize n=env->GetArrayLength(data); std::vector<uint8_t> v(n);
    env->GetByteArrayRegion(data,0,n,reinterpret_cast<jbyte*>(v.data())); engine(h)->injectVision(v,w,hh);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeAudio(JNIEnv* env, jobject, jlong h, jshortArray data, jint sr) {
    if(!engine(h)||!data) return;
    const jsize n=env->GetArrayLength(data); std::vector<int16_t> v(n);
    env->GetShortArrayRegion(data,0,n,reinterpret_cast<jshort*>(v.data())); engine(h)->injectAudio(v,sr);
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeToken(JNIEnv* env, jobject, jlong h, jint channel, jbyteArray data) {
    if(!engine(h)||!data) return;
    const jsize n=env->GetArrayLength(data); std::vector<uint8_t> v(n);
    env->GetByteArrayRegion(data,0,n,reinterpret_cast<jbyte*>(v.data())); engine(h)->injectToken(static_cast<uint32_t>(channel),v);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLearnSpeech(JNIEnv* env, jobject, jlong h, jbyteArray token, jshortArray data, jint sr) {
    if(!engine(h)||!token||!data) return JNI_FALSE;
    const jsize tn=env->GetArrayLength(token); std::vector<uint8_t> t(tn);
    env->GetByteArrayRegion(token,0,tn,reinterpret_cast<jbyte*>(t.data()));
    const jsize n=env->GetArrayLength(data); std::vector<int16_t> v(n);
    env->GetShortArrayRegion(data,0,n,reinterpret_cast<jshort*>(v.data()));
    return engine(h)->learnSpeech(t,v,sr)?JNI_TRUE:JNI_FALSE;
}

extern "C" JNIEXPORT jshortArray JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeRenderSpeech(JNIEnv* env, jobject, jlong h, jbyteArray token) {
    if(!engine(h)||!token) return env->NewShortArray(0);
    const jsize tn=env->GetArrayLength(token); std::vector<uint8_t> t(tn);
    env->GetByteArrayRegion(token,0,tn,reinterpret_cast<jbyte*>(t.data()));
    const auto pcm=engine(h)->renderSpeech(t);
    jshortArray out=env->NewShortArray(static_cast<jsize>(pcm.size()));
    if(out && !pcm.empty()) env->SetShortArrayRegion(out,0,static_cast<jsize>(pcm.size()),reinterpret_cast<const jshort*>(pcm.data()));
    return out;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLearnGenerativeSpeech(JNIEnv* env, jobject, jlong h, jbyteArray plan, jshortArray data, jint sr) {
    if(!engine(h)||!plan||!data) return JNI_FALSE;
    const jsize pn=env->GetArrayLength(plan); std::vector<uint8_t> p(pn);
    env->GetByteArrayRegion(plan,0,pn,reinterpret_cast<jbyte*>(p.data()));
    const jsize n=env->GetArrayLength(data); std::vector<int16_t> v(n);
    env->GetShortArrayRegion(data,0,n,reinterpret_cast<jshort*>(v.data()));
    return engine(h)->learnGenerativeSpeech(p,v,sr)?JNI_TRUE:JNI_FALSE;
}

extern "C" JNIEXPORT jshortArray JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeRenderGenerativeSpeech(JNIEnv* env, jobject, jlong h, jbyteArray plan) {
    if(!engine(h)||!plan) return env->NewShortArray(0);
    const jsize pn=env->GetArrayLength(plan); std::vector<uint8_t> p(pn);
    env->GetByteArrayRegion(plan,0,pn,reinterpret_cast<jbyte*>(p.data()));
    const auto pcm=engine(h)->renderGenerativeSpeech(p);
    jshortArray out=env->NewShortArray(static_cast<jsize>(pcm.size()));
    if(out && !pcm.empty()) env->SetShortArrayRegion(out,0,static_cast<jsize>(pcm.size()),reinterpret_cast<const jshort*>(pcm.data()));
    return out;
}


extern "C" JNIEXPORT jboolean JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLearnBioSpeech(JNIEnv* env, jobject, jlong h, jbyteArray plan, jshortArray data, jint sr) {
    if(!engine(h)||!plan||!data) return JNI_FALSE;
    const jsize pn=env->GetArrayLength(plan); std::vector<uint8_t> p(pn);
    env->GetByteArrayRegion(plan,0,pn,reinterpret_cast<jbyte*>(p.data()));
    const jsize n=env->GetArrayLength(data); std::vector<int16_t> v(n);
    env->GetShortArrayRegion(data,0,n,reinterpret_cast<jshort*>(v.data()));
    return engine(h)->learnBioSpeech(p,v,sr)?JNI_TRUE:JNI_FALSE;
}

extern "C" JNIEXPORT jshortArray JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeRenderBioSpeech(JNIEnv* env, jobject, jlong h, jbyteArray plan) {
    if(!engine(h)||!plan) return env->NewShortArray(0);
    const jsize pn=env->GetArrayLength(plan); std::vector<uint8_t> p(pn);
    env->GetByteArrayRegion(plan,0,pn,reinterpret_cast<jbyte*>(p.data()));
    const auto pcm=engine(h)->renderBioSpeech(p);
    jshortArray out=env->NewShortArray(static_cast<jsize>(pcm.size()));
    if(out && !pcm.empty()) env->SetShortArrayRegion(out,0,static_cast<jsize>(pcm.size()),reinterpret_cast<const jshort*>(pcm.data()));
    return out;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeHasBioSpeechPrimitive(JNIEnv* env, jobject, jlong h, jbyteArray unit) {
    if(!engine(h)||!unit) return JNI_FALSE;
    const jsize n=env->GetArrayLength(unit); std::vector<uint8_t> u(n);
    env->GetByteArrayRegion(unit,0,n,reinterpret_cast<jbyte*>(u.data()));
    return engine(h)->hasBioSpeechPrimitive(u)?JNI_TRUE:JNI_FALSE;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLearnedBioSpeechPrimitives(JNIEnv*, jobject, jlong h) {
    return engine(h)?static_cast<jint>(engine(h)->learnedBioSpeechPrimitives()):0;
}

extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSetBioSpeechPerturbation(JNIEnv*, jobject, jlong h, jfloat f1, jfloat f2, jfloat jaw) {
    if(auto* e=engine(h)) e->setBioSpeechPerturbation(f1,f2,jaw);
}

extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSetBioSpeechLesionMask(JNIEnv*, jobject, jlong h, jint mask) {
    if(auto* e=engine(h)) e->setBioSpeechLesionMask(static_cast<uint32_t>(std::max(0,mask)));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeHasSpeechPrimitive(JNIEnv* env, jobject, jlong h, jbyteArray unit) {
    if(!engine(h)||!unit) return JNI_FALSE;
    const jsize n=env->GetArrayLength(unit); std::vector<uint8_t> u(n);
    env->GetByteArrayRegion(unit,0,n,reinterpret_cast<jbyte*>(u.data()));
    return engine(h)->hasSpeechPrimitive(u)?JNI_TRUE:JNI_FALSE;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLearnedSpeechPrimitives(JNIEnv*, jobject, jlong h) {
    return engine(h)?static_cast<jint>(engine(h)->learnedSpeechPrimitives()):0;
}

extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeClearSpeech(JNIEnv*, jobject, jlong h) {
    if(auto* e=engine(h)) e->clearSpeech();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeLearnedSpeechUnits(JNIEnv*, jobject, jlong h) {
    return engine(h)?static_cast<jint>(engine(h)->learnedSpeechUnits()):0;
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSave(JNIEnv* env, jobject, jlong h) {
    if(!engine(h)) return env->NewByteArray(0);
    const auto blob=engine(h)->serializePlasticity();
    jbyteArray out=env->NewByteArray(static_cast<jsize>(blob.size()));
    env->SetByteArrayRegion(out,0,static_cast<jsize>(blob.size()),reinterpret_cast<const jbyte*>(blob.data())); return out;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeRestore(JNIEnv* env, jobject, jlong h, jbyteArray data) {
    if(!engine(h)||!data) return JNI_FALSE;
    const jsize n=env->GetArrayLength(data); std::vector<uint8_t> v(n);
    env->GetByteArrayRegion(data,0,n,reinterpret_cast<jbyte*>(v.data())); return engine(h)->restorePlasticity(v)?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeResetDiagnostics(JNIEnv*, jobject, jlong h) {
    if(auto* e=engine(h)) e->resetDiagnostics();
}


extern "C" JNIEXPORT void JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeSetTraceEnabled(JNIEnv*, jobject, jlong h, jboolean enabled) {
    if(auto* e=engine(h)) e->setTraceEnabled(enabled==JNI_TRUE);
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeTraceFrame(JNIEnv* env, jobject, jlong h, jint back) {
    if(!engine(h)) return env->NewIntArray(0);
    const auto data=engine(h)->traceFrame(static_cast<size_t>(std::max(0,back)));
    jintArray out=env->NewIntArray(static_cast<jsize>(data.size()));
    if(!out || data.empty()) return out;
    env->SetIntArrayRegion(out,0,static_cast<jsize>(data.size()),reinterpret_cast<const jint*>(data.data()));
    return out;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_eyalshemuel_wholebrainmobile_brain_NativeBrain_nativeCalibrate(JNIEnv* env, jobject, jlong memoryBudgetBytes) {
    const double rate=wb::BrainEngine::benchmarkEdgeHash(3000000,0xC0FFEE);
    const auto r=wb::BrainEngine::recommendScale(static_cast<uint64_t>(memoryBudgetBytes),rate); return jstr(env,wb::recommendationJson(r));
}
