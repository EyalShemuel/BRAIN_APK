# WholeBrain Mobile v1.0.0 — Human Cortex Scaffold

## סטטוס

גרסה זו מוסיפה substrate קורטיקלי כללי מעל v0.9 BioSpeech. היא **אינה שחזור ביולוגי מלא של קורטקס אנושי**; היא milestone מוגבל-ביולוגית עם gates שניתנים להפרכה.

## מה נוסף

### 1. שכבות קורטיקליות
- L1
- L2/3
- L4
- L5
- L6

הפרופורציות תלויות בסוג האזור:
- sensory granular — L4 מפותח
- association — L2/3 מורחב ו-L4 בינוני
- agranular motor — L4 מצומצם

### 2. מחלקות תאים
- IT — intratelencephalic pyramidal
- ET — extratelencephalic / L5 output
- CT — corticothalamic / L6
- PV
- SST
- VIP
- LAMP5

הזהות דטרמיניסטית לפי neuron id, אזור, שכבה ו-seed — בלי טבלת phenotype צפופה נוספת.

### 3. דנדריט אפיקלי נפרד
לכל נוירון יש כעת state נפרד ל-soma, apical dendrite ו-adaptation. תאי פירמידה יכולים לבצע nonlinear basal+apical coincidence. SST/LAMP5 יכולים לעכב את המסלול האפיקלי.

### 4. microcircuit structured connectivity
חלק מהקשרים המקומיים כבר אינו random fanout בלבד:
- L4 excitatory -> L2/3
- L2/3 IT -> L5
- L5 ET -> L6/CT
- PV -> perisomatic targets
- SST -> apical targets
- VIP -> preference ל-SST (disinhibitory motif)
- LAMP5 -> superficial/apical inhibition

### 5. feedforward / feedback laminar routing
בקשרים ארוכי טווח בין אזורים קורטיקליים:
- feedforward bias -> L4 / soma
- feedback bias -> superficial/apical compartment
- thalamic output לקורטקס מוטה ל-L4/L6

### 6. sensory thalamorecipient routing
Visual ו-Somatosensory topography מוזרמים ל-L4. Audio tonotopy מוזרם ל-L4. בסקייל קטן בלבד קיימת diverging copy חלשה ל-L6 כדי למנוע dilution; ב-250K היא כבויה כדי לשמור על יציבות recurrent queue.

### 7. delays
- local cortical delays: 1–3 ticks
- long-range delays: גדלים עם hierarchy distance עד recurrentDelayMax

זה עדיין abstraction של conduction ולא tractography פיזיקלית מלאה.

## Gates

תוצאת full host suite על v1.0:

```text
PASS topology/sensory
PASS K256 live stability (peak queue ~82k < 500k)
PASS learning seed 77
PASS learning seed 78
PASS learning seed 79
PASS neural speech compatibility
PASS generative speech compatibility
PASS BioSpeech
PASS cortical_microcircuit
PASS BioSpeech curriculum 28/28 core units
```

Cortical microcircuit gate:

```text
exc_fraction ≈ 0.764
sensory L4 = 20000 / 100000
motor L4 = 4000 / 100000
dendritic nonlinear gain ≈ 0.665
local delay = 1 tick
long-range delay = 4 ticks (test case)
```

## מה עדיין חסר לפני שאפשר אפילו להתקרב ל"שחזור מלא"

1. receptor kinetics נפרדים: AMPA/NMDA/GABA-A/GABA-B.
2. dendritic tree מרובה ענפים ולא compartment אפיקלי יחיד.
3. dozens of human transcriptomic interneuron/excitatory subclasses במקום 7 מחלקות coarse.
4. astrocytes, oligodendrocytes, microglia, extracellular K+/glutamate/metabolic coupling.
5. white-matter tract geometry + myelination + conduction velocity from connectome.
6. thalamic nuclei-specific microcircuits במקום Region Thalamus אחיד.
7. cerebellar granule/Purkinje/deep nuclei microcircuit.
8. basal-ganglia direct/indirect/hyperdirect pathways מפורטים.
9. developmental wiring, pruning, critical periods ומיאלינציה.
10. gene-expression / receptor-density / morphology constraints לפי area ו-cell type אנושיים.
11. sleep oscillations, UP/DOWN states, spindle/slow-wave coupling ו-replay ביולוגי.
12. vascular/hemodynamic/energy constraints.

## מקורות מדעיים שהנחו את השלב

- Hodge et al., Nature 2019, Conserved cell types with divergent features in human versus mouse cortex. DOI: 10.1038/s41586-019-1506-7
- Gidon et al., Science 2020, Dendritic action potentials and computation in human L2/3 cortical neurons. DOI: 10.1126/science.aax6239
- Leijten et al., Nature Neuroscience 2023, Developmental trajectory of transmission speed in the human brain. DOI: 10.1038/s41593-023-01272-0
- Brain Cell Atlas, Nature Medicine 2024, atlas integrating >26M human/mouse cells. DOI: 10.1038/s41591-024-03150-z
- Human cortical spatial mapping, Communications Biology 2021, 75 transcriptomic cortical cell types in temporal cortex. DOI: 10.1038/s42003-021-02517-z

## מסקנה

v1.0 מחליף את הנחת "כל Region הוא pool LIF אחיד" ב-substrate למינרי וסוג-תא שמופעל בפועל בריצה. זהו בסיס טוב יותר להמשך, אבל הוא עדיין model reduction ולא digital biological replica של קורטקס אנושי.
