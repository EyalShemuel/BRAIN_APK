# WholeBrain Mobile v0.7.0 — Neural Speech / VocalMotor

## ממצא התחלתי

ב-v0.6.x פלט הדיבור היה מבוסס Android `TextToSpeech`. אזור `VocalMotor` היה קיים בטופולוגיית 15 האזורים, אך לא יצר את אות הקול. הטקסט הועבר ל-TTS מקומי ושכבת voice-mimic עיבדה את האודיו לאחר הסינתזה.

v0.7.0 מסיר את TTS ממסלול הדיבור הפעיל.

## המסלול החדש

לימוד מפורש של מילה/משפט:

```
טקסט -> Language + Semantic + Association
מיקרופון PCM -> Auditory
              -> VocalMotor learned engram
              -> brain plasticity state
```

Recall:

```
טקסט נלמד -> Language/Semantic recall
            -> VocalMotor activation
            -> learned PCM reconstruction
            -> Android AudioTrack בלבד
```

`AudioTrack` משמש כרמקול/actuator בלבד. אין `android.speech.tts.TextToSpeech`, אין `TTS_SERVICE`, אין `synthesizeToFile` ואין הרשאת INTERNET.

## מה המוח לומד

כל יחידת דיבור נשמרת כ-engram קולי דחוס בתוך ה-native brain state:

- PCM נלמד מהמיקרופון בלבד.
- קצב קנוני: 16 kHz mono.
- trimming של שקט + normalization מתון.
- companding ל-8 bit לצמצום זיכרון.
- עד 4 שניות לכל יחידה.
- עד 128 יחידות במצב הנוכחי.
- speech engrams נשמרים יחד עם motor plasticity.

המנוע יודע קודם לחפש engram של משפט שלם. אם אין כזה, שכבת הפלט מרכיבה משפט מיחידות מילים שכבר נלמדו. אם חסרה מילה, המערכת מחזירה שגיאה מפורשת ולא נופלת חזרה ל-TTS.

## Fast learning set

נוסף curriculum עברי של 24 יחידות בסיס:

`כן, לא, שלום, תודה, בבקשה, אני, אתה, את, אנחנו, רוצה, צריך, עזרה, טוב, רע, עוד, עצור, המשך, ימין, שמאל, למעלה, למטה, מים, אוכל, בוקר טוב`

המשתמש קורא כל prompt פעם אחת. בזמן ההקלטה:

- הטקסט מוזרם ל-Language/Semantic.
- האודיו מוזרם ל-Auditory.
- association/VocalMotor engram נוצר ונשמר.
- במצב fast-learning ההקלטה מסתיימת אוטומטית לאחר כ-650ms שקט לאחר דיבור.

הסט אינו מכיל קול סינתטי ואינו מוריד מודל או אודיו מהרשת.

## תאימות לאחור

Serialization הועלה מ-v2 ל-v3. Restore מקבל גם state v2 של v0.6.x:

- motor differential קיים נשמר.
- state ישן נטען ללא speech engrams.
- לאחר לימוד קול חדש, השמירה הבאה נכתבת בפורמט v3.

## Validation

`host-tests/neural_speech_test.cpp` בודק:

1. לימוד יחידת קול.
2. unknown token אינו מפיק קול מומצא.
3. recall מפיק PCM שנלמד ללא TTS.
4. correlation מול דוגמת המקור > 0.92.
5. recall מפעיל בפועל את אזור `VocalMotor`.
6. speech engram נשמר ונטען מחדש בדיוק.
7. state v2 ישן עדיין נטען.
8. clear מוחק רק את זיכרון הדיבור.

תוצאת הבדיקה המקומית:

```
PASS neural_speech units=1 bytes=17600 corr=0.999984 vocal_sps=1676.7
```

בנוסף נשמרו כל gates הקודמים:

- sensory topology PASS
- sustained live-load / K256 stability PASS
- learning smoke seeds 77/78/79 PASS
- no active Android TTS dependency gate PASS

## גבול הטענה המדעית

זהו **learned neural speech memory + VocalMotor actuator**, לא מודל speech generative כללי ולא cortex מלא שממציא הגייה של מילים שמעולם לא שמע. כדי לדבר מילה חדשה, המוח צריך ללמוד אותה (או ללמוד את היחידות שמהן ניתן להרכיב אותה). ההבדל הקריטי מ-v0.6 הוא שהקול עצמו כבר אינו מגיע ממנוע TTS חיצוני.
