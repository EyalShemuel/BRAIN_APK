# WholeBrain Mobile v0.8.0 — Generative Speech Cortex

## מטרת הגרסה

להחליף את מסלול v0.7 שהיה אמנם ללא Android TTS, אך עדיין שמר/שחזר הקלטות דיבור, במסלול גנרטיבי מלא ברמת המוצר: המוח לומד ייצוג מוטורי־אקוסטי תת־מילתי ומייצר waveform חדש עבור משפט שלא הוקלט מעולם.

> גבול הטענה המדעית: זהו **קורטקס דיבור גנרטיבי מלא בתוך הארכיטקטורה של האפליקציה**, לא טענה ששוחזר קורטקס הדיבור האנושי במלואו. אין כאן מודל מוח אנושי מאומת ביולוגית, ואין עדיין הוכחת מובנות/טבעיות על מכשיר פיזי עד שנריץ את ה־APK ונקליט תוצאות.

## מה השתנה

### 1. אין TTS ואין replay של משפט שלם

המסלול הפעיל `SpeechOutputEngine` אינו קורא ל־Android `TextToSpeech`, אינו משתמש ב־`synthesizeToFile`, ואינו קורא ל־API הישן `renderSpeechUnit()`.

ה־API הישן נשמר רק לצורך טעינת מצב v0.7 ותאימות לאחור. הוא לא משתתף בהפקת הדיבור הפעילה של v0.8.

### 2. Phonological planner

`GenerativeSpeechPhonology.kt` הופך טקסט לרצף סמלי תת־מילתי יציב:

- אותיות/ספרות → motor units.
- אותיות סופיות בעברית מנורמלות לצורת הבסיס כדי להעביר למידה בין מיקום אמצעי/סופי.
- גבולות מילים וסימני פיסוק הופכים לפקודות timing/prosody.
- אין מילון הגייה נסתר ואין מנוע TTS חיצוני.

עברית לא מנוקדת היא מטבעה דו־משמעית מבחינת תנועות. v0.8 לומד את מימוש התנועות והקוארטיקולציה מהדיבור של המשתמש ומהקשרי המעבר שנלמדו. לכן מילה חדשה לחלוטין יכולה להיות מובנת פחות ממילה שהקשרים שלה הופיעו בסט הלמידה.

### 3. Online teaching stream

בזמן הקראה:

1. תוכנית הטקסט מוזרמת מיד כ־teaching cue ל־Semantic/Association.
2. המיקרופון מוזרם ל־Auditory בקצב של כ־15.6 chunks/s בזמן אמת.
3. בסיום ההקלטה נעשית consolidation של אותו רצף למודל VocalMotor.

כלומר הלמידה איננה רק batch לאחר סיום ההקלטה.

### 4. אוטו־alignment לתת־יחידות

המנוע מחפש גבולות אנרגיה מקומיים סביב החלוקה הזמנית הצפויה של רצף האותיות. מכל הקלטה נלמדים:

- primitive לכל יחידה תת־מילתית.
- transition bridge בין יחידות סמוכות באותה מילה.
- דוגמאות חוזרות מתמזגות בממוצע מצטבר עד 16 תצפיות לכל primitive.

כך משפט לימוד אחד מעדכן הרבה יחידות במקום ליצור זיכרון phrase יחיד.

### 5. Acoustic cortical representation — לא PCM לשחזור

כל primitive נשמר כ־10ms acoustic frames:

- `F0` משוער.
- voiced/unvoiced strength.
- RMS / energy.
- LPC order 10 — מעטפת ספקטרלית מקומית.

ה־waveform המקורי אינו נשמר במסלול הגנרטיבי. במצב המוח נשמרים הפרמטרים האקוסטיים בלבד.

### 6. Cortical vocoder

בזמן דיבור המנוע:

`Language → Semantic/Association → PFC plan → Cerebellum timing/prosody → VocalMotor → LPC vocoder → PCM`

ה־vocoder יוצר excitation חדש בכל הפקה, משלב voicing/noise, מעביר אותו דרך מעטפת LPC, מתאים אנרגיה ומחבר את היחידות באמצעות transition bridges ו־crossfade.

`AudioTrack` נשאר רק actuator פיזי של הרמקול.

### 7. Prosody planner

- גבול מילה: pause קצר.
- פסיק: pause בינוני.
- נקודה: pause ארוך + ירידת F0/tempo קלה לקראת סוף המשפט.
- סימן שאלה: עליה הדרגתית ב־F0/tempo לקראת סוף המשפט.

זהו מסלול נפרד מתוכן הפונולוגיה, בדומה להפרדה בין תוכן פונמי לבין mode/loudness/prosody במערכות דיבור מוחיות עדכניות.

## סט למידה מהיר

נוסף `generative_speech_he_v2.txt` וכן אותו curriculum באפליקציה:

- 30 משפטים קצרים.
- כיסוי 22/22 אותיות הליבה בעברית לאחר נרמול אותיות סופיות.
- כל משפט מלמד primitives ומעברים רבים בבת אחת.
- auto-stop לאחר כ־650ms שקט לאחר הדיבור.
- אין רשת, אין קול סינתטי ואין target חיצוני.

## בדיקות שבוצעו

כל בדיקות v0.6.1/v0.7 נשמרו ועברו:

- sensory topology / sustained K256 load: PASS.
- reward learning seeds 77/78/79: 1.00 / 1.00 / 1.00.
- legacy neural-speech persistence: PASS.
- no Android TTS gate: PASS.

נוסף gate חדש `generative_speech_test`:

1. המוח מקבל רק שלושה זוגות תת־מילתיים ללמידה.
2. נדרש ממנו להפיק רצף בן שלוש יחידות שלא הופיע באף דוגמת לימוד.
3. נבדק שה־PCM אינו ריק ובעל אות ממשי.
4. אותו רצף עם `?` חייב לעבור מסלול פרוזודיה שונה.
5. נבדקת פעילות `VocalMotor` בפועל.
6. מצב המוח נשמר, נטען למנוע חדש ומייצר בדיוק מאותו מודל אקוסטי שנשמר.
7. primitive חסר נכשל סגור — אין fallback ל־TTS או phrase replay.

תוצאת host אחרונה:

`PASS generative_speech primitives=3 transitions=3 novel_samples=10896 question_samples=10096 vocal_sps=1594.32`

## תאימות מצב

Serialization עלה ל־v4:

- v2 (motor plasticity) נטען.
- v3 (v0.7 legacy phrase engrams) נטען.
- v4 שומר בנוסף acoustic primitives + transition models.

זיכרונות phrase ישנים נשמרים לצורך תאימות בלבד ואינם משמשים את generator הפעיל.

## מגבלות שעדיין דורשות בדיקת מכשיר

1. איכות/מובנות של LPC vocoder תלויה מאוד באיכות המיקרופון ובכמות דוגמאות הלמידה.
2. עברית לא מנוקדת מכילה ambiguity אמיתי; context שנלמד מפחית אותו אך אינו פותר כל מילה חדשה.
3. עדיין לא בוצע benchmark אנושי של intelligibility/MOS על ה־APK v0.8.
4. עדיין לא הושוותה איכות הקול ל־SpikeVoice או למודלי vocoder גדולים; הארכיטקטורה כאן קטנה, offline, self-trained ועל מכשיר.

## מסקנה

v0.8 משנה את ההגדרה של רכיב הדיבור: הוא כבר אינו TTS וגם אינו "נגן זיכרונות". הטקסט יוצר תוכנית קורטיקלית, הלמידה מפתחת primitive/transition models מתוך קול המשתמש, וה־VocalMotor מייצר waveform חדש דרך vocoder פנימי.
