# v0.6 source validation addendum

- versionName 0.6.0 / versionCode 9
- AuthorizedVoiceMimic requires explicit consent parameter before capture
- raw PCM enrollment cache deleted after profile extraction
- sharedpref `wholebrain-voice-mimic.xml` excluded from backup and device transfer
- VoiceMimicDsp is pure Kotlin and host-tested
- no INTERNET permission

# SOURCE VALIDATION — v0.5.0

Validated locally:
- C++20 host compilation passes.
- Exact trace invariant test passes.
- Existing sensory topology tests pass.
- Existing learning smoke passes for seeds 77, 78, 79.
- Manifest contains no INTERNET permission.
- TTS service discovery query is present.
- Speech engine explicitly filters network-required voices.
- Android build requires CI/Android SDK validation.
