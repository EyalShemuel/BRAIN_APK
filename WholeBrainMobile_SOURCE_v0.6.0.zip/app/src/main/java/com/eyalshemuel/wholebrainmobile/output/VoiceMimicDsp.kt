package com.eyalshemuel.wholebrainmobile.output

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Pure-Kotlin acoustic profiling + lightweight offline timbre matching.
 *
 * This is intentionally model-free: it does not claim a neural identity clone. It extracts
 * a reproducible acoustic profile (pitch + coarse spectral envelope + dynamics) from an
 * explicitly authorized enrollment sample and applies that profile to local Android TTS.
 * The class has no Android dependency so the DSP can be host-tested in CI.
 */
data class VoiceAcousticProfile(
    val sampleRate: Int,
    val pitchHz: Float,
    val rms: Float,
    val zcr: Float,
    val voicedFraction: Float,
    val bandLow: Float,
    val bandMid: Float,
    val bandPresence: Float,
    val bandHigh: Float,
) {
    val fingerprint: List<Float>
        get() = listOf(bandLow, bandMid, bandPresence, bandHigh)
}

data class WavPcm16(
    val bytes: ByteArray,
    val sampleRate: Int,
    val channels: Int,
    val dataOffset: Int,
    val dataSize: Int,
)

object VoiceMimicDsp {
    fun analyze(samples: ShortArray, sampleRate: Int): VoiceAcousticProfile {
        require(sampleRate > 0)
        if (samples.isEmpty()) return VoiceAcousticProfile(sampleRate, 0f, 0f, 0f, 0f, 1f, 1f, 1f, 1f)

        var sumSq = 0.0
        var zc = 0
        var prev = samples[0].toInt()
        var peak = 1
        for (s in samples) {
            val v = s.toInt()
            sumSq += v.toDouble() * v.toDouble()
            peak = max(peak, abs(v))
            if ((v >= 0) != (prev >= 0)) zc++
            prev = v
        }
        val rms = (sqrt(sumSq / samples.size) / 32768.0).coerceIn(0.0, 1.0)
        val zcr = (zc.toDouble() / samples.size).coerceIn(0.0, 1.0)

        val frame = max(320, (sampleRate * 0.04).toInt())
        val hop = max(160, frame / 2)
        val pitches = ArrayList<Float>()
        var voicedFrames = 0
        var frames = 0
        var start = 0
        while (start + frame <= samples.size) {
            frames++
            val f = ShortArray(frame) { samples[start + it] }
            val frms = frameRms(f)
            if (frms > max(0.012f, (rms * 0.18).toFloat())) {
                val p = estimatePitchAutocorrelation(f, sampleRate)
                if (p in 70f..340f) {
                    pitches += p
                    voicedFrames++
                }
            }
            start += hop
        }
        val pitch = median(pitches).takeIf { it > 0f } ?: 0f
        val voicedFraction = if (frames > 0) voicedFrames.toFloat() / frames else 0f

        // Coarse spectral envelope. Multiple Goertzel probes per band are much cheaper than
        // an FFT and are sufficient for a stable timbre fingerprint on-device.
        val probe = if (samples.size > sampleRate * 6) {
            val stride = max(1, samples.size / (sampleRate * 6))
            ShortArray(min(samples.size, sampleRate * 6)) { samples[min(samples.lastIndex, it * stride)] }
        } else samples
        val low = bandEnergy(probe, sampleRate, floatArrayOf(140f, 220f, 320f, 450f))
        val mid = bandEnergy(probe, sampleRate, floatArrayOf(650f, 900f, 1200f, 1450f))
        val presence = bandEnergy(probe, sampleRate, floatArrayOf(1800f, 2200f, 2700f, 3200f))
        val high = bandEnergy(probe, sampleRate, floatArrayOf(3800f, 4600f, 5600f, 6800f).filter { it < sampleRate * 0.46f }.toFloatArray())
        val bands = normalizeBands(floatArrayOf(low, mid, presence, high))

        return VoiceAcousticProfile(
            sampleRate = sampleRate,
            pitchHz = pitch,
            rms = rms.toFloat(),
            zcr = zcr.toFloat(),
            voicedFraction = voicedFraction.coerceIn(0f, 1f),
            bandLow = bands[0],
            bandMid = bands[1],
            bandPresence = bands[2],
            bandHigh = bands[3],
        )
    }

    fun acousticMatch(reference: VoiceAcousticProfile, output: VoiceAcousticProfile): Float {
        var score = 0.0
        var weight = 0.0
        if (reference.pitchHz > 0f && output.pitchHz > 0f) {
            val oct = abs(ln((reference.pitchHz / output.pitchHz).toDouble()) / ln(2.0))
            score += (1.0 - (oct / 0.8).coerceIn(0.0, 1.0)) * 0.45
            weight += 0.45
        }
        val rb = reference.fingerprint
        val ob = output.fingerprint
        var d = 0.0
        for (i in 0..3) d += abs(ln((rb[i].coerceAtLeast(0.05f) / ob[i].coerceAtLeast(0.05f)).toDouble()))
        d /= 4.0
        score += (1.0 - (d / 0.75).coerceIn(0.0, 1.0)) * 0.45
        weight += 0.45
        val zd = abs(reference.zcr - output.zcr).toDouble()
        score += (1.0 - (zd / 0.18).coerceIn(0.0, 1.0)) * 0.10
        weight += 0.10
        return if (weight > 0) (score / weight).toFloat().coerceIn(0f, 1f) else 0f
    }

    /** Suggested Android TTS pitch multiplier, blended by mimic strength. */
    fun ttsPitchMultiplier(profile: VoiceAcousticProfile, strength: Float): Float {
        if (profile.pitchHz <= 0f) return 1f
        // 165 Hz is a neutral reference only; Android TTS still provides the base voice.
        val raw = (profile.pitchHz / 165f).coerceIn(0.62f, 1.55f)
        val s = strength.coerceIn(0f, 1f)
        return (1f + (raw - 1f) * s).coerceIn(0.62f, 1.55f)
    }

    /**
     * Apply coarse spectral-envelope matching to a 16-bit PCM WAV. The RIFF container and
     * all non-audio chunks are preserved. Returns false when the WAV format is unsupported.
     */
    fun transformWav16(input: File, output: File, profile: VoiceAcousticProfile, strength: Float): Boolean {
        val wav = readWav16(input) ?: return false
        val s = strength.coerceIn(0f, 1f)
        if (s <= 0f) {
            input.copyTo(output, overwrite = true)
            return true
        }
        val bytes = wav.bytes.copyOf()
        val channels = wav.channels.coerceAtLeast(1)
        val frameCount = wav.dataSize / (2 * channels)
        if (frameCount <= 0) return false

        val gains = floatArrayOf(profile.bandLow, profile.bandMid, profile.bandPresence, profile.bandHigh)
        for (i in gains.indices) gains[i] = (1f + (gains[i].coerceIn(0.55f, 1.8f) - 1f) * s).coerceIn(0.65f, 1.65f)
        // Keep overall energy stable even with aggressive spectral profiles.
        val gainNorm = max(1f, (gains.sum() / 4f) * 1.08f)
        for (i in gains.indices) gains[i] /= gainNorm

        val fc1 = 500.0
        val fc2 = 1500.0
        val fc3 = min(3200.0, wav.sampleRate * 0.38)
        val a1 = onePoleAlpha(fc1, wav.sampleRate)
        val a2 = onePoleAlpha(fc2, wav.sampleRate)
        val a3 = onePoleAlpha(fc3, wav.sampleRate)
        val lp1 = DoubleArray(channels)
        val lp2 = DoubleArray(channels)
        val lp3 = DoubleArray(channels)

        var pos = wav.dataOffset
        var peakOut = 1.0
        val temp = IntArray(frameCount * channels)
        var ti = 0
        for (f in 0 until frameCount) {
            for (ch in 0 until channels) {
                val x = readS16(bytes, pos).toDouble() / 32768.0
                pos += 2
                lp1[ch] += a1 * (x - lp1[ch])
                lp2[ch] += a2 * (x - lp2[ch])
                lp3[ch] += a3 * (x - lp3[ch])
                val low = lp1[ch]
                val mid = lp2[ch] - lp1[ch]
                val presence = lp3[ch] - lp2[ch]
                val high = x - lp3[ch]
                val wet = low * gains[0] + mid * gains[1] + presence * gains[2] + high * gains[3]
                val mixed = x * (1.0 - 0.72 * s) + wet * (0.72 * s)
                val limited = softLimit(mixed)
                peakOut = max(peakOut, abs(limited))
                temp[ti++] = (limited * 32767.0).toInt()
            }
        }
        val scale = if (peakOut > 0.96) 0.96 / peakOut else 1.0
        pos = wav.dataOffset
        for (v in temp) {
            val y = (v * scale).toInt().coerceIn(-32768, 32767)
            bytes[pos] = (y and 0xff).toByte()
            bytes[pos + 1] = ((y shr 8) and 0xff).toByte()
            pos += 2
        }
        output.parentFile?.mkdirs()
        output.writeBytes(bytes)
        return true
    }

    fun analyzeWav16(file: File): VoiceAcousticProfile? {
        val wav = readWav16(file) ?: return null
        val channels = wav.channels.coerceAtLeast(1)
        val frames = wav.dataSize / (2 * channels)
        if (frames <= 0) return null
        val mono = ShortArray(frames)
        var pos = wav.dataOffset
        for (f in 0 until frames) {
            var sum = 0
            for (ch in 0 until channels) {
                sum += readS16(wav.bytes, pos)
                pos += 2
            }
            mono[f] = (sum / channels).coerceIn(-32768, 32767).toShort()
        }
        return analyze(mono, wav.sampleRate)
    }

    fun readWav16(file: File): WavPcm16? {
        val bytes = runCatching { file.readBytes() }.getOrNull() ?: return null
        if (bytes.size < 44 || ascii(bytes, 0, 4) != "RIFF" || ascii(bytes, 8, 4) != "WAVE") return null
        var sampleRate = 0
        var channels = 0
        var bits = 0
        var format = 0
        var dataOffset = -1
        var dataSize = 0
        var p = 12
        while (p + 8 <= bytes.size) {
            val id = ascii(bytes, p, 4)
            val size = readI32(bytes, p + 4).coerceAtLeast(0)
            val payload = p + 8
            if (payload > bytes.size) break
            if (id == "fmt " && size >= 16 && payload + 16 <= bytes.size) {
                format = readU16(bytes, payload)
                channels = readU16(bytes, payload + 2)
                sampleRate = readI32(bytes, payload + 4)
                bits = readU16(bytes, payload + 14)
            } else if (id == "data") {
                dataOffset = payload
                dataSize = min(size, bytes.size - payload)
                break
            }
            p = payload + size + (size and 1)
        }
        if (format != 1 || bits != 16 || sampleRate <= 0 || channels !in 1..8 || dataOffset < 0 || dataSize < 2) return null
        return WavPcm16(bytes, sampleRate, channels, dataOffset, dataSize - (dataSize % (2 * channels)))
    }

    private fun estimatePitchAutocorrelation(frame: ShortArray, sampleRate: Int): Float {
        if (frame.size < 64) return 0f
        val x = DoubleArray(frame.size)
        var mean = 0.0
        for (v in frame) mean += v
        mean /= frame.size
        var energy = 0.0
        for (i in frame.indices) {
            // Hann window reduces false lag peaks on short speech frames.
            val w = 0.5 - 0.5 * cos(2.0 * PI * i / max(1, frame.lastIndex))
            x[i] = (frame[i] - mean) * w
            energy += x[i] * x[i]
        }
        if (energy <= 1e-9) return 0f
        val minLag = max(2, sampleRate / 340)
        val maxLag = min(frame.size / 2, sampleRate / 70)
        var bestLag = 0
        var best = 0.0
        for (lag in minLag..maxLag) {
            var num = 0.0
            var e1 = 0.0
            var e2 = 0.0
            val n = frame.size - lag
            for (i in 0 until n) {
                val a = x[i]
                val b = x[i + lag]
                num += a * b
                e1 += a * a
                e2 += b * b
            }
            val c = if (e1 > 0 && e2 > 0) num / sqrt(e1 * e2) else 0.0
            if (c > best) { best = c; bestLag = lag }
        }
        return if (bestLag > 0 && best >= 0.28) sampleRate.toFloat() / bestLag else 0f
    }

    private fun bandEnergy(samples: ShortArray, sampleRate: Int, freqs: FloatArray): Float {
        if (samples.isEmpty() || freqs.isEmpty()) return 1e-6f
        var sum = 0.0
        // Use at most ~24k samples per Goertzel probe for predictable enrollment latency.
        val n = min(samples.size, 24_000)
        val stride = max(1, samples.size / n)
        for (f in freqs) {
            if (f <= 0 || f >= sampleRate * 0.49f) continue
            val omega = 2.0 * PI * f / sampleRate
            val coeff = 2.0 * cos(omega)
            var q0: Double
            var q1 = 0.0
            var q2 = 0.0
            var idx = 0
            repeat(n) {
                val x = samples[idx].toDouble() / 32768.0
                q0 = coeff * q1 - q2 + x
                q2 = q1
                q1 = q0
                idx = min(samples.lastIndex, idx + stride)
            }
            val power = q1 * q1 + q2 * q2 - coeff * q1 * q2
            sum += max(0.0, power) / n
        }
        return max(1e-7, sum / max(1, freqs.size)).toFloat()
    }

    private fun normalizeBands(b: FloatArray): FloatArray {
        val safe = b.map { max(1e-7f, it) }
        val geo = kotlin.math.exp(safe.map { ln(it.toDouble()) }.average()).toFloat().coerceAtLeast(1e-7f)
        return FloatArray(4) { (safe[it] / geo).coerceIn(0.45f, 2.2f) }
    }

    private fun frameRms(f: ShortArray): Float {
        if (f.isEmpty()) return 0f
        var s = 0.0
        for (v in f) s += v.toDouble() * v
        return (sqrt(s / f.size) / 32768.0).toFloat()
    }

    private fun median(v: List<Float>): Float {
        if (v.isEmpty()) return 0f
        val s = v.sorted()
        val m = s.size / 2
        return if (s.size % 2 == 1) s[m] else (s[m - 1] + s[m]) * 0.5f
    }

    private fun onePoleAlpha(cutoff: Double, sampleRate: Int): Double {
        val x = kotlin.math.exp(-2.0 * PI * cutoff / sampleRate)
        return 1.0 - x
    }

    private fun softLimit(x: Double): Double {
        val a = abs(x)
        return if (a <= 0.82) x else kotlin.math.sign(x) * (0.82 + 0.18 * (1.0 - kotlin.math.exp(-(a - 0.82) * 4.0)))
    }

    private fun ascii(b: ByteArray, p: Int, n: Int): String = String(b, p, n, Charsets.US_ASCII)
    private fun readU16(b: ByteArray, p: Int): Int = (b[p].toInt() and 0xff) or ((b[p + 1].toInt() and 0xff) shl 8)
    private fun readI32(b: ByteArray, p: Int): Int = ByteBuffer.wrap(b, p, 4).order(ByteOrder.LITTLE_ENDIAN).int
    private fun readS16(b: ByteArray, p: Int): Int = ((b[p].toInt() and 0xff) or (b[p + 1].toInt() shl 8)).toShort().toInt()
}
