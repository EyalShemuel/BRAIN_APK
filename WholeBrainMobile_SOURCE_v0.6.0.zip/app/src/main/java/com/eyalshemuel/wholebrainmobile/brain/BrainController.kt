package com.eyalshemuel.wholebrainmobile.brain

import android.app.ActivityManager
import android.content.Context
import android.hardware.Sensor
import android.os.PowerManager
import android.util.Log
import com.eyalshemuel.wholebrainmobile.storage.BrainStateStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.min

class BrainController(private val context: Context) {
    private val executor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "WholeBrain-Step").apply { priority = Thread.NORM_PRIORITY + 1 }
    }
    private var loop: ScheduledFuture<*>? = null
    @Volatile private var handle: Long = 0
    @Volatile private var thermalStatus: Int = PowerManager.THERMAL_STATUS_NONE
    private var skippedForThermal = 0
    private var nativeSteps = 0L
    private var currentStateKey: String? = null
    private val store = BrainStateStore(context)
    private val _state = MutableStateFlow(BrainUiState())
    val state: StateFlow<BrainUiState> = _state.asStateFlow()
    private val _trace = MutableStateFlow(NeuralTrace())
    val trace: StateFlow<NeuralTrace> = _trace.asStateFlow()
    @Volatile private var traceEnabled = false
    @Volatile private var traceHistoryBack = 0

    fun initialize(seed: Long = 261_711L) {
        if (handle != 0L || !_state.value.calibrating) return
        executor.execute {
            try {
                val am = context.getSystemService(ActivityManager::class.java)
                val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
                // Native allocations are outside the Java heap; still keep a conservative OS margin.
                val budget = min((mi.availMem * 0.25).toLong(), 1_800_000_000L).coerceAtLeast(128_000_000L)
                val rec = parseRecommendation(NativeBrain.nativeCalibrate(budget))
                _state.value = _state.value.copy(recommendation = rec)
                // Safe initial profile; Balanced/Max can be applied from Device screen.
                rebuildBlocking(ScaleProfile.Verified, seed)
            } catch (t: Throwable) {
                Log.e("WholeBrain", "initialize", t)
                _state.value = _state.value.copy(calibrating = false, error = t.message ?: t.javaClass.simpleName)
            }
        }
    }

    fun rebuild(profile: ScaleProfile, seed: Long = 261_711L) {
        _state.value = _state.value.copy(calibrating = true)
        executor.execute { rebuildBlocking(profile, seed) }
    }

    @Synchronized private fun rebuildBlocking(profile: ScaleProfile, seed: Long = 261_711L) {
        stopLoop()
        val old = handle
        if (old != 0L) { currentStateKey?.let { key -> runCatching { store.save(key, NativeBrain.nativeSave(old)) } }; NativeBrain.nativeDestroy(old) }
        val rec = _state.value.recommendation
        val pair = when (profile) {
            ScaleProfile.Verified -> 250_000L to 1024
            ScaleProfile.Balanced -> rec.balancedNeurons.coerceAtMost(2_500_000L).coerceAtLeast(250_000L) to rec.balancedFanout
            ScaleProfile.Max -> rec.maxNeurons.coerceAtLeast(250_000L) to rec.maxFanout
        }
        try {
            handle = NativeBrain.nativeCreate(pair.first, pair.second, seed)
            nativeSteps = 0
            currentStateKey = "v3_n${pair.first}_k${pair.second}_s$seed"
            currentStateKey?.let { key -> store.load(key)?.let { NativeBrain.nativeRestore(handle, it) } }
            NativeBrain.nativeSetMode(handle, _state.value.stats.mode.nativeValue)
            NativeBrain.nativeSetTraceEnabled(handle, traceEnabled)
            _state.value = _state.value.copy(running = true, calibrating = false, profile = profile, error = null)
            startLoop()
        } catch (t: Throwable) {
            handle = 0
            _state.value = _state.value.copy(running = false, calibrating = false, error = "Allocation/build failed: ${t.message}")
        }
    }

    private fun startLoop() {
        if (loop != null || handle == 0L) return
        loop = executor.scheduleAtFixedRate({
            val h = handle
            if (h == 0L) return@scheduleAtFixedRate
            try {
                // At severe thermal levels preserve state and reduce compute instead of silently changing topology.
                if (thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
                    skippedForThermal = (skippedForThermal + 1) % 3
                    if (skippedForThermal != 0) return@scheduleAtFixedRate
                }
                NativeBrain.nativeStep(h)
                nativeSteps++
                if (nativeSteps % 4L == 0L) {
                    val stats = parseStats(NativeBrain.nativeStats(h))
                    _state.value = _state.value.copy(stats = stats, thermalStatus = thermalStatus, running = true)
                    if (traceEnabled) {
                        val parsed = parseTrace(NativeBrain.nativeTraceFrame(h, traceHistoryBack), traceHistoryBack)
                        if (parsed.totalNeurons > 0) _trace.value = parsed
                    }
                }
            } catch (t: Throwable) {
                _state.value = _state.value.copy(error = t.message ?: "Native step failed", running = false)
            }
        }, 0, 10, TimeUnit.MILLISECONDS)
    }

    private fun stopLoop() { loop?.cancel(false); loop = null }

    fun shutdown() {
        stopLoop(); val h = handle; handle = 0
        if (h != 0L) { currentStateKey?.let { key -> runCatching { store.save(key, NativeBrain.nativeSave(h)) } }; NativeBrain.nativeDestroy(h) }
    }

    fun saveNow(): Boolean = withHandle(false) { h -> currentStateKey?.let { store.save(it, NativeBrain.nativeSave(h)); true } ?: false }
    fun saveAsync() { executor.execute { saveNow() } }
    fun loadNow(): Boolean = withHandle(false) { h -> currentStateKey?.let { key -> store.load(key)?.let { NativeBrain.nativeRestore(h, it) } } ?: false }
    fun setMode(mode: BrainMode) = withHandle(Unit) { NativeBrain.nativeSetMode(it, mode.nativeValue) }
    fun reward(positive: Boolean) = withHandle(Unit) { NativeBrain.nativeReward(it, positive) }

    fun setTraceEnabled(enabled: Boolean) {
        traceEnabled = enabled
        traceHistoryBack = 0
        if (!enabled) _trace.value = NeuralTrace()
        withHandle(Unit) { NativeBrain.nativeSetTraceEnabled(it, enabled) }
    }

    fun setTraceHistoryBack(back: Int) {
        traceHistoryBack = back.coerceAtLeast(0)
        if (traceEnabled) executor.execute {
            val h = handle
            if (h != 0L) {
                val parsed = parseTrace(NativeBrain.nativeTraceFrame(h, traceHistoryBack), traceHistoryBack)
                if (parsed.totalNeurons > 0) _trace.value = parsed
            }
        }
    }

    fun setSensorMode(mode: SensorMode) {
        _state.value = _state.value.copy(sensorMode = mode)
        withHandle(Unit) { NativeBrain.nativeResetDiagnostics(it) }
    }

    fun noteCameraFrame() = withHandle(Unit) { NativeBrain.nativeNoteCameraFrame(it) }

    fun injectSensor(type: Int, x: Float, y: Float, z: Float) {
        val mode = _state.value.sensorMode
        val allowed = mode == SensorMode.AllSensors ||
            (mode == SensorMode.ImuOnly && isImuType(type)) ||
            (mode == SensorMode.EnvironmentOnly && !isImuType(type))
        if (allowed) withHandle(Unit) { NativeBrain.nativeSensor(it,type,x,y,z) }
    }
    fun injectTouch(x: Float, y: Float, pressure: Float) {
        val mode=_state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.TouchOnly) withHandle(Unit) { NativeBrain.nativeTouch(it,x,y,pressure) }
    }
    fun injectLocation(lat: Double, lon: Double, speed: Float, bearing: Float) {
        val mode=_state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.LocationOnly) withHandle(Unit) { NativeBrain.nativeLocation(it,lat,lon,speed,bearing) }
    }
    fun injectVision(pixels: ByteArray, w: Int, h: Int) {
        val mode = _state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.VisionOnly) withHandle(Unit) { NativeBrain.nativeVision(it,pixels,w,h) }
    }
    fun injectAudio(pcm: ShortArray, sampleRate: Int) {
        val mode = _state.value.sensorMode
        if (mode == SensorMode.AllSensors || mode == SensorMode.AudioOnly) withHandle(Unit) { NativeBrain.nativeAudio(it,pcm,sampleRate) }
    }
    fun injectToken(channel: Int, bytes: ByteArray) {
        val mode=_state.value.sensorMode
        // Channel 9 is an internal scientific/teaching cue and remains available in Learn.
        if (channel==9 || mode == SensorMode.AllSensors || mode == SensorMode.ExternalOnly) withHandle(Unit) { NativeBrain.nativeToken(it,channel,bytes) }
    }
    fun setThermalStatus(status: Int) { thermalStatus = status }

    private fun isImuType(type: Int): Boolean = when(type) {
        Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_MAGNETIC_FIELD, Sensor.TYPE_GYROSCOPE,
        Sensor.TYPE_GRAVITY, Sensor.TYPE_LINEAR_ACCELERATION, Sensor.TYPE_ROTATION_VECTOR,
        Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED, Sensor.TYPE_GAME_ROTATION_VECTOR,
        Sensor.TYPE_GYROSCOPE_UNCALIBRATED, Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR,
        3, 27, 28, 35, 37, 38, 39, 40, 41, 42 -> true
        else -> false
    }

    private inline fun <T> withHandle(default: T, block: (Long)->T): T { val h=handle; return if(h==0L) default else block(h) }

    private fun parseTrace(data: IntArray, historyBack: Int): NeuralTrace {
        if (data.size < 7 || data[0] != 1) return NeuralTrace(historyBack = historyBack)
        val tick = (data[1].toLong() and 0xffffffffL) or ((data[2].toLong() and 0xffffffffL) shl 32)
        val neuronCount = data[3].coerceAtLeast(0)
        val edgeCount = data[4].coerceAtLeast(0)
        val totalNeurons = data[5].coerceAtLeast(0)
        val historyDepth = data[6].coerceAtLeast(0)
        val expected = 7L + neuronCount.toLong() + edgeCount.toLong() * 4L
        if (expected > data.size.toLong()) return NeuralTrace(historyBack = historyBack)
        var off = 7
        val fired = ArrayList<Int>(neuronCount)
        repeat(neuronCount) { fired += data[off++] }
        val edges = ArrayList<NeuralEdge>(edgeCount)
        repeat(edgeCount) {
            val src = data[off++]
            val dst = data[off++]
            val delay = data[off++]
            val sign = data[off++]
            edges += NeuralEdge(src, dst, delay, sign >= 0)
        }
        return NeuralTrace(tick, totalNeurons, fired, edges, historyDepth, historyBack)
    }

    private fun parseRecommendation(json: String): ScaleRecommendation = JSONObject(json).run {
        ScaleRecommendation(
            optLong("balancedNeurons",250_000), optInt("balancedFanout",1024),
            optLong("maxNeurons",250_000), optInt("maxFanout",1024),
            optLong("logicalConnectionsBalanced",0), optLong("logicalConnectionsMax",0),
            optDouble("edgeHashPerSecond",0.0), optLong("memoryBudgetBytes",0)
        )
    }

    private fun parseStats(json: String): BrainStats = JSONObject(json).run {
        BrainStats(
            neurons=optLong("neurons"), logicalSynapses=optLong("logicalSynapses"), tick=optLong("tick"),
            spikesTotal=optLong("spikesTotal"), edgeEventsTotal=optLong("edgeEventsTotal"),
            spikesLastStep=optInt("spikesLastStep"), queuedEvents=optLong("queuedEvents"),
            lastStepMs=optDouble("lastStepMs"), spikesPerSecond=optDouble("spikesPerSecond"),
            edgesPerSecond=optDouble("edgesPerSecond"), stepHz=optDouble("stepHz"),
            regionSpikesPerSecond=optJSONArray("regionSpikesPerSecond")?.let { a -> List(15){ i -> a.optDouble(i,0.0) } } ?: List(15){0.0},
            cameraFramesPerSecond=optDouble("cameraFramesPerSecond"), visionFramesPerSecond=optDouble("visionFramesPerSecond"),
            visionFeaturesPerSecond=optDouble("visionFeaturesPerSecond"), visionInjectionsPerSecond=optDouble("visionInjectionsPerSecond"),
            audioChunksPerSecond=optDouble("audioChunksPerSecond"), audioBandsPerSecond=optDouble("audioBandsPerSecond"),
            audioInjectionsPerSecond=optDouble("audioInjectionsPerSecond"),
            touchEventsPerSecond=optDouble("touchEventsPerSecond"), touchInjectionsPerSecond=optDouble("touchInjectionsPerSecond"),
            imuEventsPerSecond=optDouble("imuEventsPerSecond"), imuChangesPerSecond=optDouble("imuChangesPerSecond"),
            imuInjectionsPerSecond=optDouble("imuInjectionsPerSecond"),
            environmentEventsPerSecond=optDouble("environmentEventsPerSecond"), environmentChangesPerSecond=optDouble("environmentChangesPerSecond"),
            environmentInjectionsPerSecond=optDouble("environmentInjectionsPerSecond"),
            locationEventsPerSecond=optDouble("locationEventsPerSecond"), locationInjectionsPerSecond=optDouble("locationInjectionsPerSecond"),
            externalTokensPerSecond=optDouble("externalTokensPerSecond"), externalInjectionsPerSecond=optDouble("externalInjectionsPerSecond"),
            currentAction=optInt("currentAction",-1), actionEpoch=optLong("actionEpoch",0), motorMargin=optDouble("motorMargin"),
            reinforcedEpisodes=optLong("reinforcedEpisodes"), memoryBytes=optLong("memoryBytes"),
            motorDifferential=optDouble("motorDifferential",0.0),
            mode=BrainMode.entries.getOrElse(optInt("mode",0)){ BrainMode.Observe }
        )
    }
}
