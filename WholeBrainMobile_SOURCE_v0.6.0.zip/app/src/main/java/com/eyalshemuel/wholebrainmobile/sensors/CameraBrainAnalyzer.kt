package com.eyalshemuel.wholebrainmobile.sensors

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.eyalshemuel.wholebrainmobile.brain.BrainController
import java.util.concurrent.Executors

class CameraBrainAnalyzer(private val context: Context, private val brain: BrainController) {
    private val executor=Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider?=null
    private var analysisUseCase: ImageAnalysis?=null
    private var previewUseCase: Preview?=null
    private var frameNo=0

    private fun ensureAnalysis(p:ProcessCameraProvider,owner:LifecycleOwner){
        val existing=analysisUseCase
        if(existing!=null && p.isBound(existing)) return
        val analysis=existing?:ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build().also { useCase ->
                useCase.setAnalyzer(executor){ image -> analyze(image) }
                analysisUseCase=useCase
            }
        p.bindToLifecycle(owner,CameraSelector.DEFAULT_BACK_CAMERA,analysis)
    }

    fun bindAnalysis(owner: LifecycleOwner) {
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return
        val future=ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val p=future.get(); provider=p
                ensureAnalysis(p,owner)
            }
        },ContextCompat.getMainExecutor(context))
    }

    fun bind(owner: LifecycleOwner, previewView: PreviewView) {
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return
        val future=ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val p=future.get(); provider=p
                ensureAnalysis(p,owner)
                previewUseCase?.let { if(p.isBound(it)) p.unbind(it) }
                val preview=Preview.Builder().build().also{it.surfaceProvider=previewView.surfaceProvider}
                previewUseCase=preview
                p.bindToLifecycle(owner,CameraSelector.DEFAULT_BACK_CAMERA,preview)
            }
        },ContextCompat.getMainExecutor(context))
    }

    private fun sample(image:ImageProxy, planeIndex:Int, sx:Int, sy:Int):Int {
        val plane=image.planes.getOrNull(planeIndex)?:return if(planeIndex==0)0 else 128
        val div=if(planeIndex==0)1 else 2
        val x=(sx/div).coerceAtLeast(0)
        val y=(sy/div).coerceAtLeast(0)
        val pos=y*plane.rowStride+x*plane.pixelStride
        return if(pos in 0 until plane.buffer.limit()) plane.buffer.get(pos).toInt() and 0xFF else if(planeIndex==0)0 else 128
    }

    private fun analyze(image: ImageProxy){
        try{
            frameNo++
            brain.noteCameraFrame()
            if(frameNo%3!=0)return
            val srcW=image.width; val srcH=image.height
            val rotation=((image.imageInfo.rotationDegrees%360)+360)%360
            // Retinal coordinates are defined in display/upright orientation, so the same
            // scene location maps to the same Visual column in portrait/landscape.
            val orientedW=if(rotation==90||rotation==270)srcH else srcW
            val orientedH=if(rotation==90||rotation==270)srcW else srcH
            val w=64; val h=36
            val out=ByteArray(w*h*3)

            fun rawPoint(ox:Int,oy:Int):Pair<Int,Int> = when(rotation){
                90 -> oy.coerceIn(0,srcW-1) to (srcH-1-ox).coerceIn(0,srcH-1)
                180 -> (srcW-1-ox).coerceIn(0,srcW-1) to (srcH-1-oy).coerceIn(0,srcH-1)
                270 -> (srcW-1-oy).coerceIn(0,srcW-1) to ox.coerceIn(0,srcH-1)
                else -> ox.coerceIn(0,srcW-1) to oy.coerceIn(0,srcH-1)
            }

            // 3x3 stratified sampling per retinal cell greatly reduces aliasing without
            // copying/resizing the full camera frame. 64*36*9 remains inexpensive on-phone.
            for(y in 0 until h){
                val y0=y*orientedH/h
                val y1=((y+1)*orientedH/h-1).coerceAtLeast(y0)
                for(x in 0 until w){
                    val x0=x*orientedW/w
                    val x1=((x+1)*orientedW/w-1).coerceAtLeast(x0)
                    var yy=0;var uu=0;var vv=0;var taps=0
                    for(ty in 0..2) for(tx in 0..2){
                        val ox=x0+((x1-x0)*tx)/2
                        val oy=y0+((y1-y0)*ty)/2
                        val (sx,sy)=rawPoint(ox,oy)
                        yy+=sample(image,0,sx,sy);uu+=sample(image,1,sx,sy);vv+=sample(image,2,sx,sy);taps++
                    }
                    val p=(y*w+x)*3
                    out[p]=(yy/taps).toByte(); out[p+1]=(uu/taps).toByte(); out[p+2]=(vv/taps).toByte()
                }
            }
            brain.injectVision(out,w,h)
        }finally{ image.close() }
    }
    fun unbind(){
        val p=provider
        if(p!=null){
            analysisUseCase?.let{runCatching{p.unbind(it)}}
            previewUseCase?.let{runCatching{p.unbind(it)}}
        }
        analysisUseCase=null;previewUseCase=null;provider=null
    }
    fun close(){unbind();executor.shutdownNow()}
}
