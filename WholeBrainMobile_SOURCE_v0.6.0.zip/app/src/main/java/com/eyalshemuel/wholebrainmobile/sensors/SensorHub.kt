package com.eyalshemuel.wholebrainmobile.sensors

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.TriggerEvent
import android.hardware.TriggerEventListener
import android.hardware.usb.UsbManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.eyalshemuel.wholebrainmobile.brain.BrainController

class SensorHub(private val context: Context, private val brain: BrainController): SensorEventListener, LocationListener {
    private val sensors=context.getSystemService(SensorManager::class.java)
    private val location=context.getSystemService(LocationManager::class.java)
    private val power=context.getSystemService(PowerManager::class.java)
    private val connectivity=context.getSystemService(ConnectivityManager::class.java)
    private val usb=context.getSystemService(UsbManager::class.java)
    private val bluetooth=context.getSystemService(BluetoothManager::class.java)?.adapter
    private val audio=AudioBrainCapture(context,brain)
    private val camera=CameraBrainAnalyzer(context,brain)
    private var started=false
    private var receiverRegistered=false
    private var networkRegistered=false
    private var bleScanning=false
    private var audioPausedForVoiceEnrollment=false
    private val externalSeen=mutableMapOf<String,Pair<Int,Long>>()
    private val thermalListener=PowerManager.OnThermalStatusChangedListener { brain.setThermalStatus(it); brain.injectSensor(10002,it.toFloat(),0f,0f) }

    private val triggerListener=object:TriggerEventListener(){
        override fun onTrigger(event:TriggerEvent){
            val v=event.values
            brain.injectSensor(event.sensor.type,v.getOrElse(0){1f},v.getOrElse(1){0f},v.getOrElse(2){0f})
            if(started)runCatching{sensors.requestTriggerSensor(this,event.sensor)}
        }
    }

    private val networkCallback=object:ConnectivityManager.NetworkCallback(){
        override fun onAvailable(network:Network){injectNetworkContext()}
        override fun onLost(network:Network){injectNetworkContext()}
        override fun onCapabilitiesChanged(network:Network,caps:NetworkCapabilities){injectNetworkContext(caps)}
    }

    private val externalReceiver=object:BroadcastReceiver(){
        override fun onReceive(c:Context?,intent:Intent?){
            when(intent?.action){
                UsbManager.ACTION_USB_DEVICE_ATTACHED,UsbManager.ACTION_USB_DEVICE_DETACHED->injectUsbContext()
                BluetoothAdapter.ACTION_STATE_CHANGED->injectBluetoothBondedContext()
                Intent.ACTION_BATTERY_CHANGED->injectBatteryContext()
            }
        }
    }

    private val bleCallback=object:ScanCallback(){
        override fun onScanResult(callbackType:Int,result:ScanResult){
            val device=result.device?:return
            val address=runCatching{device.address}.getOrNull()?:return
            val bucket=(result.rssi/5)*5
            val now=SystemClock.elapsedRealtime()
            val old=externalSeen[address]
            if(old!=null && old.first==bucket && now-old.second<15_000L)return
            externalSeen[address]=bucket to now
            val name=if(canBluetoothConnect())runCatching{device.name}.getOrNull() else null
            brain.injectToken(3,"BLE:$address:${name?:"unknown"}:rssi$bucket".encodeToByteArray())
        }
    }

    fun start(){
        if(started)return;started=true

        // Do not subscribe to every virtual/calibrated/uncalibrated duplicate sensor.
        // One canonical sensor per physical modality keeps the brain from being driven
        // 5-10x harder simply because a vendor exposes redundant Android sensor types.
        val selected=linkedMapOf<Int,Sensor>()
        intArrayOf(
            Sensor.TYPE_ACCELEROMETER,
            Sensor.TYPE_GYROSCOPE,
            Sensor.TYPE_ROTATION_VECTOR,
            Sensor.TYPE_MAGNETIC_FIELD
        ).forEach { type -> sensors.getDefaultSensor(type)?.let { selected[type]=it } }

        sensors.getSensorList(Sensor.TYPE_ALL).forEach { sensor ->
            if(!isImuType(sensor.type) && isSupportedEnvironmentType(sensor.type) && !selected.containsKey(sensor.type)){
                selected[sensor.type]=sensors.getDefaultSensor(sensor.type)?:sensor
            }
        }

        selected.values.forEach { sensor ->
            if(sensor.reportingMode==Sensor.REPORTING_MODE_ONE_SHOT){
                runCatching{sensors.requestTriggerSensor(triggerListener,sensor)}
            }else{
                val delay=if(isImuType(sensor.type))SensorManager.SENSOR_DELAY_GAME else SensorManager.SENSOR_DELAY_NORMAL
                runCatching { sensors.registerListener(this,sensor,delay) }
            }
        }
        runCatching{power.addThermalStatusListener(ContextCompat.getMainExecutor(context),thermalListener)}
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){
            runCatching{location.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000L,1f,this)}
            runCatching{location.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,3000L,3f,this)}
        }
        audio.start()
        injectBatteryContext(); injectExternalContext()
        registerExternalEvents(); registerNetwork(); startBleScan()
    }

    fun stop(){
        if(!started)return;started=false
        sensors.unregisterListener(this)
        sensors.getSensorList(Sensor.TYPE_ALL)
            .filter { it.reportingMode == Sensor.REPORTING_MODE_ONE_SHOT }
            .forEach { sensor -> runCatching { sensors.cancelTriggerSensor(triggerListener, sensor) } }
        runCatching{location.removeUpdates(this)}
        runCatching{power.removeThermalStatusListener(thermalListener)}
        stopBleScan(); unregisterNetwork(); unregisterExternalEvents()
        audio.stop(); audioPausedForVoiceEnrollment=false; camera.unbind()
    }
    fun pauseBrainAudioForVoiceEnrollment(){
        if(started && !audioPausedForVoiceEnrollment){
            audio.stop()
            audioPausedForVoiceEnrollment=true
        }
    }
    fun resumeBrainAudioAfterVoiceEnrollment(){
        if(started && audioPausedForVoiceEnrollment){
            audioPausedForVoiceEnrollment=false
            audio.start()
        }
    }

    fun bindCameraAnalysis(owner:LifecycleOwner)=camera.bindAnalysis(owner)
    fun bindCamera(owner:LifecycleOwner,view:PreviewView)=camera.bind(owner,view)
    fun close(){stop();camera.close()}

    override fun onSensorChanged(event:SensorEvent){
        val v=event.values
        brain.injectSensor(event.sensor.type,v.getOrElse(0){0f},v.getOrElse(1){0f},v.getOrElse(2){0f})
    }
    override fun onAccuracyChanged(sensor:Sensor?,accuracy:Int)=Unit
    override fun onLocationChanged(loc:Location){brain.injectLocation(loc.latitude,loc.longitude,loc.speed,loc.bearing)}
    @Deprecated("Deprecated by Android but required for older LocationListener contracts") override fun onStatusChanged(provider:String?,status:Int,extras:Bundle?)=Unit
    override fun onProviderEnabled(provider:String)=Unit
    override fun onProviderDisabled(provider:String)=Unit

    fun injectNfcTag(id:ByteArray)=brain.injectToken(1,id)


    private fun isSupportedEnvironmentType(type:Int)=when(type){
        Sensor.TYPE_LIGHT, Sensor.TYPE_PRESSURE, Sensor.TYPE_TEMPERATURE, Sensor.TYPE_PROXIMITY,
        Sensor.TYPE_RELATIVE_HUMIDITY, Sensor.TYPE_AMBIENT_TEMPERATURE,
        Sensor.TYPE_SIGNIFICANT_MOTION, Sensor.TYPE_STEP_DETECTOR, Sensor.TYPE_STEP_COUNTER,
        Sensor.TYPE_HEART_RATE, 22,23,24,25,26,
        29,30,31,34,36 -> true
        else -> false
    }

    private fun isImuType(type:Int)=when(type){
        Sensor.TYPE_ACCELEROMETER,Sensor.TYPE_MAGNETIC_FIELD,Sensor.TYPE_GYROSCOPE,
        Sensor.TYPE_GRAVITY,Sensor.TYPE_LINEAR_ACCELERATION,Sensor.TYPE_ROTATION_VECTOR,
        Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED,Sensor.TYPE_GAME_ROTATION_VECTOR,
        Sensor.TYPE_GYROSCOPE_UNCALIBRATED,Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR,
        3,27,28,35,37,38,39,40,41,42->true
        else->false
    }

    private fun injectBatteryContext(){
        val i=context.registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED))?:return
        val level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);val scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100)
        val temp=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0)/10f;val voltage=i.getIntExtra(BatteryManager.EXTRA_VOLTAGE,0)/1000f
        brain.injectSensor(10001,if(scale>0)level.toFloat()/scale else 0f,temp,voltage)
    }

    fun injectExternalContext(){ injectNetworkContext();injectUsbContext();injectBluetoothBondedContext() }

    private fun injectNetworkContext(capsOverride:NetworkCapabilities?=null){
        val caps=capsOverride?:runCatching{connectivity.getNetworkCapabilities(connectivity.activeNetwork)}.getOrNull()
        val net=when{caps==null->"offline";caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"wifi";caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"cellular";caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)->"ethernet";caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH)->"bt-network";else->"other"}
        brain.injectToken(4,net.encodeToByteArray())
    }

    private fun injectUsbContext(){
        if(usb.deviceList.isEmpty()) brain.injectToken(2,"USB:none".encodeToByteArray())
        usb.deviceList.values.forEach{d->brain.injectToken(2,"USB:${d.vendorId}:${d.productId}:${d.deviceClass}:${d.deviceSubclass}".encodeToByteArray())}
    }

    private fun injectBluetoothBondedContext(){
        if(!canBluetoothConnect())return
        runCatching{bluetooth?.bondedDevices?.forEach{d->brain.injectToken(3,"BT:${d.address}:${d.name?:"unknown"}".encodeToByteArray())}}
    }

    private fun canBluetoothScan()=Build.VERSION.SDK_INT<31 || ContextCompat.checkSelfPermission(context,Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED
    private fun canBluetoothConnect()=Build.VERSION.SDK_INT<31 || ContextCompat.checkSelfPermission(context,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED

    private fun startBleScan(){
        if(bleScanning || !canBluetoothScan())return
        val scanner=runCatching{bluetooth?.bluetoothLeScanner}.getOrNull()?:return
        val settings=ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_POWER).build()
        if(runCatching{scanner.startScan(emptyList<ScanFilter>(),settings,bleCallback)}.isSuccess)bleScanning=true
    }
    private fun stopBleScan(){
        if(!bleScanning)return
        runCatching{bluetooth?.bluetoothLeScanner?.stopScan(bleCallback)};bleScanning=false
    }

    private fun registerNetwork(){
        if(networkRegistered)return
        if(runCatching{connectivity.registerDefaultNetworkCallback(networkCallback)}.isSuccess)networkRegistered=true
    }
    private fun unregisterNetwork(){if(networkRegistered){runCatching{connectivity.unregisterNetworkCallback(networkCallback)};networkRegistered=false}}

    private fun registerExternalEvents(){
        if(receiverRegistered)return
        val f=IntentFilter().apply{addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);addAction(BluetoothAdapter.ACTION_STATE_CHANGED);addAction(Intent.ACTION_BATTERY_CHANGED)}
        val ok=runCatching{
            if(Build.VERSION.SDK_INT>=33)context.registerReceiver(externalReceiver,f,Context.RECEIVER_NOT_EXPORTED)
            else { @Suppress("DEPRECATION") context.registerReceiver(externalReceiver,f) }
        }.isSuccess
        receiverRegistered=ok
    }
    private fun unregisterExternalEvents(){if(receiverRegistered){runCatching{context.unregisterReceiver(externalReceiver)};receiverRegistered=false}}
}
