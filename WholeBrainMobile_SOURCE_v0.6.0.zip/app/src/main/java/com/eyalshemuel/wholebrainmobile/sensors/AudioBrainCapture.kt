package com.eyalshemuel.wholebrainmobile.sensors

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import androidx.core.content.ContextCompat
import com.eyalshemuel.wholebrainmobile.brain.BrainController
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class AudioBrainCapture(private val context: Context, private val brain: BrainController) {
    private val running=AtomicBoolean(false)
    @Volatile private var record: AudioRecord?=null
    private var worker: Thread?=null
    val sampleRate=16_000

    fun start() {
        if(running.get() || ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) return
        val min=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(min<=0)return
        val sources=intArrayOf(MediaRecorder.AudioSource.UNPROCESSED,MediaRecorder.AudioSource.VOICE_RECOGNITION,MediaRecorder.AudioSource.MIC)
        var r:AudioRecord?=null
        for(source in sources){
            val candidate=runCatching{AudioRecord(source,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,maxOf(min,4096))}.getOrNull()?:continue
            if(candidate.state==AudioRecord.STATE_INITIALIZED){r=candidate;break}else candidate.release()
        }
        val active=r?:return
        record=active; running.set(true); active.startRecording()
        worker=thread(name="WholeBrain-Audio",isDaemon=true){
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val buf=ShortArray(512)
            while(running.get()){
                val n=active.read(buf,0,buf.size,AudioRecord.READ_BLOCKING)
                if(n>0) brain.injectAudio(if(n==buf.size)buf else buf.copyOf(n),sampleRate)
            }
        }
    }
    fun stop(){
        running.set(false); runCatching{record?.stop()}; worker?.join(300); worker=null; record?.release(); record=null
    }
}
