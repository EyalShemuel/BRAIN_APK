package com.eyalshemuel.wholebrainmobile.output

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * v0.6 authorized voice-mimic enrollment.
 *
 * Privacy boundary:
 * - Enrollment requires an explicit user attestation supplied by the UI.
 * - Raw microphone PCM is written only to a cache file during enrollment.
 * - The raw file is deleted immediately after acoustic features are extracted.
 * - Only a compact acoustic profile is persisted in app-private SharedPreferences.
 * - No network API is used.
 */
data class VoiceMimicState(
    val enrolled: Boolean = false,
    val enabled: Boolean = false,
    val recording: Boolean = false,
    val elapsedSeconds: Float = 0f,
    val strength: Float = 0.78f,
    val targetPitchHz: Float = 0f,
    val voicedFraction: Float = 0f,
    val referenceFingerprint: List<Float> = emptyList(),
    val outputFingerprint: List<Float> = emptyList(),
    val acousticMatch: Float = 0f,
    val consentTimestamp: Long = 0L,
    val rawSampleRetained: Boolean = false,
    val error: String? = null,
)

class AuthorizedVoiceMimic(private val context: Context) {
    private val prefs = context.getSharedPreferences("wholebrain-voice-mimic", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var record: AudioRecord? = null
    private var worker: Thread? = null
    private var tempPcm: File? = null
    private var startedAt = 0L
    private var finishedCallback: (() -> Unit)? = null
    private val sampleRate = 16_000
    private val maxSeconds = 12f
    private val minSeconds = 3.5f

    @Volatile private var profile: VoiceAcousticProfile? = loadProfile()
    private val _state = MutableStateFlow(initialState())
    val state: StateFlow<VoiceMimicState> = _state.asStateFlow()

    private fun initialState(): VoiceMimicState {
        val p = profile
        val consent = prefs.getLong("consent_timestamp", 0L)
        val enabled = prefs.getBoolean("enabled", false) && p != null && consent > 0
        val strength = prefs.getFloat("strength", 0.78f).coerceIn(0f, 1f)
        return VoiceMimicState(
            enrolled = p != null && consent > 0,
            enabled = enabled,
            strength = strength,
            targetPitchHz = p?.pitchHz ?: 0f,
            voicedFraction = p?.voicedFraction ?: 0f,
            referenceFingerprint = p?.fingerprint ?: emptyList(),
            consentTimestamp = consent,
            rawSampleRetained = false,
        )
    }

    fun setEnabled(enabled: Boolean) {
        val can = profile != null && _state.value.consentTimestamp > 0
        if (enabled && !can) {
            _state.value = _state.value.copy(enabled = false, error = "Enroll an authorized voice profile first")
            return
        }
        prefs.edit().putBoolean("enabled", enabled && can).apply()
        _state.value = _state.value.copy(enabled = enabled && can, error = null)
    }

    fun setStrength(value: Float) {
        val s = value.coerceIn(0f, 1f)
        prefs.edit().putFloat("strength", s).apply()
        _state.value = _state.value.copy(strength = s)
    }

    fun deleteProfile() {
        stopEnrollment()
        profile = null
        prefs.edit().clear().apply()
        tempPcm?.delete(); tempPcm = null
        _state.value = VoiceMimicState(rawSampleRetained = false)
    }

    /** Returns true only if microphone capture actually started. */
    fun startEnrollment(consentConfirmed: Boolean, onFinished: () -> Unit): Boolean {
        if (running.get()) return false
        if (!consentConfirmed) {
            _state.value = _state.value.copy(error = "Confirm that this is your voice or that you have explicit permission to mimic it")
            return false
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _state.value = _state.value.copy(error = "Microphone permission is required for voice enrollment")
            return false
        }
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) {
            _state.value = _state.value.copy(error = "Microphone input is unavailable")
            return false
        }
        var active: AudioRecord? = null
        for (source in intArrayOf(MediaRecorder.AudioSource.UNPROCESSED, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)) {
            val c = runCatching {
                AudioRecord(source, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096))
            }.getOrNull() ?: continue
            if (c.state == AudioRecord.STATE_INITIALIZED) { active = c; break } else c.release()
        }
        val recorder = active ?: run {
            _state.value = _state.value.copy(error = "Could not open a local microphone stream")
            return false
        }
        val tmp = File(context.cacheDir, "voice-enrollment-${System.currentTimeMillis()}.pcm")
        tempPcm?.delete()
        tempPcm = tmp
        finishedCallback = onFinished
        record = recorder
        startedAt = SystemClock.elapsedRealtime()
        running.set(true)
        _state.value = _state.value.copy(recording = true, elapsedSeconds = 0f, error = null, rawSampleRetained = false)
        recorder.startRecording()
        worker = thread(name = "WholeBrain-VoiceEnrollment", isDaemon = true) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val buf = ShortArray(512)
            var ioError: Throwable? = null
            try {
                FileOutputStream(tmp).use { out ->
                    while (running.get()) {
                        val n = recorder.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                        if (n > 0) {
                            val bytes = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                            repeat(n) { bytes.putShort(buf[it]) }
                            out.write(bytes.array())
                        }
                        val elapsed = (SystemClock.elapsedRealtime() - startedAt) / 1000f
                        main.post { _state.value = _state.value.copy(recording = true, elapsedSeconds = elapsed.coerceAtMost(maxSeconds)) }
                        if (elapsed >= maxSeconds) running.set(false)
                    }
                }
            } catch (t: Throwable) {
                ioError = t
            } finally {
                runCatching { recorder.stop() }
                recorder.release()
                record = null
                finalizeEnrollment(tmp, ioError)
            }
        }
        return true
    }

    fun stopEnrollment() {
        if (!running.getAndSet(false)) return
        runCatching { record?.stop() }
    }

    fun ttsPitchMultiplier(): Float {
        val p = profile ?: return 1f
        val s = _state.value
        return if (s.enabled) VoiceMimicDsp.ttsPitchMultiplier(p, s.strength) else 1f
    }

    /** Returns a transformed local WAV or the original file when mimic is disabled/unsupported. */
    fun processSynthesized(input: File): File {
        val p = profile
        val s = _state.value
        if (p == null || !s.enabled || s.consentTimestamp <= 0) {
            updateOutputAnalysis(input)
            return input
        }
        val out = File(context.cacheDir, input.nameWithoutExtension + "-mimic.wav")
        val ok = runCatching { VoiceMimicDsp.transformWav16(input, out, p, s.strength) }.getOrDefault(false)
        val chosen = if (ok && out.exists()) out else input
        updateOutputAnalysis(chosen)
        if (!ok) {
            _state.value = _state.value.copy(error = "This TTS engine produced an audio format that cannot be timbre-matched; pitch mimic is still active")
        }
        return chosen
    }

    private fun updateOutputAnalysis(file: File) {
        val out = VoiceMimicDsp.analyzeWav16(file) ?: return
        val ref = profile
        _state.value = _state.value.copy(
            outputFingerprint = out.fingerprint,
            acousticMatch = if (ref != null) VoiceMimicDsp.acousticMatch(ref, out) else 0f,
        )
    }

    private fun finalizeEnrollment(tmp: File, ioError: Throwable?) {
        val elapsed = (SystemClock.elapsedRealtime() - startedAt) / 1000f
        var error: String? = ioError?.message
        var newProfile: VoiceAcousticProfile? = null
        if (error == null && elapsed < minSeconds) error = "Record at least ${minSeconds.toInt() + 1} seconds of natural speech"
        if (error == null) {
            val bytes = runCatching { tmp.readBytes() }.getOrElse { error = it.message; ByteArray(0) }
            if (bytes.size >= 2) {
                val samples = ShortArray(bytes.size / 2)
                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                for (i in samples.indices) samples[i] = bb.short
                val p = VoiceMimicDsp.analyze(samples, sampleRate)
                if (p.pitchHz <= 0f || p.voicedFraction < 0.08f) error = "Not enough voiced speech detected. Speak normally and try again."
                else newProfile = p
            } else if (error == null) error = "No usable microphone samples were captured"
        }
        tmp.delete() // raw enrollment audio is never retained
        tempPcm = null

        if (newProfile != null) {
            val ts = System.currentTimeMillis()
            profile = newProfile
            saveProfile(newProfile, ts)
            _state.value = _state.value.copy(
                enrolled = true,
                enabled = true,
                recording = false,
                elapsedSeconds = elapsed,
                targetPitchHz = newProfile.pitchHz,
                voicedFraction = newProfile.voicedFraction,
                referenceFingerprint = newProfile.fingerprint,
                outputFingerprint = emptyList(),
                acousticMatch = 0f,
                consentTimestamp = ts,
                rawSampleRetained = false,
                error = null,
            )
        } else {
            _state.value = _state.value.copy(recording = false, elapsedSeconds = elapsed, rawSampleRetained = false, error = error ?: "Enrollment failed")
        }
        val cb = finishedCallback
        finishedCallback = null
        main.post { cb?.invoke() }
    }

    private fun saveProfile(p: VoiceAcousticProfile, consentTimestamp: Long) {
        prefs.edit()
            .putInt("profile_version", 1)
            .putInt("sample_rate", p.sampleRate)
            .putFloat("pitch_hz", p.pitchHz)
            .putFloat("rms", p.rms)
            .putFloat("zcr", p.zcr)
            .putFloat("voiced", p.voicedFraction)
            .putFloat("band_low", p.bandLow)
            .putFloat("band_mid", p.bandMid)
            .putFloat("band_presence", p.bandPresence)
            .putFloat("band_high", p.bandHigh)
            .putLong("consent_timestamp", consentTimestamp)
            .putBoolean("enabled", true)
            .apply()
    }

    private fun loadProfile(): VoiceAcousticProfile? {
        if (prefs.getInt("profile_version", 0) != 1) return null
        if (prefs.getLong("consent_timestamp", 0L) <= 0L) return null
        val pitch = prefs.getFloat("pitch_hz", 0f)
        if (pitch <= 0f) return null
        return VoiceAcousticProfile(
            sampleRate = prefs.getInt("sample_rate", sampleRate),
            pitchHz = pitch,
            rms = prefs.getFloat("rms", 0f),
            zcr = prefs.getFloat("zcr", 0f),
            voicedFraction = prefs.getFloat("voiced", 0f),
            bandLow = prefs.getFloat("band_low", 1f),
            bandMid = prefs.getFloat("band_mid", 1f),
            bandPresence = prefs.getFloat("band_presence", 1f),
            bandHigh = prefs.getFloat("band_high", 1f),
        )
    }

    fun close() {
        stopEnrollment()
        worker?.join(300)
        worker = null
        tempPcm?.delete(); tempPcm = null
    }
}
