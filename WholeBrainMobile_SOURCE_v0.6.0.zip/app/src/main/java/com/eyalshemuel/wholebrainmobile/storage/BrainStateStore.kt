package com.eyalshemuel.wholebrainmobile.storage

import android.content.Context
import java.io.File

class BrainStateStore(private val context: Context) {
    private val dir = File(context.filesDir, "brain_states").apply { mkdirs() }
    private fun file(key: String) = File(dir, "${key.replace(Regex("[^A-Za-z0-9_-]"), "_")}.bin")
    fun save(key: String, bytes: ByteArray) {
        if(bytes.isEmpty()) return
        val dst=file(key); val tmp=File(dst.parentFile, dst.name+".tmp")
        tmp.writeBytes(bytes)
        if(dst.exists()) dst.delete()
        if(!tmp.renameTo(dst)) { dst.writeBytes(bytes); tmp.delete() }
    }
    fun load(key: String): ByteArray? = file(key).takeIf { it.exists() && it.length() > 0 }?.readBytes()
    fun clear(key: String) { file(key).delete() }
}
