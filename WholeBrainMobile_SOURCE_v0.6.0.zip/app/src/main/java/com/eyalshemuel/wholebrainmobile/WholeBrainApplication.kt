package com.eyalshemuel.wholebrainmobile

import android.app.Application
import com.eyalshemuel.wholebrainmobile.brain.BrainController

class WholeBrainApplication : Application() {
    val brainController: BrainController by lazy { BrainController(applicationContext) }
}
