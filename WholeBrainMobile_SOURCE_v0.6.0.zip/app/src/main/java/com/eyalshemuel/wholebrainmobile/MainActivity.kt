package com.eyalshemuel.wholebrainmobile

import android.Manifest
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableIntStateOf
import com.eyalshemuel.wholebrainmobile.output.OutputRouter
import com.eyalshemuel.wholebrainmobile.sensors.SensorHub
import com.eyalshemuel.wholebrainmobile.ui.theme.WholeBrainTheme

class MainActivity:ComponentActivity(){
    private val brain by lazy{(application as WholeBrainApplication).brainController}
    private val sensors by lazy{SensorHub(this,brain)}
    private val outputs by lazy{OutputRouter(this)}
    private val permissionEpoch=mutableIntStateOf(0)
    private val permissionLauncher=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){
        permissionEpoch.intValue++; sensors.stop(); sensors.start(); sensors.bindCameraAnalysis(this)
    }

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState);brain.initialize()
        setContent{WholeBrainTheme{WholeBrainApp(brain,sensors,outputs,permissionEpoch.intValue,onRequestPermissions={ requestRuntimePermissions() })}}
        handleIntent(intent)
    }
    override fun onStart(){super.onStart();sensors.start();sensors.bindCameraAnalysis(this)}
    override fun onStop(){sensors.stop();brain.saveAsync();super.onStop()}
    override fun onDestroy(){sensors.close();outputs.close();super.onDestroy()}
    override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent);handleIntent(intent)}

    private fun handleIntent(intent:Intent?){
        if(intent?.action==NfcAdapter.ACTION_TAG_DISCOVERED){
            val tag:Tag?=if(Build.VERSION.SDK_INT>=33) intent.getParcelableExtra(NfcAdapter.EXTRA_TAG,Tag::class.java) else { @Suppress("DEPRECATION") (intent.getParcelableExtra(NfcAdapter.EXTRA_TAG) as? Tag) }
            tag?.id?.let{sensors.injectNfcTag(it)}
        }
    }
    private fun requestRuntimePermissions(){
        val p=mutableListOf(Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACTIVITY_RECOGNITION)
        if(Build.VERSION.SDK_INT>=31){p+=Manifest.permission.BLUETOOTH_SCAN;p+=Manifest.permission.BLUETOOTH_CONNECT}
        if(Build.VERSION.SDK_INT>=36) p += "android.permission.health.READ_HEART_RATE" else p += Manifest.permission.BODY_SENSORS
        if(Build.VERSION.SDK_INT>=33)p+=Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(p.toTypedArray())
    }
}
