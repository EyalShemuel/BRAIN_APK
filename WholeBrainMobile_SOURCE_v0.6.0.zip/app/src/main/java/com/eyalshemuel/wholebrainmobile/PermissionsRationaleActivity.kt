package com.eyalshemuel.wholebrainmobile

import android.app.Activity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad=(24*resources.displayMetrics.density).toInt()
        setContentView(TextView(this).apply {
            setPadding(pad,pad,pad,pad)
            textSize=17f
            movementMethod=ScrollingMovementMethod()
            text = """WholeBrain Mobile — Health sensor privacy\n\nWhy heart-rate access may be requested\nIf this phone exposes a heart-rate sensor, WholeBrain Mobile can encode its live value as local neural input so the on-device spiking system can react to the user's physiological context.\n\nHow the data is handled\n• Values are processed locally on this device.\n• The app has no INTERNET permission.\n• Heart-rate values are not uploaded, sold, or shared.\n• v0.1 does not write health data to Health Connect.\n• Denying the permission simply disables that optional sense; the rest of the app continues to work.\n\nThe plastic brain-state files are also excluded from Android cloud backup/device transfer by default.""".trimIndent()
        })
    }
}
