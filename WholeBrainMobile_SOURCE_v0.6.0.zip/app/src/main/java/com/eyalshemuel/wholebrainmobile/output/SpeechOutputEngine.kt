package com.eyalshemuel.wholebrainmobile.output

import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

/**
 * Offline-first speech actuator for v0.6 with authorized acoustic mimic integration.
 *
 * No INTERNET permission is requested by the app. We only select voices whose Android
 * TextToSpeech metadata says they do not require a network connection. The synthesized
 * file is then played locally so the exact generated audio can also be visualized.
 */
data class SpeechOutputState(
    val ready: Boolean = false,
    val synthesizing: Boolean = false,
    val speaking: Boolean = false,
    val progress: Float = 0f,
    val currentText: String = "",
    val voiceName: String = "",
    val waveform: List<Float> = emptyList(),
    val error: String? = null,
)

class SpeechOutputEngine(private val context: Context) {
    val mimic = AuthorizedVoiceMimic(context)
    private val prefs = context.getSharedPreferences("wholebrain-speech", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val _state = MutableStateFlow(SpeechOutputState())
    val state: StateFlow<SpeechOutputState> = _state.asStateFlow()

    var actionPhrase0: String = prefs.getString("action_phrase_0", "Yes") ?: "Yes"
        private set
    var actionPhrase1: String = prefs.getString("action_phrase_1", "No") ?: "No"
        private set

    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var activeId: String? = null
    private var activeFile: File? = null
    private var processedFile: File? = null

    private val progressTicker = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && runCatching { p.isPlaying }.getOrDefault(false)) {
                val duration = runCatching { p.duration }.getOrDefault(0).coerceAtLeast(1)
                val current = runCatching { p.currentPosition }.getOrDefault(0)
                _state.value = _state.value.copy(progress = (current.toFloat() / duration).coerceIn(0f, 1f), speaking = true)
                main.postDelayed(this, 50)
            }
        }
    }

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                _state.value = _state.value.copy(error = "Android offline speech engine is unavailable")
                return@TextToSpeech
            }
            configureOfflineVoice()
        }
    }

    private fun configureOfflineVoice() {
        val engine = tts ?: return
        engine.setSpeechRate(1.0f)
        engine.setPitch(1.0f)
        val locale = Locale.getDefault()
        runCatching { engine.language = locale }
        val voices = runCatching { engine.voices.orEmpty() }.getOrDefault(emptySet())
        val offline = voices.filter { !it.isNetworkConnectionRequired }
        val exact = offline.firstOrNull { it.locale.language == locale.language && it.locale.country == locale.country }
        val sameLanguage = offline.firstOrNull { it.locale.language == locale.language }
        val chosen = exact ?: sameLanguage ?: offline.firstOrNull()
        if (chosen == null) {
            _state.value = _state.value.copy(
                ready = false,
                error = "No offline TTS voice is installed on this device"
            )
            return
        }
        runCatching { engine.voice = chosen }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                if (utteranceId == activeId) _state.value = _state.value.copy(synthesizing = true, error = null)
            }
            override fun onDone(utteranceId: String?) {
                if (utteranceId != activeId) return
                val file = activeFile ?: return
                main.post { playSynthesized(file) }
            }
            @Deprecated("Deprecated by Android")
            override fun onError(utteranceId: String?) {
                if (utteranceId == activeId) _state.value = _state.value.copy(synthesizing = false, speaking = false, error = "Speech synthesis failed")
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                if (utteranceId == activeId) _state.value = _state.value.copy(synthesizing = false, speaking = false, error = "Speech synthesis failed ($errorCode)")
            }
        })
        _state.value = _state.value.copy(ready = true, voiceName = chosen.name, error = null)
    }

    fun setActionPhrase(action: Int, text: String) {
        val clean = text.trim().take(160)
        if (action == 0) actionPhrase0 = clean else actionPhrase1 = clean
        prefs.edit().putString(if (action == 0) "action_phrase_0" else "action_phrase_1", clean).apply()
    }

    fun speakAction(action: Int) {
        when (action) {
            0 -> speak(actionPhrase0)
            1 -> speak(actionPhrase1)
        }
    }

    fun speak(text: String) {
        val engine = tts ?: return
        val clean = text.trim().take(500)
        if (clean.isEmpty()) return
        if (!_state.value.ready) {
            _state.value = _state.value.copy(error = "Install or enable an offline Android TTS voice first")
            return
        }
        stopPlayback()
        cleanupAudioFiles()
        runCatching { engine.setPitch(mimic.ttsPitchMultiplier()) }
        runCatching { engine.setSpeechRate(1.0f) }
        val id = "wb-${UUID.randomUUID()}"
        val file = File(context.cacheDir, "$id.wav")
        activeId = id
        activeFile = file
        _state.value = _state.value.copy(
            synthesizing = true,
            speaking = false,
            progress = 0f,
            currentText = clean,
            waveform = emptyList(),
            error = null,
        )
        val result = engine.synthesizeToFile(clean, Bundle(), file, id)
        if (result == TextToSpeech.ERROR) {
            _state.value = _state.value.copy(synthesizing = false, error = "Speech engine rejected the utterance")
        }
    }

    fun stop() {
        runCatching { tts?.stop() }
        stopPlayback()
        _state.value = _state.value.copy(synthesizing = false, speaking = false, progress = 0f)
    }

    private fun stopPlayback() {
        main.removeCallbacks(progressTicker)
        player?.let { runCatching { it.stop() }; runCatching { it.release() } }
        player = null
    }

    private fun playSynthesized(file: File) {
        val localFile = mimic.processSynthesized(file)
        processedFile = if (localFile.absolutePath != file.absolutePath) localFile else null
        val wave = extractWaveform(localFile, 256)
        stopPlayback()
        val mp = MediaPlayer()
        player = mp
        runCatching {
            mp.setDataSource(localFile.absolutePath)
            mp.setOnCompletionListener {
                main.removeCallbacks(progressTicker)
                _state.value = _state.value.copy(synthesizing = false, speaking = false, progress = 1f)
                runCatching { it.release() }
                if (player === it) player = null
                cleanupAudioFiles()
            }
            mp.setOnErrorListener { m, what, extra ->
                _state.value = _state.value.copy(synthesizing = false, speaking = false, error = "Audio playback failed ($what/$extra)")
                runCatching { m.release() }
                if (player === m) player = null
                true
            }
            mp.prepare()
            _state.value = _state.value.copy(synthesizing = false, speaking = true, waveform = wave, progress = 0f)
            mp.start()
            main.post(progressTicker)
        }.onFailure {
            runCatching { mp.release() }
            player = null
            _state.value = _state.value.copy(synthesizing = false, speaking = false, error = "Cannot play synthesized speech: ${it.message}")
        }
    }

    /** Extract a normalized envelope from a WAV/PCM file. If an engine writes another
     * local audio container, a byte-energy fallback still gives a truthful visualization
     * of the synthesized file rather than a decorative animation. */
    private fun extractWaveform(file: File, bins: Int): List<Float> {
        val bytes = runCatching { file.readBytes() }.getOrElse { return emptyList() }
        if (bytes.isEmpty() || bins <= 0) return emptyList()
        val samples = ArrayList<Float>()
        if (bytes.size > 44 && String(bytes.copyOfRange(0, 4)) == "RIFF" && String(bytes.copyOfRange(8, 12)) == "WAVE") {
            var dataOffset = 12
            while (dataOffset + 8 <= bytes.size) {
                val id = String(bytes.copyOfRange(dataOffset, dataOffset + 4))
                val size = ByteBuffer.wrap(bytes, dataOffset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                val payload = dataOffset + 8
                if (id == "data" && size > 1) {
                    val end = (payload + size).coerceAtMost(bytes.size)
                    var i = payload
                    while (i + 1 < end) {
                        val v = ((bytes[i].toInt() and 0xff) or (bytes[i + 1].toInt() shl 8)).toShort().toInt()
                        samples += abs(v) / 32768f
                        i += 2
                    }
                    break
                }
                dataOffset = payload + max(0, size) + (size and 1)
            }
        }
        if (samples.isEmpty()) {
            val start = minOf(64, bytes.size)
            for (i in start until bytes.size) samples += abs(bytes[i].toInt()) / 128f
        }
        if (samples.isEmpty()) return emptyList()
        val out = FloatArray(bins)
        for (b in 0 until bins) {
            val a = (b.toLong() * samples.size / bins).toInt()
            val z = (((b + 1L) * samples.size / bins).toInt()).coerceAtLeast(a + 1).coerceAtMost(samples.size)
            var peak = 0f
            for (i in a until z) peak = max(peak, samples[i])
            out[b] = peak.coerceIn(0f, 1f)
        }
        return out.toList()
    }

    private fun cleanupAudioFiles() {
        processedFile?.let { runCatching { it.delete() } }
        processedFile = null
        activeFile?.let { runCatching { it.delete() } }
        activeFile = null
    }

    fun close() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
        cleanupAudioFiles()
        mimic.close()
    }
}
