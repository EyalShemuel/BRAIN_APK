package com.eyalshemuel.wholebrainmobile.brain

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.eyalshemuel.wholebrainmobile.R
import com.eyalshemuel.wholebrainmobile.WholeBrainApplication

class BrainForegroundService:Service(){
    private val channel="wholebrain-runtime"
    override fun onCreate(){
        super.onCreate()
        if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,getString(R.string.brain_service_channel),NotificationManager.IMPORTANCE_LOW))
        val notification=NotificationCompat.Builder(this,channel).setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle(getString(R.string.app_name)).setContentText(getString(R.string.brain_service_running)).setOngoing(true).build()
        if(Build.VERSION.SDK_INT>=34) startForeground(7001,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(7001,notification)
        (application as WholeBrainApplication).brainController.initialize()
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int)=START_STICKY
    override fun onBind(intent:Intent?):IBinder?=null
}
