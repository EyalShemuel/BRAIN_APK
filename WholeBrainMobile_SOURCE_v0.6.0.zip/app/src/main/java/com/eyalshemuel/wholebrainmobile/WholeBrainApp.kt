package com.eyalshemuel.wholebrainmobile

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.eyalshemuel.wholebrainmobile.brain.*
import com.eyalshemuel.wholebrainmobile.output.OutputRouter
import com.eyalshemuel.wholebrainmobile.output.SpeechOutputState
import com.eyalshemuel.wholebrainmobile.output.VoiceMimicState
import com.eyalshemuel.wholebrainmobile.sensors.CapabilityScanner
import com.eyalshemuel.wholebrainmobile.sensors.SensorHub
import java.text.DecimalFormat
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private enum class AppTab(val title:String,val icon:ImageVector){
    Live("Live",Icons.Rounded.Home),
    Teach("Teach",Icons.Rounded.School),
    Memory("Memory",Icons.Rounded.Memory),
    System("System",Icons.Rounded.Settings)
}
private enum class SystemPage{Brain,Device}
private enum class LiveSubview{Main,Neural,Speech}

private val regionNames=listOf(
    "Visual","Auditory","Language","Somatosensory","Association","Hippocampus","PFC",
    "Basal ganglia","Thalamus","Cerebellum","Motor","Vocal motor","Semantic","Neuromod","Brainstem"
)

@Composable
fun WholeBrainApp(
    controller:BrainController,
    sensorHub:SensorHub,
    output:OutputRouter,
    permissionEpoch:Int,
    onRequestPermissions:()->Unit
){
    val ui by controller.state.collectAsStateWithLifecycle()
    var tab by remember{mutableStateOf(AppTab.Live)}
    var liveSubview by remember{mutableStateOf(LiveSubview.Main)}
    val lifecycle=LocalLifecycleOwner.current
    val context=LocalContext.current

    LaunchedEffect(ui.stats.actionEpoch,ui.stats.currentAction,ui.stats.mode){
        if(ui.stats.mode==BrainMode.Act) output.route(ui.stats.currentAction)
    }

    Scaffold(
        containerColor=MaterialTheme.colorScheme.background,
        topBar={PremiumTopBar(ui,controller)},
        bottomBar={
            NavigationBar(
                tonalElevation=0.dp,
                containerColor=MaterialTheme.colorScheme.surface
            ){
                AppTab.entries.forEach{t->
                    NavigationBarItem(
                        selected=tab==t,
                        onClick={tab=t;if(t!=AppTab.Live)liveSubview=LiveSubview.Main},
                        icon={Icon(t.icon,contentDescription=t.title)},
                        label={Text(t.title)},
                        alwaysShowLabel=true
                    )
                }
            }
        }
    ){pad->
        Box(Modifier.padding(pad).fillMaxSize()){
            when(tab){
                AppTab.Live->when(liveSubview){
                    LiveSubview.Main->LiveScreen(ui,controller,sensorHub,lifecycle,permissionEpoch,onRequestPermissions,onOpenNeural={liveSubview=LiveSubview.Neural},onOpenSpeech={liveSubview=LiveSubview.Speech})
                    LiveSubview.Neural->NeuralScreen(controller,onBack={liveSubview=LiveSubview.Main})
                    LiveSubview.Speech->SpeechScreen(ui,output,sensorHub,onBack={liveSubview=LiveSubview.Main})
                }
                AppTab.Teach->TeachScreen(ui,controller)
                AppTab.Memory->MemoryScreen(ui,controller)
                AppTab.System->SystemScreen(ui,controller,output,context,permissionEpoch,onRequestPermissions)
            }
        }
    }
}

@Composable
private fun PremiumTopBar(ui:BrainUiState,controller:BrainController){
    Surface(color=MaterialTheme.colorScheme.surface,shadowElevation=1.dp){
        Row(
            Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars).padding(horizontal=18.dp,vertical=10.dp),
            verticalAlignment=Alignment.CenterVertically
        ){
            Column(Modifier.weight(1f)){
                Text(
                    "WholeBrain",
                    style=MaterialTheme.typography.titleLarge,
                    fontWeight=FontWeight.Bold,
                    color=MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
                    StatusDot(statusColor(ui))
                    Text(
                        compactStatusText(ui),
                        style=MaterialTheme.typography.labelMedium,
                        color=MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines=1,
                        overflow=TextOverflow.Ellipsis
                    )
                }
            }
            ModeMenu(ui.stats.mode,ui.running,controller)
        }
    }
}

@Composable
private fun ModeMenu(mode:BrainMode,running:Boolean,controller:BrainController){
    var expanded by remember{mutableStateOf(false)}
    Box{
        FilledTonalButton(
            onClick={expanded=true},
            contentPadding=PaddingValues(horizontal=14.dp,vertical=9.dp),
            shape=RoundedCornerShape(16.dp)
        ){
            Text(if(running)mode.name else "Offline",fontWeight=FontWeight.SemiBold)
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Rounded.KeyboardArrowDown,null,Modifier.size(18.dp))
        }
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
            BrainMode.entries.forEach{m->
                DropdownMenuItem(
                    text={
                        Column{
                            Text(m.name,fontWeight=if(m==mode)FontWeight.SemiBold else FontWeight.Normal)
                            Text(modeDescription(m),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    onClick={controller.setMode(m);expanded=false},
                    leadingIcon=if(m==mode){{Icon(Icons.Rounded.Check,null)}} else null
                )
            }
        }
    }
}

private fun modeDescription(m:BrainMode)=when(m){
    BrainMode.Observe->"Sense without changing learned output"
    BrainMode.Learn->"Accept feedback and adapt output"
    BrainMode.Act->"Allow learned motor output"
    BrainMode.Sleep->"Low-interaction consolidation mode"
}

private fun compactStatusText(ui:BrainUiState)=when{
    ui.calibrating->"Calibrating this device"
    ui.error!=null->ui.error
    ui.thermalStatus>=3->"Thermal protection active"
    ui.running->{
        val k=if(ui.stats.neurons>0)ui.stats.logicalSynapses/ui.stats.neurons else 0
        "Engine ready · ${fmt(ui.stats.neurons)} neurons · K$k"
    }
    else->"Engine stopped"
}

@Composable
private fun statusColor(ui:BrainUiState)=when{
    ui.error!=null->MaterialTheme.colorScheme.error
    ui.thermalStatus>=3->MaterialTheme.colorScheme.tertiary
    ui.running&&!ui.calibrating->MaterialTheme.colorScheme.primary
    else->MaterialTheme.colorScheme.outline
}

@Composable private fun StatusDot(color:Color){Box(Modifier.size(8.dp).clip(CircleShape).background(color))}

@Composable
private fun LiveScreen(
    ui:BrainUiState,
    controller:BrainController,
    sensors:SensorHub,
    lifecycle:LifecycleOwner,
    permissionEpoch:Int,
    onRequestPermissions:()->Unit,
    onOpenNeural:()->Unit,
    onOpenSpeech:()->Unit
){
    val context=LocalContext.current
    val hasCamera=remember(permissionEpoch){ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED}
    var showAdvanced by remember{mutableStateOf(false)}
    var showAllSenses by remember{mutableStateOf(false)}

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding=PaddingValues(horizontal=16.dp,vertical=16.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp)
    ){
        item{InputProfileCard(ui.sensorMode,controller)}
        item{ActivityHero(ui.stats,onOpenNeural,onOpenSpeech)}
        item{CompactMetrics(ui.stats)}

        item{SectionHeader("Senses","What is reaching the brain right now")}
        item{
            SenseGrid(
                stats=ui.stats,
                showAll=showAllSenses,
                onToggleAll={showAllSenses=!showAllSenses}
            )
        }

        if(ui.sensorMode==SensorMode.TouchOnly||ui.sensorMode==SensorMode.AllSensors){
            item{TouchSurface(controller)}
        }

        if(ui.sensorMode==SensorMode.VisionOnly||ui.sensorMode==SensorMode.AllSensors){
            item{SectionHeader("Vision preview","The camera runs independently from this preview")}
            item{
                if(hasCamera){
                    key(permissionEpoch){
                        Box(
                            Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                        ){
                            AndroidView(
                                factory={ctx->PreviewView(ctx).apply{scaleType=PreviewView.ScaleType.FILL_CENTER;sensors.bindCamera(lifecycle,this)}},
                                modifier=Modifier.fillMaxSize()
                            )
                            Surface(
                                modifier=Modifier.align(Alignment.TopStart).padding(12.dp),
                                shape=RoundedCornerShape(999.dp),
                                color=MaterialTheme.colorScheme.surface.copy(alpha=.88f)
                            ){
                                Row(Modifier.padding(horizontal=10.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
                                    StatusDot(if(ui.stats.cameraFramesPerSecond>0)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                                    Text("${fmt(ui.stats.cameraFramesPerSecond)} fps",style=MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }else{
                    PermissionPrompt(
                        title="Camera access is off",
                        body="Enable camera access to let the visual pathway receive real frames.",
                        action="Enable senses",
                        onClick=onRequestPermissions
                    )
                }
            }
        }

        item{
            OutlinedButton(
                onClick={showAdvanced=!showAdvanced},
                modifier=Modifier.fillMaxWidth(),
                shape=RoundedCornerShape(18.dp)
            ){
                Icon(if(showAdvanced)Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,null)
                Spacer(Modifier.width(8.dp))
                Text(if(showAdvanced)"Hide technical diagnostics" else "Show technical diagnostics")
            }
        }
        item{
            AnimatedVisibility(showAdvanced){SensorDiagnostics(ui.stats)}
        }
        item{Spacer(Modifier.height(4.dp))}
    }
}

@Composable
private fun InputProfileCard(mode:SensorMode,controller:BrainController){
    var expanded by remember{mutableStateOf(false)}
    PremiumCard{
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text("Input profile",style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Text(modeFriendlyName(mode),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold)
            }
            Box{
                OutlinedButton(onClick={expanded=true},shape=RoundedCornerShape(16.dp)){
                    Text("Change")
                    Icon(Icons.Rounded.KeyboardArrowDown,null,Modifier.size(18.dp))
                }
                DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
                    SensorMode.entries.forEach{m->
                        DropdownMenuItem(
                            text={Text(modeFriendlyName(m))},
                            onClick={controller.setSensorMode(m);expanded=false},
                            leadingIcon=if(m==mode){{Icon(Icons.Rounded.Check,null)}} else null
                        )
                    }
                }
            }
        }
    }
}

private fun modeFriendlyName(mode:SensorMode)=when(mode){
    SensorMode.AllSensors->"All senses"
    SensorMode.VisionOnly->"Vision only"
    SensorMode.AudioOnly->"Audio only"
    SensorMode.TouchOnly->"Touch only"
    SensorMode.ImuOnly->"Motion only"
    SensorMode.EnvironmentOnly->"Environment only"
    SensorMode.LocationOnly->"Location only"
    SensorMode.ExternalOnly->"External devices only"
}

@Composable
private fun ActivityHero(stats:BrainStats,onOpenNeural:()->Unit,onOpenSpeech:()->Unit){
    val p=MaterialTheme.colorScheme.primary
    val s=MaterialTheme.colorScheme.secondary
    val maxRate=(stats.regionSpikesPerSecond.maxOrNull()?:0.0).coerceAtLeast(1.0)
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(
            Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer,MaterialTheme.colorScheme.secondaryContainer.copy(alpha=.72f)))
        ).padding(20.dp)
    ){
        Column{
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("Brain activity",style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha=.72f))
                    Text("${fmt(stats.spikesPerSecond)}/s",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("spikes across 15 regions",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha=.72f))
                }
                Canvas(Modifier.size(128.dp)){
                    val c=center
                    val r=size.minDimension*.35f
                    for(i in 0 until 15){
                        val a=2*PI*i/15.0
                        val pos=Offset(c.x+(cos(a)*r).toFloat(),c.y+(sin(a)*r).toFloat())
                        val rate=stats.regionSpikesPerSecond.getOrElse(i){0.0}
                        val active=sqrt((rate/maxRate).coerceIn(0.0,1.0)).toFloat()
                        drawCircle(if(i%2==0)p else s,radius=3.5f+9f*active,center=pos,alpha=.22f+.78f*active)
                    }
                    drawCircle(p,radius=19f,center=c,alpha=.16f)
                    drawCircle(p,radius=5.5f,center=c,alpha=if(stats.spikesLastStep>0).95f else .3f)
                }
            }
            Spacer(Modifier.height(14.dp))
            Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.surface.copy(alpha=.62f)){
                Row(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Rounded.CheckCircle,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if(stats.currentAction<0)"Regional activity is live" else "Motor action ${stats.currentAction+1} selected",
                        style=MaterialTheme.typography.labelLarge,
                        color=MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                FilledTonalButton(onClick=onOpenNeural,modifier=Modifier.weight(1f),shape=RoundedCornerShape(16.dp)){
                    Icon(Icons.Rounded.Hub,null,Modifier.size(18.dp));Spacer(Modifier.width(6.dp));Text("Neural view")
                }
                FilledTonalButton(onClick=onOpenSpeech,modifier=Modifier.weight(1f),shape=RoundedCornerShape(16.dp)){
                    Icon(Icons.Rounded.GraphicEq,null,Modifier.size(18.dp));Spacer(Modifier.width(6.dp));Text("Voice output")
                }
            }
        }
    }
}

@Composable
private fun CompactMetrics(s:BrainStats){
    LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(end=4.dp)){
        item{MiniMetric("Step",if(s.lastStepMs>0)"${df1.format(s.lastStepMs)} ms" else "—")}
        item{MiniMetric("Queue",fmt(s.queuedEvents))}
        item{MiniMetric("Edges/s",fmt(s.edgesPerSecond))}
        item{MiniMetric("Neurons",fmt(s.neurons))}
        item{MiniMetric("Synapses",fmt(s.logicalSynapses))}
    }
}

@Composable private fun MiniMetric(label:String,value:String){
    Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surface,tonalElevation=1.dp){
        Column(Modifier.widthIn(min=112.dp).padding(horizontal=14.dp,vertical=12.dp)){
            Text(value,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
            Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SenseGrid(stats:BrainStats,showAll:Boolean,onToggleAll:()->Unit){
    val primary=listOf(
        SenseCardData("Vision",Icons.Rounded.Visibility,stats.visionInjectionsPerSecond,"${fmt(stats.cameraFramesPerSecond)} fps camera",stats.cameraFramesPerSecond>0),
        SenseCardData("Audio",Icons.Rounded.VolumeUp,stats.audioInjectionsPerSecond,"${fmt(stats.audioChunksPerSecond)} chunks/s",stats.audioChunksPerSecond>0),
        SenseCardData("Touch",Icons.Rounded.TouchApp,stats.touchInjectionsPerSecond,"${fmt(stats.touchEventsPerSecond)} events/s",stats.touchEventsPerSecond>0),
        SenseCardData("Motion",Icons.Rounded.Explore,stats.imuInjectionsPerSecond,"${fmt(stats.imuChangesPerSecond)} changes/s",stats.imuChangesPerSecond>0)
    )
    val secondary=listOf(
        SenseCardData("Environment",Icons.Rounded.Thermostat,stats.environmentInjectionsPerSecond,"${fmt(stats.environmentChangesPerSecond)} changes/s",stats.environmentChangesPerSecond>0),
        SenseCardData("Location",Icons.Rounded.LocationOn,stats.locationInjectionsPerSecond,"${fmt(stats.locationEventsPerSecond)} updates/s",stats.locationEventsPerSecond>0),
        SenseCardData("External",Icons.Rounded.Usb,stats.externalInjectionsPerSecond,"${fmt(stats.externalTokensPerSecond)} tokens/s",stats.externalTokensPerSecond>0)
    )
    Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        primary.chunked(2).forEach{row->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                row.forEach{SenseTile(it,Modifier.weight(1f))}
            }
        }
        AnimatedVisibility(showAll){
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
                secondary.chunked(2).forEach{row->
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                        row.forEach{SenseTile(it,Modifier.weight(1f))}
                        if(row.size==1)Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        TextButton(onClick=onToggleAll,modifier=Modifier.align(Alignment.End)){
            Text(if(showAll)"Show less" else "Show all senses")
            Icon(if(showAll)Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,null)
        }
    }
}

private data class SenseCardData(val title:String,val icon:ImageVector,val injections:Double,val detail:String,val physicallyActive:Boolean)

@Composable private fun SenseTile(d:SenseCardData,modifier:Modifier=Modifier){
    val active=d.injections>0.2
    Surface(modifier,shape=RoundedCornerShape(22.dp),color=MaterialTheme.colorScheme.surface,tonalElevation=1.dp){
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Surface(shape=RoundedCornerShape(12.dp),color=if(active)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant){
                    Icon(d.icon,null,Modifier.padding(8.dp).size(20.dp),tint=if(active)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.weight(1f))
                StatusDot(if(active)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
            }
            Text(d.title,fontWeight=FontWeight.SemiBold)
            Text(if(active)"${fmt(d.injections)}/s injected" else if(d.physicallyActive)"Connected · quiet" else "Waiting",style=MaterialTheme.typography.labelLarge,color=if(active)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(d.detail,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1,overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun TouchSurface(controller:BrainController){
    var size by remember{mutableStateOf(IntSize.Zero)}
    var active by remember{mutableStateOf(false)}
    Surface(
        Modifier.fillMaxWidth().height(150.dp).onSizeChanged{size=it}.pointerInput(size){
            awaitPointerEventScope{
                while(true){
                    val event=awaitPointerEvent(PointerEventPass.Initial)
                    val change=event.changes.firstOrNull()?:continue
                    active=change.pressed
                    if(size.width>0&&size.height>0){
                        controller.injectTouch(
                            (change.position.x/size.width).coerceIn(0f,1f),
                            (change.position.y/size.height).coerceIn(0f,1f),
                            if(change.pressed)change.pressure.coerceIn(0.05f,1f) else 0f
                        )
                    }
                }
            }
        },
        shape=RoundedCornerShape(24.dp),
        color=if(active)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    ){
        Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
            Icon(Icons.Rounded.TouchApp,null,Modifier.size(28.dp),tint=MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(if(active)"Touch detected" else "Touch sensor pad",fontWeight=FontWeight.SemiBold)
            Text("Use this area to send position and pressure to the somatosensory map",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable private fun PermissionPrompt(title:String,body:String,action:String,onClick:()->Unit){
    Surface(shape=RoundedCornerShape(24.dp),color=MaterialTheme.colorScheme.errorContainer.copy(alpha=.42f)){
        Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
            Icon(Icons.Rounded.Warning,null,tint=MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){
                Text(title,fontWeight=FontWeight.SemiBold)
                Text(body,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick=onClick){Text(action)}
        }
    }
}

@Composable
private fun SensorDiagnostics(s:BrainStats){
    val visual=s.regionSpikesPerSecond.getOrElse(0){0.0}
    val auditory=s.regionSpikesPerSecond.getOrElse(1){0.0}
    val somato=s.regionSpikesPerSecond.getOrElse(3){0.0}
    val assoc=s.regionSpikesPerSecond.getOrElse(4){0.0}
    val hippoc=s.regionSpikesPerSecond.getOrElse(5){0.0}
    val pfc=s.regionSpikesPerSecond.getOrElse(6){0.0}
    val thalamus=s.regionSpikesPerSecond.getOrElse(8){0.0}
    val cerebellum=s.regionSpikesPerSecond.getOrElse(9){0.0}
    val motor=s.regionSpikesPerSecond.getOrElse(10){0.0}
    val semantic=s.regionSpikesPerSecond.getOrElse(12){0.0}
    val brainstem=s.regionSpikesPerSecond.getOrElse(14){0.0}
    PremiumCard{
        Column(verticalArrangement=Arrangement.spacedBy(11.dp)){
            Text("Technical diagnostics",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
            DiagnosticRow("Vision","camera ${fmt(s.cameraFramesPerSecond)}/s · retina ${fmt(s.visionFramesPerSecond)}/s","features ${fmt(s.visionFeaturesPerSecond)}/s · inject ${fmt(s.visionInjectionsPerSecond)}/s · Visual total ${fmt(visual)}/s")
            HorizontalDivider()
            DiagnosticRow("Audio","chunks ${fmt(s.audioChunksPerSecond)}/s · active bands ${fmt(s.audioBandsPerSecond)}/s","tonotopic inject ${fmt(s.audioInjectionsPerSecond)}/s · Auditory total ${fmt(auditory)}/s")
            HorizontalDivider()
            DiagnosticRow("Touch","events ${fmt(s.touchEventsPerSecond)}/s · somatotopic inject ${fmt(s.touchInjectionsPerSecond)}/s","S1 total ${fmt(somato)}/s")
            HorizontalDivider()
            DiagnosticRow("Motion / gyro","events ${fmt(s.imuEventsPerSecond)}/s · meaningful Δ ${fmt(s.imuChangesPerSecond)}/s","inject ${fmt(s.imuInjectionsPerSecond)}/s · S1 total ${fmt(somato)}/s · Cerebellum total ${fmt(cerebellum)}/s")
            HorizontalDivider()
            DiagnosticRow("Environment","events ${fmt(s.environmentEventsPerSecond)}/s · changes ${fmt(s.environmentChangesPerSecond)}/s","inject ${fmt(s.environmentInjectionsPerSecond)}/s · Thalamus ${fmt(thalamus)}/s · Brainstem ${fmt(brainstem)}/s")
            HorizontalDivider()
            DiagnosticRow("GPS / place","updates ${fmt(s.locationEventsPerSecond)}/s · inject ${fmt(s.locationInjectionsPerSecond)}/s","Hippocampus ${fmt(hippoc)}/s")
            HorizontalDivider()
            DiagnosticRow("External","tokens ${fmt(s.externalTokensPerSecond)}/s · inject ${fmt(s.externalInjectionsPerSecond)}/s","Semantic ${fmt(semantic)}/s · Association ${fmt(assoc)}/s")
            HorizontalDivider()
            DiagnosticRow("Propagation","Association ${fmt(assoc)}/s · PFC ${fmt(pfc)}/s","Motor ${fmt(motor)}/s · total ${fmt(s.spikesPerSecond)}/s")
        }
    }
}

@Composable private fun DiagnosticRow(title:String,line1:String,line2:String){
    Column(verticalArrangement=Arrangement.spacedBy(3.dp)){
        Text(title,fontWeight=FontWeight.SemiBold)
        Text(line1,style=MaterialTheme.typography.bodySmall)
        Text(line2,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TeachScreen(ui:BrainUiState,controller:BrainController){
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding=PaddingValues(16.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp)
    ){
        item{SectionHeader("Teach","Reward the consequence, not a hidden label")}
        item{
            PremiumCard{
                Row(verticalAlignment=Alignment.CenterVertically){
                    Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.primaryContainer){
                        Icon(Icons.Rounded.School,null,Modifier.padding(10.dp).size(24.dp),tint=MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text(if(ui.stats.currentAction<0)"Waiting for a decision" else "Action ${ui.stats.currentAction+1}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                        Text(
                            if(ui.stats.currentAction<0)"Switch to Act when you want the learned output to choose." else "Was this consequence good or bad?",
                            color=MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        if(ui.stats.mode!=BrainMode.Learn){
            item{
                Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.secondaryContainer.copy(alpha=.55f)){
                    Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text("Learning mode is off",fontWeight=FontWeight.SemiBold)
                            Text("Enable Learn before giving feedback.",style=MaterialTheme.typography.bodySmall)
                        }
                        FilledTonalButton(onClick={controller.setMode(BrainMode.Learn)}){Text("Enable Learn")}
                    }
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){
                Button(
                    onClick={controller.reward(true)},
                    enabled=ui.stats.currentAction>=0&&ui.stats.mode==BrainMode.Learn,
                    modifier=Modifier.weight(1f).height(68.dp),
                    shape=RoundedCornerShape(22.dp)
                ){
                    Icon(Icons.Rounded.Check,null)
                    Spacer(Modifier.width(8.dp))
                    Text("Good",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                }
                Button(
                    onClick={controller.reward(false)},
                    enabled=ui.stats.currentAction>=0&&ui.stats.mode==BrainMode.Learn,
                    modifier=Modifier.weight(1f).height(68.dp),
                    shape=RoundedCornerShape(22.dp),
                    colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)
                ){
                    Icon(Icons.Rounded.Close,null)
                    Spacer(Modifier.width(8.dp))
                    Text("Wrong",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                StatCard("Feedback",ui.stats.reinforcedEpisodes.toString(),Modifier.weight(1f))
                StatCard("Output Δ",df3.format(ui.stats.motorDifferential),Modifier.weight(1f))
            }
        }
        item{
            PremiumCard{
                Text("How learning is bounded",fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Feedback changes only the validated plastic Association→Motor output path. The recurrent procedural substrate remains fixed.",
                    style=MaterialTheme.typography.bodyMedium,
                    color=MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun MemoryScreen(ui:BrainUiState,controller:BrainController){
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding=PaddingValues(16.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp)
    ){
        item{SectionHeader("Memory","Save, restore, and inspect learned state")}
        item{
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(
                    Brush.linearGradient(listOf(MaterialTheme.colorScheme.secondaryContainer,MaterialTheme.colorScheme.surface))
                ).padding(20.dp)
            ){
                Column{
                    Text("Plastic state",style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Text("${ui.stats.reinforcedEpisodes}",style=MaterialTheme.typography.displaySmall,fontWeight=FontWeight.Bold)
                    Text("reinforced feedback episodes",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    Text("Differential output · ${df3.format(ui.stats.motorDifferential)}",fontWeight=FontWeight.SemiBold)
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){
                Button(onClick={controller.saveAsync()},modifier=Modifier.weight(1f).height(56.dp),shape=RoundedCornerShape(18.dp)){
                    Icon(Icons.Rounded.Save,null);Spacer(Modifier.width(8.dp));Text("Save brain")
                }
                OutlinedButton(onClick={controller.loadNow()},modifier=Modifier.weight(1f).height(56.dp),shape=RoundedCornerShape(18.dp)){
                    Icon(Icons.Rounded.Restore,null);Spacer(Modifier.width(8.dp));Text("Restore")
                }
            }
        }
        item{
            PremiumCard{
                Text("What this number means",fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Feedback episodes are actual plastic updates, not a claim about the number of independent memories the network can store.",
                    style=MaterialTheme.typography.bodyMedium,
                    color=MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SystemScreen(
    ui:BrainUiState,
    controller:BrainController,
    output:OutputRouter,
    context:Context,
    permissionEpoch:Int,
    onRequestPermissions:()->Unit
){
    var page by remember{mutableStateOf(SystemPage.Brain)}
    Column(Modifier.fillMaxSize()){
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            FilterChip(selected=page==SystemPage.Brain,onClick={page=SystemPage.Brain},label={Text("Brain")},leadingIcon=if(page==SystemPage.Brain){{Icon(Icons.Rounded.Check,null,Modifier.size(18.dp))}}else null,modifier=Modifier.weight(1f))
            FilterChip(selected=page==SystemPage.Device,onClick={page=SystemPage.Device},label={Text("Device")},leadingIcon=if(page==SystemPage.Device){{Icon(Icons.Rounded.Check,null,Modifier.size(18.dp))}}else null,modifier=Modifier.weight(1f))
        }
        when(page){
            SystemPage.Brain->BrainScreen(ui)
            SystemPage.Device->DeviceScreen(ui,controller,output,context,permissionEpoch,onRequestPermissions)
        }
    }
}

@Composable
private fun BrainScreen(ui:BrainUiState){
    val k=if(ui.stats.neurons>0)ui.stats.logicalSynapses/ui.stats.neurons else 0
    val maxRate=(ui.stats.regionSpikesPerSecond.maxOrNull()?:0.0).coerceAtLeast(1.0)
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(horizontal=16.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{SectionHeader("Brain","Runtime substrate and regional activity")}
        item{
            PremiumCard{
                Text("Runtime",style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text("${fmt(ui.stats.neurons)} neurons · K$k",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                Text("${fmt(ui.stats.logicalSynapses)} logical connections",color=MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.tertiaryContainer.copy(alpha=.5f)){
                    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Rounded.Info,null,tint=MaterialTheme.colorScheme.tertiary)
                        Spacer(Modifier.width(10.dp))
                        Text("Scientific mechanism validated at K6 · current K$k is an engineering runtime scale",style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item{SectionHeader("Regions","Measured spikes per second")}
        itemsIndexed(regionNames){i,r->
            RegionRow(r,ui.stats.regionSpikesPerSecond.getOrElse(i){0.0},maxRate)
        }
        item{Spacer(Modifier.height(8.dp))}
    }
}

@Composable private fun RegionRow(name:String,rate:Double,maxRate:Double){
    val target=(rate/maxRate).coerceIn(0.0,1.0).toFloat()
    val progress by animateFloatAsState(target,label="region")
    Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surface,tonalElevation=1.dp){
        Column(Modifier.padding(horizontal=14.dp,vertical=12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Text(name,Modifier.weight(1f),fontWeight=FontWeight.Medium)
                Text("${fmt(rate)}/s",style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth().height(5.dp).clip(CircleShape))
        }
    }
}

@Composable
private fun DeviceScreen(
    ui:BrainUiState,
    controller:BrainController,
    output:OutputRouter,
    context:Context,
    permissionEpoch:Int,
    onRequestPermissions:()->Unit
){
    val caps=remember(permissionEpoch){CapabilityScanner(context).scan()}
    var haptic by remember{mutableStateOf(output.hapticsEnabled)}
    var sound by remember{mutableStateOf(output.soundEnabled)}
    var torch by remember{mutableStateOf(output.torchEnabled)}
    var notices by remember{mutableStateOf(output.notificationsEnabled)}
    var showHardware by remember{mutableStateOf(false)}

    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(horizontal=16.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{SectionHeader("Device","Permissions, scale, outputs, and hardware")}
        item{
            PremiumCard{
                Row(verticalAlignment=Alignment.CenterVertically){
                    Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.primaryContainer){Icon(Icons.Rounded.CheckCircle,null,Modifier.padding(9.dp),tint=MaterialTheme.colorScheme.primary)}
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Sensor permissions",fontWeight=FontWeight.SemiBold)
                        Text("Enable optional camera, microphone, location, Bluetooth and notification access.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    FilledTonalButton(onClick=onRequestPermissions){Text("Enable")}
                }
            }
        }
        item{SectionHeader("Scale","Choose an engineering runtime profile")}
        item{
            PremiumCard{
                ScaleChoice(
                    title="Balanced",
                    subtitle="${fmt(ui.recommendation.balancedNeurons)} neurons · K${ui.recommendation.balancedFanout}",
                    selected=ui.profile==ScaleProfile.Balanced,
                    onClick={controller.rebuild(ScaleProfile.Balanced)}
                )
                HorizontalDivider(Modifier.padding(vertical=12.dp))
                ScaleChoice(
                    title="Max",
                    subtitle="${fmt(ui.recommendation.maxNeurons)} neurons · K${ui.recommendation.maxFanout}",
                    selected=ui.profile==ScaleProfile.Max,
                    onClick={controller.rebuild(ScaleProfile.Max)}
                )
                Spacer(Modifier.height(10.dp))
                Text("Runtime scale changes execution size, not the scientific validation boundary.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item{SectionHeader("Outputs","What the brain is allowed to control")}
        item{OutputToggle("Haptics",Icons.Rounded.Vibration,haptic){haptic=it;output.hapticsEnabled=it}}
        item{OutputToggle("Sound",Icons.Rounded.VolumeUp,sound){sound=it;output.soundEnabled=it}}
        item{OutputToggle("Torch",Icons.Rounded.FlashOn,torch){torch=it;output.torchEnabled=it}}
        item{OutputToggle("Notifications",Icons.Rounded.Notifications,notices){notices=it;output.notificationsEnabled=it}}
        item{
            OutlinedButton(
                onClick={ContextCompat.startForegroundService(context,Intent(context,BrainForegroundService::class.java))},
                modifier=Modifier.fillMaxWidth().height(54.dp),
                shape=RoundedCornerShape(18.dp)
            ){Text("Keep brain running in background")}
        }
        item{
            TextButton(onClick={showHardware=!showHardware},modifier=Modifier.fillMaxWidth()){
                Text(if(showHardware)"Hide hardware details" else "Show hardware details")
                Icon(if(showHardware)Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,null)
            }
        }
        item{
            AnimatedVisibility(showHardware){
                Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
                    caps.forEach{c->
                        Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surface){
                            Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                                StatusDot(if(c.available)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){
                                    Text(c.name,fontWeight=FontWeight.Medium)
                                    Text(c.detail,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1,overflow=TextOverflow.Ellipsis)
                                }
                                Text(if(c.available)"Ready" else "Unavailable",style=MaterialTheme.typography.labelMedium,color=if(c.available)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        item{Spacer(Modifier.height(8.dp))}
    }
}

@Composable private fun ScaleChoice(title:String,subtitle:String,selected:Boolean,onClick:()->Unit){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
        Column(Modifier.weight(1f)){
            Text(title,fontWeight=FontWeight.SemiBold)
            Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if(selected){AssistChip(onClick={},label={Text("Active")},leadingIcon={Icon(Icons.Rounded.Check,null,Modifier.size(16.dp))})}
        else OutlinedButton(onClick=onClick,shape=RoundedCornerShape(14.dp)){Text("Apply")}
    }
}

@Composable private fun OutputToggle(label:String,icon:ImageVector,checked:Boolean,onChange:(Boolean)->Unit){
    Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surface,tonalElevation=1.dp){
        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
            Icon(icon,null,tint=MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text(label,Modifier.weight(1f),fontWeight=FontWeight.Medium)
            Switch(checked=checked,onCheckedChange=onChange)
        }
    }
}

@Composable private fun PremiumCard(content:@Composable ColumnScope.()->Unit){
    Surface(shape=RoundedCornerShape(24.dp),color=MaterialTheme.colorScheme.surface,tonalElevation=1.dp){
        Column(Modifier.fillMaxWidth().padding(16.dp),content=content)
    }
}

@Composable private fun StatCard(label:String,value:String,modifier:Modifier=Modifier){
    Surface(modifier,shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surface,tonalElevation=1.dp){
        Column(Modifier.padding(16.dp)){
            Text(value,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable private fun SectionHeader(title:String,subtitle:String?=null){
    Column(Modifier.fillMaxWidth()){
        Text(title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        if(subtitle!=null)Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


private val neuralRegionWeights=intArrayOf(35,24,47,18,59,30,35,18,12,29,12,6,18,6,6)
private const val neuralRegionWeightSum=355

private fun neuralRegionBounds(region:Int,total:Int):IntRange{
    if(total<=0)return 0 until 0
    val before=neuralRegionWeights.take(region).sum()
    val through=before+neuralRegionWeights.getOrElse(region){0}
    val start=(total.toLong()*before/neuralRegionWeightSum).toInt()
    val endExclusive=if(region==14)total else (total.toLong()*through/neuralRegionWeightSum).toInt()
    return start until endExclusive.coerceAtLeast(start+1)
}

private fun neuralRegionOf(neuron:Int,total:Int):Int{
    if(total<=0)return 14
    for(r in 0..14)if(neuron<neuralRegionBounds(r,total).last+1)return r
    return 14
}

private fun DrawScope.neuronPosition(neuron:Int,total:Int):Offset{
    val region=neuralRegionOf(neuron,total)
    val bounds=neuralRegionBounds(region,total)
    val local=(neuron-bounds.first).coerceAtLeast(0)
    val count=bounds.count().coerceAtLeast(1)
    val col=region%5
    val row=region/5
    val cellW=size.width/5f
    val cellH=size.height/3f
    val cx=(col+.5f)*cellW
    val cy=(row+.5f)*cellH
    val angle=local*2.399963229728653
    val frac=sqrt((local+0.5)/count.toDouble()).toFloat()
    val radius=minOf(cellW,cellH)*.40f*frac
    return Offset(cx+(cos(angle)*radius).toFloat(),cy+(sin(angle)*radius).toFloat())
}

@Composable
private fun NeuralScreen(controller:BrainController,onBack:()->Unit){
    val trace by controller.trace.collectAsStateWithLifecycle()
    var selectedRegion by remember{mutableIntStateOf(-1)}
    var historyBack by remember{mutableIntStateOf(0)}
    var regionMenu by remember{mutableStateOf(false)}
    DisposableEffect(Unit){controller.setTraceEnabled(true);onDispose{controller.setTraceEnabled(false)}}
    LaunchedEffect(historyBack){controller.setTraceHistoryBack(historyBack)}

    val filteredEdges=remember(trace.tick,trace.historyBack,selectedRegion){
        if(selectedRegion<0)trace.edges else trace.edges.filter{
            neuralRegionOf(it.source,trace.totalNeurons)==selectedRegion||neuralRegionOf(it.target,trace.totalNeurons)==selectedRegion
        }
    }
    val filteredFired=remember(trace.tick,trace.historyBack,selectedRegion){
        if(selectedRegion<0)trace.fired else trace.fired.filter{neuralRegionOf(it,trace.totalNeurons)==selectedRegion}
    }
    LazyColumn(
        Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)
    ){
        item{SubscreenHeader("Neural view","Exact active subgraph · 1:1 event data",onBack)}
        item{
            PremiumCard{
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text("Step ${trace.tick}",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                        Text("${fmt(filteredFired.size.toLong())} fired neurons · ${fmt(filteredEdges.size.toLong())} recurrent edges",color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box{
                        OutlinedButton(onClick={regionMenu=true},shape=RoundedCornerShape(14.dp)){
                            Text(if(selectedRegion<0)"All regions" else regionNames[selectedRegion])
                            Icon(Icons.Rounded.KeyboardArrowDown,null,Modifier.size(18.dp))
                        }
                        DropdownMenu(expanded=regionMenu,onDismissRequest={regionMenu=false}){
                            DropdownMenuItem(text={Text("All regions")},onClick={selectedRegion=-1;regionMenu=false})
                            regionNames.forEachIndexed{i,n->DropdownMenuItem(text={Text(n)},onClick={selectedRegion=i;regionMenu=false})}
                        }
                    }
                }
            }
        }
        item{
            val exc=MaterialTheme.colorScheme.primary
            val inh=MaterialTheme.colorScheme.error
            val node=MaterialTheme.colorScheme.onSurface
            val regionLabel=MaterialTheme.colorScheme.onSurfaceVariant
            Surface(shape=RoundedCornerShape(28.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)){
                Box(Modifier.fillMaxWidth().height(430.dp).padding(8.dp)){
                    Canvas(Modifier.fillMaxSize()){
                        // Region names are always spatially fixed. Every neuron ID maps to one stable point.
                        for(r in 0..14){
                            val col=r%5;val row=r/5
                            drawCircle(regionLabel,2.5f,Offset((col+.5f)*size.width/5f,(row+.5f)*size.height/3f),alpha=.35f)
                        }
                        val excPath=Path();val inhPath=Path()
                        filteredEdges.forEach{e->
                            val a=neuronPosition(e.source,trace.totalNeurons)
                            val b=neuronPosition(e.target,trace.totalNeurons)
                            val path=if(e.excitatory)excPath else inhPath
                            path.moveTo(a.x,a.y);path.lineTo(b.x,b.y)
                        }
                        drawPath(excPath,exc,alpha=.13f,style=androidx.compose.ui.graphics.drawscope.Stroke(width=.7f))
                        drawPath(inhPath,inh,alpha=.16f,style=androidx.compose.ui.graphics.drawscope.Stroke(width=.8f))
                        filteredFired.forEach{id->drawCircle(node,2.6f,neuronPosition(id,trace.totalNeurons),alpha=.95f)}
                    }
                    Column(Modifier.align(Alignment.BottomStart).padding(12.dp)){
                        Surface(shape=RoundedCornerShape(999.dp),color=MaterialTheme.colorScheme.surface.copy(alpha=.90f)){
                            Row(Modifier.padding(horizontal=10.dp,vertical=6.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                                Text("● spike",style=MaterialTheme.typography.labelSmall)
                                Text("— excitatory",style=MaterialTheme.typography.labelSmall,color=exc)
                                Text("— inhibitory",style=MaterialTheme.typography.labelSmall,color=inh)
                            }
                        }
                    }
                }
            }
        }
        item{
            PremiumCard{
                Text("Step history",fontWeight=FontWeight.SemiBold)
                Text("Inspect one of the exact simulation steps still held by the native trace buffer.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                val maxBack=(trace.historyDepth-1).coerceAtLeast(0)
                Slider(value=historyBack.coerceAtMost(maxBack).toFloat(),onValueChange={historyBack=it.toInt()},valueRange=0f..maxBack.coerceAtLeast(1).toFloat(),steps=(maxBack-1).coerceAtLeast(0))
                Text(if(historyBack==0)"Latest step" else "$historyBack steps back",style=MaterialTheme.typography.labelLarge)
            }
        }
        item{
            PremiumCard{
                Text("What 1:1 means here",fontWeight=FontWeight.SemiBold)
                Text("Every dot is an actual neuron ID that fired in the selected timestep. Every line is an actual recurrent edge scheduled by that spike. Nothing in this view is a decorative activity animation.",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SpeechScreen(ui:BrainUiState,output:OutputRouter,sensorHub:SensorHub,onBack:()->Unit){
    val speech by output.speech.state.collectAsStateWithLifecycle()
    val mimic by output.speech.mimic.state.collectAsStateWithLifecycle()
    var text by remember{mutableStateOf("WholeBrain voice output is online")}
    var phrase0 by remember{mutableStateOf(output.speech.actionPhrase0)}
    var phrase1 by remember{mutableStateOf(output.speech.actionPhrase1)}
    var speechEnabled by remember{mutableStateOf(output.speechEnabled)}
    var consentConfirmed by remember{mutableStateOf(false)}
    val vocalRate=ui.stats.regionSpikesPerSecond.getOrElse(11){0.0}
    DisposableEffect(Unit){
        onDispose{
            if(output.speech.mimic.state.value.recording){
                output.speech.mimic.stopEnrollment()
                sensorHub.resumeBrainAudioAfterVoiceEnrollment()
            }
        }
    }
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{SubscreenHeader("Voice output","Offline speech actuator + real audio visualization",onBack)}
        item{
            PremiumCard{
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                    Surface(shape=RoundedCornerShape(16.dp),color=if(speech.ready)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer){
                        Icon(Icons.Rounded.RecordVoiceOver,null,Modifier.padding(11.dp).size(24.dp),tint=if(speech.ready)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text(if(speech.ready)"Offline voice ready" else "Offline voice unavailable",fontWeight=FontWeight.Bold)
                        Text(speech.voiceName.ifBlank{speech.error?:"Install an offline Android TTS voice"},style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=2)
                    }
                    Switch(checked=speechEnabled,onCheckedChange={speechEnabled=it;output.speechEnabled=it})
                }
                Text("When enabled, learned motor Action 1/2 can speak the phrases configured below. The app has no INTERNET permission.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item{VoiceMimicCard(mimic,consentConfirmed,{consentConfirmed=it},
            onStart={
                sensorHub.pauseBrainAudioForVoiceEnrollment()
                val ok=output.speech.mimic.startEnrollment(consentConfirmed){sensorHub.resumeBrainAudioAfterVoiceEnrollment()}
                if(!ok)sensorHub.resumeBrainAudioAfterVoiceEnrollment()
            },
            onStop={output.speech.mimic.stopEnrollment()},
            onEnabled={output.speech.mimic.setEnabled(it)},
            onStrength={output.speech.mimic.setStrength(it)},
            onDelete={output.speech.mimic.deleteProfile();consentConfirmed=false}
        )}
        item{VoiceFingerprintCard(mimic)}
        item{
            PremiumCard{
                Text("Speak now",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                OutlinedTextField(value=text,onValueChange={text=it.take(500)},modifier=Modifier.fillMaxWidth(),label={Text("Text to synthesize")},minLines=2,maxLines=4,shape=RoundedCornerShape(18.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                    Button(onClick={output.speech.speak(text)},enabled=speech.ready&&!speech.synthesizing,modifier=Modifier.weight(1f),shape=RoundedCornerShape(16.dp)){
                        Icon(Icons.Rounded.PlayArrow,null);Spacer(Modifier.width(6.dp));Text("Speak")
                    }
                    OutlinedButton(onClick={output.speech.stop()},enabled=speech.speaking||speech.synthesizing,modifier=Modifier.weight(1f),shape=RoundedCornerShape(16.dp)){
                        Icon(Icons.Rounded.Stop,null);Spacer(Modifier.width(6.dp));Text("Stop")
                    }
                }
            }
        }
        item{VoiceWaveformCard(speech,vocalRate)}
        item{
            PremiumCard{
                Text("Brain → voice mapping",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                Text("These phrases are spoken only when Act mode selects the corresponding learned motor action and Voice output is enabled.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value=phrase0,onValueChange={phrase0=it.take(160);output.speech.setActionPhrase(0,phrase0)},modifier=Modifier.fillMaxWidth(),label={Text("Action 1 phrase")},shape=RoundedCornerShape(16.dp))
                OutlinedTextField(value=phrase1,onValueChange={phrase1=it.take(160);output.speech.setActionPhrase(1,phrase1)},modifier=Modifier.fillMaxWidth(),label={Text("Action 2 phrase")},shape=RoundedCornerShape(16.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
                    FilledTonalButton(onClick={output.speech.speak(phrase0)},modifier=Modifier.weight(1f)){Text("Test 1")}
                    FilledTonalButton(onClick={output.speech.speak(phrase1)},modifier=Modifier.weight(1f)){Text("Test 2")}
                }
            }
        }
        item{
            PremiumCard{
                Row(verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Rounded.VerifiedUser,null,tint=MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(10.dp))
                    Column{
                        Text("Authorized mimic · local only",fontWeight=FontWeight.SemiBold)
                        Text("v0.6 matches pitch, spectral envelope and dynamics to an explicitly authorized reference. It is an offline acoustic mimic layer over the installed local TTS voice; the acoustic-match score is not identity verification.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceMimicCard(
    m:VoiceMimicState,
    consent:Boolean,
    onConsent:(Boolean)->Unit,
    onStart:()->Unit,
    onStop:()->Unit,
    onEnabled:(Boolean)->Unit,
    onStrength:(Float)->Unit,
    onDelete:()->Unit
){
    PremiumCard{
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Surface(shape=RoundedCornerShape(16.dp),color=if(m.enrolled)MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant){
                Icon(Icons.Rounded.Fingerprint,null,Modifier.padding(11.dp).size(24.dp),tint=if(m.enrolled)MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){
                Text(if(m.enrolled)"Authorized voice profile enrolled" else "Enroll an authorized voice",fontWeight=FontWeight.Bold)
                Text(
                    if(m.enrolled)"Target pitch ${m.targetPitchHz.toInt()} Hz · ${(m.voicedFraction*100).toInt()}% voiced reference"
                    else "Record 4–12 seconds of natural speech. Raw enrollment audio is deleted after analysis.",
                    style=MaterialTheme.typography.bodySmall,
                    color=MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked=m.enabled,onCheckedChange=onEnabled,enabled=m.enrolled&&!m.recording)
        }
        if(!m.enrolled){
            Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.65f)){
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.Top){
                    Checkbox(checked=consent,onCheckedChange=onConsent,enabled=!m.recording)
                    Spacer(Modifier.width(6.dp))
                    Text("I confirm this is my voice, or I have explicit permission from the speaker to create a local voice mimic profile.",style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        if(m.recording){
            LinearProgressIndicator(progress={ (m.elapsedSeconds/12f).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth())
            Text("Recording ${df1.format(m.elapsedSeconds)} s · speak naturally",style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.error)
            Button(onClick=onStop,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){
                Icon(Icons.Rounded.Stop,null);Spacer(Modifier.width(6.dp));Text("Finish enrollment")
            }
        }else if(!m.enrolled){
            Button(onClick=onStart,enabled=consent,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){
                Icon(Icons.Rounded.Mic,null);Spacer(Modifier.width(6.dp));Text("Record voice profile")
            }
            Text("Suggested phrase: “Today I am speaking naturally so this device can learn the sound of my voice.” Repeat it twice at a comfortable volume.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }else{
            Text("Mimic strength ${(m.strength*100).toInt()}%",fontWeight=FontWeight.SemiBold)
            Slider(value=m.strength,onValueChange=onStrength,valueRange=0f..1f)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                Column{
                    Text("Privacy",fontWeight=FontWeight.SemiBold)
                    Text("Raw reference retained: No",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)
                }
                TextButton(onClick=onDelete,enabled=!m.recording){Icon(Icons.Rounded.Delete,null);Spacer(Modifier.width(4.dp));Text("Delete profile")}
            }
        }
        m.error?.let{Text(it,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.error)}
    }
}

@Composable
private fun VoiceFingerprintCard(m:VoiceMimicState){
    if(!m.enrolled)return
    val p=MaterialTheme.colorScheme.primary
    val q=MaterialTheme.colorScheme.secondary
    val grid=MaterialTheme.colorScheme.outlineVariant
    PremiumCard{
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text("Voice fingerprint",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                Text("Reference vs last synthesized output",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if(m.outputFingerprint.isNotEmpty()){
                Text("${(m.acousticMatch*100).toInt()}% match",fontWeight=FontWeight.Bold,color=if(m.acousticMatch>=.72f)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
            }
        }
        Canvas(Modifier.fillMaxWidth().height(130.dp)){
            val labels=4
            val gap=size.width/(labels*2+1)
            val maxVal=maxOf(2.2f,(m.referenceFingerprint+m.outputFingerprint).maxOrNull()?:1f)
            for(i in 0 until labels){
                val x=gap*(1+i*2)
                drawLine(grid,Offset(x,0f),Offset(x,size.height),1f,alpha=.3f)
                val rv=m.referenceFingerprint.getOrElse(i){1f}/maxVal
                val ov=m.outputFingerprint.getOrElse(i){0f}/maxVal
                drawRect(p,topLeft=Offset(x-gap*.6f,size.height*(1-rv)),size=androidx.compose.ui.geometry.Size(gap*.5f,size.height*rv),alpha=.78f)
                if(m.outputFingerprint.isNotEmpty())drawRect(q,topLeft=Offset(x+gap*.08f,size.height*(1-ov)),size=androidx.compose.ui.geometry.Size(gap*.5f,size.height*ov),alpha=.78f)
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceAround){
            listOf("Low","Mid","Presence","High").forEach{Text(it,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
        }
        Text("Acoustic match measures pitch/spectral similarity to the authorized profile. It does not prove speaker identity.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun VoiceWaveformCard(s:SpeechOutputState,vocalRate:Double){
    val primary=MaterialTheme.colorScheme.primary
    val secondary=MaterialTheme.colorScheme.secondary
    val outline=MaterialTheme.colorScheme.outlineVariant
    PremiumCard{
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text("Voice signal",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                Text(when{ s.synthesizing->"Synthesizing locally";s.speaking->"Speaking";s.waveform.isNotEmpty()->"Last synthesized utterance";else->"No utterance yet"},color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Vocal motor ${fmt(vocalRate)}/s",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Canvas(Modifier.fillMaxWidth().height(150.dp)){
            val mid=size.height/2f
            drawLine(outline,Offset(0f,mid),Offset(size.width,mid),1f)
            val w=s.waveform
            if(w.isNotEmpty()){
                val dx=size.width/w.size
                w.forEachIndexed{i,a->
                    val x=(i+.5f)*dx
                    val h=a.coerceIn(0f,1f)*size.height*.42f
                    drawLine(primary,Offset(x,mid-h),Offset(x,mid+h),maxOf(1f,dx*.55f),alpha=.82f)
                }
                val playX=size.width*s.progress.coerceIn(0f,1f)
                drawLine(secondary,Offset(playX,0f),Offset(playX,size.height),2.5f,alpha=.9f)
            }
        }
        if(s.currentText.isNotBlank())Text(s.currentText,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=2,overflow=TextOverflow.Ellipsis)
    }
}

@Composable
private fun SubscreenHeader(title:String,subtitle:String,onBack:()->Unit){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
        IconButton(onClick=onBack){Icon(Icons.Rounded.ArrowBack,null)}
        Column(Modifier.weight(1f)){
            Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private val df1=DecimalFormat("0.0")
private val df3=DecimalFormat("0.000")
private fun fmt(v:Long)=fmt(v.toDouble())
private fun fmt(v:Double):String=when{
    v>=1e12->df1.format(v/1e12)+"T"
    v>=1e9->df1.format(v/1e9)+"B"
    v>=1e6->df1.format(v/1e6)+"M"
    v>=1e3->df1.format(v/1e3)+"K"
    else->df1.format(v)
}
