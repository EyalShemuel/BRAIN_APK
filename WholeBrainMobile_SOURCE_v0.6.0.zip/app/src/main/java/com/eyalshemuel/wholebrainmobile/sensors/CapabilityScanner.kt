package com.eyalshemuel.wholebrainmobile.sensors

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.usb.UsbManager
import android.nfc.NfcAdapter
import android.os.Build
import android.os.VibratorManager
import com.eyalshemuel.wholebrainmobile.brain.CapabilityItem

class CapabilityScanner(private val context: Context) {
    fun scan(): List<CapabilityItem> {
        val pm=context.packageManager
        val out=mutableListOf<CapabilityItem>()
        fun feature(name:String,label:String,category:String="Device") = out.add(CapabilityItem(label,pm.hasSystemFeature(name),name,category))
        feature(PackageManager.FEATURE_CAMERA_ANY,"Camera","Vision")
        feature(PackageManager.FEATURE_MICROPHONE,"Microphone","Audio")
        feature(PackageManager.FEATURE_LOCATION_GPS,"GPS","Spatial")
        feature(PackageManager.FEATURE_BLUETOOTH_LE,"Bluetooth LE","External")
        feature(PackageManager.FEATURE_NFC,"NFC","External")
        feature(PackageManager.FEATURE_USB_HOST,"USB Host","External")
        feature("android.hardware.uwb","UWB","External")
        out += CapabilityItem("Network context",true,"Wi-Fi/cellular state only; no INTERNET permission","Context")
        out += CapabilityItem("Battery / charging",true,"local interoceptive state","Context")
        out += CapabilityItem("Thermal status",Build.VERSION.SDK_INT>=29,"used for workload protection","Context")

        val sm=context.getSystemService(SensorManager::class.java)
        sm.getSensorList(Sensor.TYPE_ALL).sortedBy { it.name }.forEach { s ->
            out += CapabilityItem(s.name,true,"type=${s.type}, vendor=${s.vendor}","Physical sensor")
        }
        val cm=context.getSystemService(CameraManager::class.java)
        runCatching {
            cm.cameraIdList.forEach { id ->
                val c=cm.getCameraCharacteristics(id)
                out += CapabilityItem("Camera $id",true,"lens=${c.get(CameraCharacteristics.LENS_FACING)}, flash=${c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)==true}","Vision")
            }
        }
        val usb=context.getSystemService(UsbManager::class.java)
        out += CapabilityItem("USB devices",true,"connected=${usb.deviceList.size}","External")
        val bt=context.getSystemService(BluetoothManager::class.java)?.adapter
        out += CapabilityItem("Bluetooth adapter",bt!=null,if(bt==null)"absent" else runCatching{"enabled=${bt.isEnabled}"}.getOrElse{"permission required"},"External")
        out += CapabilityItem("NFC adapter",NfcAdapter.getDefaultAdapter(context)!=null,"tap tags while app is open","External")
        if(Build.VERSION.SDK_INT>=31){
            val vm=context.getSystemService(VibratorManager::class.java)
            out += CapabilityItem("Haptics",vm.defaultVibrator.hasVibrator(),"device vibrator","Output")
        }
        return out
    }
}
