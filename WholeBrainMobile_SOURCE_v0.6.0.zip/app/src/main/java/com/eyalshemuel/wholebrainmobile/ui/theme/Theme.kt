package com.eyalshemuel.wholebrainmobile.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Light=lightColorScheme(
    primary=Color(0xFF006B63),
    onPrimary=Color.White,
    primaryContainer=Color(0xFFCDEEEA),
    onPrimaryContainer=Color(0xFF0B302D),
    secondary=Color(0xFF526A67),
    onSecondary=Color.White,
    secondaryContainer=Color(0xFFDCE9E7),
    onSecondaryContainer=Color(0xFF243A37),
    tertiary=Color(0xFF5E628A),
    onTertiary=Color.White,
    tertiaryContainer=Color(0xFFE4E4FF),
    onTertiaryContainer=Color(0xFF2A2D52),
    error=Color(0xFFB3261E),
    errorContainer=Color(0xFFFFDAD6),
    background=Color(0xFFF6F8F8),
    onBackground=Color(0xFF171C1B),
    surface=Color(0xFFFFFFFF),
    onSurface=Color(0xFF171C1B),
    surfaceVariant=Color(0xFFEEF2F1),
    onSurfaceVariant=Color(0xFF5C6664),
    outline=Color(0xFF7A8582),
    outlineVariant=Color(0xFFD9E0DE)
)

private val Dark=darkColorScheme(
    primary=Color(0xFF79D8D0),
    onPrimary=Color(0xFF003733),
    primaryContainer=Color(0xFF164B47),
    onPrimaryContainer=Color(0xFFD2F5F1),
    secondary=Color(0xFFB4CBC7),
    onSecondary=Color(0xFF203633),
    secondaryContainer=Color(0xFF344A47),
    onSecondaryContainer=Color(0xFFD8ECE9),
    tertiary=Color(0xFFC7C8F8),
    onTertiary=Color(0xFF30335A),
    tertiaryContainer=Color(0xFF45486E),
    onTertiaryContainer=Color(0xFFE7E7FF),
    error=Color(0xFFFFB4AB),
    errorContainer=Color(0xFF6B1A16),
    background=Color(0xFF0E1212),
    onBackground=Color(0xFFE1E6E4),
    surface=Color(0xFF151A19),
    onSurface=Color(0xFFE1E6E4),
    surfaceVariant=Color(0xFF222927),
    onSurfaceVariant=Color(0xFFBEC8C5),
    outline=Color(0xFF89938F),
    outlineVariant=Color(0xFF39413F)
)

private val PremiumTypography=Typography(
    displaySmall=TextStyle(fontSize=40.sp,lineHeight=46.sp,fontWeight=FontWeight.Bold,letterSpacing=(-0.6).sp),
    headlineLarge=TextStyle(fontSize=34.sp,lineHeight=40.sp,fontWeight=FontWeight.Bold,letterSpacing=(-0.4).sp),
    headlineSmall=TextStyle(fontSize=24.sp,lineHeight=30.sp,fontWeight=FontWeight.SemiBold,letterSpacing=(-0.2).sp),
    titleLarge=TextStyle(fontSize=20.sp,lineHeight=26.sp,fontWeight=FontWeight.SemiBold),
    titleMedium=TextStyle(fontSize=17.sp,lineHeight=22.sp,fontWeight=FontWeight.SemiBold),
    bodyMedium=TextStyle(fontSize=15.sp,lineHeight=21.sp),
    bodySmall=TextStyle(fontSize=13.sp,lineHeight=18.sp),
    labelLarge=TextStyle(fontSize=14.sp,lineHeight=18.sp,fontWeight=FontWeight.Medium),
    labelMedium=TextStyle(fontSize=12.sp,lineHeight=16.sp,fontWeight=FontWeight.Medium),
    labelSmall=TextStyle(fontSize=11.sp,lineHeight=14.sp,fontWeight=FontWeight.Medium)
)

private val PremiumShapes=Shapes(
    extraSmall=RoundedCornerShape(8.dp),
    small=RoundedCornerShape(12.dp),
    medium=RoundedCornerShape(18.dp),
    large=RoundedCornerShape(24.dp),
    extraLarge=RoundedCornerShape(28.dp)
)

@Composable
fun WholeBrainTheme(content: @Composable () -> Unit){
    MaterialTheme(
        colorScheme=if(isSystemInDarkTheme())Dark else Light,
        typography=PremiumTypography,
        shapes=PremiumShapes,
        content=content
    )
}
