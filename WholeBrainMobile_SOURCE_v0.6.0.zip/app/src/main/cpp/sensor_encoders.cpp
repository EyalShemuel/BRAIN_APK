#include "sensor_encoders.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <vector>

namespace wb::enc {
namespace {
uint64_t mix(uint64_t x) {
    x += 0x9E3779B97F4A7C15ull;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
    return x ^ (x >> 31);
}

inline float clamp01(float v) { return std::clamp(v, 0.0f, 1.0f); }

float component(std::span<const uint8_t> pixels, int width, int height,
                int x, int y, int c) {
    x = std::clamp(x, 0, width - 1);
    y = std::clamp(y, 0, height - 1);
    const size_t cells = static_cast<size_t>(width) * height;
    if (pixels.size() >= cells * 3) {
        return pixels[(static_cast<size_t>(y) * width + x) * 3 + c] / 255.0f;
    }
    if (c == 0 && pixels.size() >= cells) {
        return pixels[static_cast<size_t>(y) * width + x] / 255.0f;
    }
    return c == 0 ? 0.0f : (128.0f / 255.0f);
}

void keepStrongest(std::vector<RankedStimulus>& v, size_t keep) {
    if (v.size() <= keep) return;
    std::nth_element(v.begin(), v.begin() + keep, v.end(),
                     [](const auto& a, const auto& b){ return a.magnitude > b.magnitude; });
    v.resize(keep);
}
}

uint64_t visionKey(uint32_t x, uint32_t y, VisionChannel channel) {
    return (uint64_t(static_cast<uint8_t>(channel)) << 32) |
           (uint64_t(y & 0xFFFFu) << 16) | uint64_t(x & 0xFFFFu);
}
uint32_t visionX(uint64_t key) { return static_cast<uint32_t>(key & 0xFFFFu); }
uint32_t visionY(uint64_t key) { return static_cast<uint32_t>((key >> 16) & 0xFFFFu); }
uint32_t visionChannel(uint64_t key) { return static_cast<uint32_t>((key >> 32) & 0xFFu); }

std::vector<RankedStimulus> visionFeatures(std::span<const uint8_t> pixels,
                                          std::span<const uint8_t> previous,
                                          int width, int height, int maxFeatures) {
    std::vector<RankedStimulus> out;
    if (width <= 1 || height <= 1) return out;
    const size_t cells = static_cast<size_t>(width) * height;
    if (pixels.size() < cells) return out;
    const bool color = pixels.size() >= cells * 3;
    const bool havePrev = previous.size() == pixels.size();

    constexpr size_t channels = kVisionChannels;
    std::array<std::vector<RankedStimulus>, channels> perChannel;
    const size_t quota = std::max<size_t>(1, static_cast<size_t>(std::max(1, maxFeatures)) / channels);
    for (auto& v : perChannel) v.reserve(cells / 3);

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const float lum = component(pixels, width, height, x, y, 0);
            const float prevLum = havePrev ? component(previous, width, height, x, y, 0) : lum;
            const float d = lum - prevLum;
            const float gx = 0.5f * std::abs(component(pixels,width,height,x+1,y,0) -
                                              component(pixels,width,height,x-1,y,0));
            const float gy = 0.5f * std::abs(component(pixels,width,height,x,y+1,0) -
                                              component(pixels,width,height,x,y-1,0));

            auto add = [&](VisionChannel ch, float mag, float minMag) {
                mag = clamp01(mag);
                if (mag >= minMag) perChannel[static_cast<size_t>(ch)].push_back({visionKey(x,y,ch),mag});
            };

            add(VisionChannel::LumaOn,  (lum - 0.50f) * 2.0f, 0.16f);
            add(VisionChannel::LumaOff, (0.50f - lum) * 2.0f, 0.16f);
            if (havePrev) {
                const float motion = std::sqrt(std::abs(d));
                if (d > 0) add(VisionChannel::MotionOn, motion, 0.18f);
                else if (d < 0) add(VisionChannel::MotionOff, motion, 0.18f);
            }
            add(VisionChannel::VerticalEdge, gx * 2.6f, 0.18f);
            add(VisionChannel::HorizontalEdge, gy * 2.6f, 0.18f);

            if (color) {
                const float u = (component(pixels,width,height,x,y,1) - 0.5f) * 2.0f;
                const float v = (component(pixels,width,height,x,y,2) - 0.5f) * 2.0f;
                if (u >= 0) add(VisionChannel::ChromaUPos, u, 0.14f);
                else add(VisionChannel::ChromaUNeg, -u, 0.14f);
                if (v >= 0) add(VisionChannel::ChromaVPos, v, 0.14f);
                else add(VisionChannel::ChromaVNeg, -v, 0.14f);
            }
        }
    }

    out.reserve(std::min<size_t>(maxFeatures, cells * channels));
    for (auto& v : perChannel) {
        keepStrongest(v, quota);
        out.insert(out.end(), v.begin(), v.end());
    }
    // A quota-per-channel selection preserves multiple visual modalities instead of
    // letting a bright or moving patch monopolize every available feature slot.
    if (out.size() > static_cast<size_t>(maxFeatures)) keepStrongest(out, maxFeatures);
    return out;
}

float audioRms(std::span<const int16_t> pcm) {
    if (pcm.empty()) return 0.0f;
    double e = 0.0;
    for (auto s : pcm) { const double x = s / 32768.0; e += x*x; }
    return static_cast<float>(std::sqrt(e / pcm.size()));
}

std::vector<RankedStimulus> audioBands(std::span<const int16_t> pcm,
                                      int sampleRate, int bands, int keep) {
    std::vector<RankedStimulus> out;
    if (pcm.size() < 64 || sampleRate <= 0 || bands <= 0) return out;
    const size_t n = std::min<size_t>(pcm.size(), 1024);
    const float rms = audioRms(pcm.first(n));
    if (rms < 0.0012f) return out; // about -58 dBFS: reject microphone floor

    const double db = 20.0 * std::log10(std::max<double>(rms, 1e-9));
    const float loudness = clamp01(static_cast<float>((db + 55.0) / 43.0));
    const double fMin = 80.0, fMax = std::min(7600.0, sampleRate * 0.45);
    std::vector<double> amp(static_cast<size_t>(bands), 0.0);
    double maxAmp = 1e-12;

    for (int b = 0; b < bands; ++b) {
        const double t = bands == 1 ? 0.0 : double(b) / double(bands - 1);
        const double freq = fMin * std::pow(fMax / fMin, t);
        const double w = 2.0 * M_PI * freq / sampleRate;
        const double coeff = 2.0 * std::cos(w);
        double s0 = 0.0, s1 = 0.0, s2 = 0.0;
        for (size_t i = 0; i < n; ++i) {
            const double win = 0.5 - 0.5 * std::cos(2.0 * M_PI * i / std::max<size_t>(1, n - 1));
            const double x = (pcm[i] / 32768.0) * win;
            s0 = x + coeff * s1 - s2;
            s2 = s1; s1 = s0;
        }
        const double power = std::max(0.0, s1*s1 + s2*s2 - coeff*s1*s2) / double(n*n);
        amp[static_cast<size_t>(b)] = std::sqrt(power);
        maxAmp = std::max(maxAmp, amp[static_cast<size_t>(b)]);
    }

    out.reserve(bands);
    for (int b = 0; b < bands; ++b) {
        // Relative spectral prominence keeps speech/tone structure while loudness keeps
        // quiet microphone noise from being promoted to a full-strength neural event.
        const float relative = clamp01(static_cast<float>(amp[static_cast<size_t>(b)] / maxAmp));
        const float mag = loudness * std::sqrt(relative);
        if (mag >= 0.08f) out.push_back({static_cast<uint64_t>(b), mag});
    }
    const int k = std::min<int>(std::max(1, keep), out.size());
    if (static_cast<int>(out.size()) > k) {
        std::partial_sort(out.begin(), out.begin() + k, out.end(),
                          [](const auto& a, const auto& b){ return a.magnitude > b.magnitude; });
        out.resize(k);
    }
    return out;
}

uint64_t hashBytes(uint32_t channel, std::span<const uint8_t> bytes) {
    uint64_t h = 1469598103934665603ull ^ uint64_t(channel);
    for (uint8_t b : bytes) { h ^= b; h *= 1099511628211ull; }
    return mix(h);
}

uint64_t quantizedVectorKey(int type, float x, float y, float z) {
    auto q = [](float v) -> uint32_t {
        const int iv = std::clamp<int>(int(std::lrint((v + 32.0f) * 64.0f)), 0, 4095);
        return uint32_t(iv);
    };
    return mix(uint64_t(uint32_t(type)) << 48 | uint64_t(q(x)) << 24 | uint64_t(q(y)) << 12 | q(z));
}

uint64_t geoKey(double latitude, double longitude, float speed, float bearing) {
    const int64_t lat = std::llround(latitude * 10000.0);
    const int64_t lon = std::llround(longitude * 10000.0);
    const uint64_t motion = uint64_t(std::clamp<int>(int(speed * 10),0,4095)) << 12 |
                            uint64_t(std::clamp<int>(int(bearing),0,511));
    return mix(uint64_t(lat) ^ (uint64_t(lon) << 21) ^ motion ^ 0x6E656F47ull);
}

} // namespace wb::enc
