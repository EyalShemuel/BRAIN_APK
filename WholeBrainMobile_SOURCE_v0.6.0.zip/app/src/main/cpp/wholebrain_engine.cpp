#include "wholebrain_engine.h"
#include "sensor_encoders.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <iomanip>
#include <limits>
#include <numeric>
#include <sstream>

namespace wb {
namespace {
constexpr std::array<uint32_t, 15> kRegionWidths = {
    35,24,47,18,59,30,35,18,12,29,12,6,18,6,6
};
constexpr uint32_t kRegionWidthSum = 355;
constexpr uint64_t kMaxNeurons = 71000000ull;
constexpr uint32_t kMaxFanout = 4096;
constexpr uint32_t kSerializationMagic = 0x57424D31u; // WBM1
constexpr uint32_t kSerializationVersion = 2; // sensory topology v3

inline float fastDecay(float v, uint32_t dt, float decay) {
    if (dt == 0) return v;
    if (dt > 128) return 0.0f;
    return v * std::pow(decay, static_cast<float>(dt));
}

template <typename T>
void appendBytes(std::vector<uint8_t>& out, const T& value) {
    const auto* p = reinterpret_cast<const uint8_t*>(&value);
    out.insert(out.end(), p, p + sizeof(T));
}

template <typename T>
bool readBytes(std::span<const uint8_t> blob, size_t& off, T& out) {
    if (off + sizeof(T) > blob.size()) return false;
    std::memcpy(&out, blob.data() + off, sizeof(T)); off += sizeof(T); return true;
}

int motionSensorSlot(int type) {
    switch (type) {
        case 1: case 35: return 0;
        case 10: return 1;
        case 9: return 2;
        case 4: case 16: return 3;
        case 3: case 11: case 27: case 28: return 4;
        case 15: case 37: return 5;
        case 20: case 42: return 6;
        case 2: case 14: return 7;
        case 38: case 40: return 0;
        case 39: case 41: return 3;
        default: return -1;
    }
}

float motionDeltaScale(int type) {
    switch (type) {
        case 4: case 16: return 0.55f;
        case 11: case 15: case 20: case 28: case 37: return 0.10f;
        case 3: case 27: case 42: return 5.0f;
        case 2: case 14: return 8.0f;
        case 39: case 41: return 0.55f;
        case 9: return 2.2f;
        default: return 2.0f;
    }
}

constexpr uint32_t kMotionSlots = 8;
constexpr uint32_t kEnvironmentSlots = 20;

int environmentSlot(int type) {
    switch (type) {
        case 5: return 0; case 6: return 1; case 7: return 2; case 8: return 3;
        case 12: return 4; case 13: return 5; case 17: return 6; case 18: return 7;
        case 19: return 8; case 21: return 9; case 22: return 10; case 23: return 11;
        case 24: return 12; case 25: return 13; case 26: return 14; case 29: return 15;
        case 30: return 16; case 31: return 17; case 34: return 18; case 36: return 19;
        default: return -1;
    }
}

float normalizedEnvironmentLevel(int type, float x) {
    switch (type) {
        case 5:  return std::clamp(std::log1p(std::max(0.0f,x)) / std::log1p(20000.0f), 0.0f, 1.0f);
        case 6:  return std::clamp((x - 850.0f) / 250.0f, 0.0f, 1.0f);
        case 7: case 13: return std::clamp((x + 20.0f) / 80.0f, 0.0f, 1.0f);
        case 8:  return 1.0f - std::clamp(x / 10.0f, 0.0f, 1.0f);
        case 12: return std::clamp(x / 100.0f, 0.0f, 1.0f);
        case 17: case 18: case 22: case 23: case 24: case 25: case 26: case 29: case 30: case 31: return x > 0.0f ? 1.0f : 0.0f;
        case 19: return std::clamp(std::fmod(std::max(0.0f,x), 100.0f) / 100.0f, 0.0f, 1.0f);
        case 21: return std::clamp((x - 35.0f) / 165.0f, 0.0f, 1.0f);
        case 34: return x > 0.5f ? 1.0f : 0.0f;
        case 36: return std::clamp(x / 360.0f, 0.0f, 1.0f);
        default: return std::clamp(0.5f + 0.5f * std::tanh(x / 10.0f), 0.0f, 1.0f);
    }
}

inline void updateEma(double& ema, double sample, double keep = 0.90) {
    ema = ema == 0.0 ? sample : keep * ema + (1.0 - keep) * sample;
}

uint32_t unitIndex(uint64_t h, uint32_t n) {
    if (!n) return 0;
    constexpr double inv53 = 1.0 / 9007199254740992.0;
    const double u = double(h >> 11) * inv53;
    return std::min<uint32_t>(n-1, static_cast<uint32_t>(u * n));
}
}

uint64_t BrainEngine::mix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ull;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
    return x ^ (x >> 31);
}

uint32_t BrainEngine::deterministicTarget(uint32_t source, uint32_t slot,
                                          uint32_t n, uint64_t seed) {
    if (!n) return 0;
    const uint64_t x = mix64(seed ^ (uint64_t(source) << 32) ^ uint64_t(slot) * 0xD6E8FEB86659FD93ull);
    return static_cast<uint32_t>(x % n);
}

float BrainEngine::core53ErrorUpdate(float differential, uint16_t count, int chosen, float eta) {
    const float direction = chosen == 1 ? +1.0f : -1.0f;
    return std::clamp(differential + direction * 2.0f * eta * count, -2.0f, 2.0f);
}

uint32_t BrainEngine::topographicLocal(uint32_t regionSize, uint32_t cellIndex, uint32_t cellCount, uint32_t role, uint32_t roleCount) {
    if (!regionSize || !cellCount) return 0;
    cellIndex = std::min(cellIndex, cellCount - 1);
    const uint32_t a = std::min<uint32_t>(static_cast<uint32_t>(uint64_t(regionSize) * cellIndex / cellCount), regionSize - 1);
    const uint32_t rawB = static_cast<uint32_t>(uint64_t(regionSize) * (cellIndex + 1) / cellCount);
    const uint32_t b = std::max<uint32_t>(a + 1, std::min<uint32_t>(rawB, regionSize));
    const uint32_t width = b - a;
    if (width <= 1 || roleCount <= 1) return a;
    role = std::min(role, roleCount - 1);
    return a + static_cast<uint32_t>(uint64_t(role) * (width - 1) / (roleCount - 1));
}

BrainEngine::BrainEngine(const EngineConfig& config) : cfg_(config) {
    cfg_.neurons = std::clamp<uint64_t>(cfg_.neurons, 1024ull, kMaxNeurons);
    cfg_.fanout = std::clamp<uint32_t>(cfg_.fanout, 64u, kMaxFanout);
    cfg_.recurrentDelayMax = std::clamp<uint32_t>(cfg_.recurrentDelayMax, 1u, 32u);
    buildRegions();
    membrane_.assign(cfg_.neurons, 0.0f);
    lastUpdateTick_.assign(cfg_.neurons, 0);
    lastSpikeTick_.assign(cfg_.neurons, 0);
    touchMarker_.assign(cfg_.neurons, 0);
    eventRing_.resize(cfg_.recurrentDelayMax + 2);
    association_ = regions_[static_cast<size_t>(Region::Association)];
    motor_ = regions_[static_cast<size_t>(Region::Motor)];
    const uint32_t assocN = association_.end - association_.begin;
    motorDifferential_.assign(assocN, 0.0f);
    featureCounts_.assign(assocN, 0);
    touched_.reserve(65536);
    featureTouched_.reserve(8192);
    lastFeature_.reserve(8192);
}

void BrainEngine::buildRegions() {
    uint64_t cursor = 0;
    for (size_t r = 0; r < kRegionWidths.size(); ++r) {
        uint64_t next = (r + 1 == kRegionWidths.size())
            ? cfg_.neurons
            : (cfg_.neurons * std::accumulate(kRegionWidths.begin(), kRegionWidths.begin()+r+1, 0ull)) / kRegionWidthSum;
        regions_[r] = {static_cast<uint32_t>(cursor), static_cast<uint32_t>(next)};
        cursor = next;
    }
}

Region BrainEngine::regionOf(uint32_t neuron) const {
    for (size_t r = 0; r < regions_.size(); ++r) if (neuron < regions_[r].end) return static_cast<Region>(r);
    return Region::Brainstem;
}

uint32_t BrainEngine::regionSize(Region region) const {
    const auto rr = regions_[static_cast<size_t>(region)];
    return rr.end - rr.begin;
}

bool BrainEngine::isExcitatory(uint32_t neuron) const {
    const uint64_t h = mix64(cfg_.seed ^ (uint64_t(neuron) * 0x9E3779B97F4A7C15ull));
    return (h & 0xFFFFu) < static_cast<uint64_t>(cfg_.excitatoryFraction * 65535.0f);
}

float BrainEngine::thresholdFor(uint32_t neuron) const {
    const Region r = regionOf(neuron);
    if (r == Region::Association) return 0.92f;
    if (r == Region::Pfc) return 1.08f;
    if (r == Region::Motor) {
        const uint32_t m = motor_.end - motor_.begin;
        const uint32_t half = std::max<uint32_t>(1, m / 2);
        const uint32_t local = neuron - motor_.begin;
        const uint32_t within = local % half;
        const float t = half <= 1 ? 0.0f : float(within) / float(half - 1);
        return 0.05f + 0.75f * t;
    }
    return cfg_.threshold;
}

void BrainEngine::schedule(uint32_t target, float weight, uint32_t delayTicks) {
    if (target >= cfg_.neurons) return;
    delayTicks = std::clamp<uint32_t>(delayTicks, 0u, cfg_.recurrentDelayMax + 1);
    eventRing_[(tick_ + delayTicks) % eventRing_.size()].push_back({target, weight});
}

uint32_t BrainEngine::injectPopulation(Region region, uint64_t key, float magnitude, uint32_t count, float gain) {
    // Legacy deterministic population primitive is preserved for the validated
    // synthetic/learning token path. New physical senses do not use this mapper.
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || magnitude <= 0 || gain <= 0) return 0;
    count = std::min(count, n);
    for (uint32_t i = 0; i < count; ++i) {
        const uint32_t local = static_cast<uint32_t>(mix64(key ^ (uint64_t(i) * 0xA24BAED4963EE407ull)) % n);
        schedule(rr.begin + local, gain * magnitude, 0);
    }
    return count;
}

uint32_t BrainEngine::injectChannelPopulation(Region region, uint32_t channel, uint32_t channelCount,
                                              float magnitude, float density, float gain, uint64_t salt,
                                              uint32_t maxCount) {
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || !channelCount || magnitude <= 0.0f || gain <= 0.0f) return 0;
    channel = std::min(channel, channelCount - 1);
    const uint32_t a = rr.begin + static_cast<uint32_t>(uint64_t(n) * channel / channelCount);
    const uint32_t rawB = rr.begin + static_cast<uint32_t>(uint64_t(n) * (channel + 1) / channelCount);
    const uint32_t b = std::max<uint32_t>(a + 1, std::min<uint32_t>(rawB, rr.end));
    const uint32_t width = b - a;
    uint32_t count = static_cast<uint32_t>(std::lround(width * density * std::clamp(magnitude,0.0f,1.0f)));
    count = std::clamp<uint32_t>(count, 1u, std::min<uint32_t>(maxCount, width));
    const float drive = gain * std::clamp(0.58f + 0.62f * magnitude, 0.0f, 1.35f);
    for (uint32_t i=0;i<count;++i) {
        const uint64_t h = mix64(salt ^ uint64_t(channel) * 0x9E3779B97F4A7C15ull ^ i);
        const uint32_t jitter = width > 1 ? unitIndex(h,width) : 0;
        const uint32_t evenly = static_cast<uint32_t>(uint64_t(i) * width / count);
        const uint32_t local = (evenly + jitter / std::max<uint32_t>(1,count)) % width;
        schedule(a + local, drive, 0);
    }
    return count;
}

uint32_t BrainEngine::injectDistributedSubrange(Region region, uint32_t bank, uint32_t banks,
                                                uint64_t key, float magnitude, float density, float gain,
                                                uint32_t maxCount) {
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || !banks || magnitude <= 0.0f) return 0;
    bank = std::min(bank, banks - 1);
    const uint32_t a = rr.begin + static_cast<uint32_t>(uint64_t(n) * bank / banks);
    const uint32_t rawB = rr.begin + static_cast<uint32_t>(uint64_t(n) * (bank + 1) / banks);
    const uint32_t b = std::max<uint32_t>(a + 1, std::min<uint32_t>(rawB, rr.end));
    const uint32_t width = b - a;
    uint32_t count = static_cast<uint32_t>(std::lround(width * density * std::clamp(magnitude,0.0f,1.0f)));
    count = std::clamp<uint32_t>(count, 1u, std::min<uint32_t>(maxCount, width));
    const float drive = gain * std::clamp(0.62f + 0.58f * magnitude, 0.0f, 1.35f);
    for (uint32_t i=0;i<count;++i) {
        const uint64_t h = mix64(key ^ uint64_t(i) * 0xD6E8FEB86659FD93ull);
        const uint32_t local = width > 1 ? unitIndex(h,width) : 0;
        schedule(a + local, drive, 0);
    }
    return count;
}

uint32_t BrainEngine::injectTopographicCell(Region region, uint32_t x, uint32_t y,
                                            uint32_t width, uint32_t height,
                                            uint32_t role, uint32_t roleCount,
                                            float magnitude, float gain) {
    const auto rr = regions_[static_cast<size_t>(region)];
    const uint32_t n = rr.end - rr.begin;
    if (!n || !width || !height || x >= width || y >= height || magnitude <= 0.0f) return 0;
    const uint32_t cell = y * width + x;
    const uint32_t local = topographicLocal(n, cell, width*height, role, roleCount);
    const float drive = gain * std::clamp(0.55f + 0.68f * magnitude, 0.0f, 1.40f);
    schedule(rr.begin + std::min(local,n-1), drive, 0);
    return 1;
}

uint32_t BrainEngine::injectVisualFeature(uint64_t key, float magnitude, int width, int height) {
    return injectTopographicCell(Region::Visual,
        enc::visionX(key), enc::visionY(key),
        static_cast<uint32_t>(width), static_cast<uint32_t>(height),
        enc::visionChannel(key), enc::kVisionChannels,
        magnitude, cfg_.visionGain);
}

uint32_t BrainEngine::injectAudioBand(uint32_t band, float magnitude, float onset) {
    band = std::min<uint32_t>(band, enc::kAudioBands - 1);
    uint32_t n = injectChannelPopulation(Region::Auditory, band, enc::kAudioBands,
                                         magnitude, 0.018f, cfg_.audioGain,
                                         0x415544494Full, 12);
    if (onset > 0.18f) {
        n += injectChannelPopulation(Region::Auditory, band, enc::kAudioBands,
                                     onset, 0.008f, cfg_.audioGain,
                                     0x4F4E534554ull, 6);
    }
    return n;
}

void BrainEngine::noteCameraFrame() {
    std::lock_guard lock(mutex_);
    ++pendingCameraFrames_;
}

void BrainEngine::injectVision(std::span<const uint8_t> pixels, int width, int height) {
    std::lock_guard lock(mutex_);
    ++pendingVisionFrames_;
    const auto features = enc::visionFeatures(pixels, previousVision_, width, height, 768);
    pendingVisionFeatures_ += features.size();
    for (const auto& f : features) pendingVisionInjections_ += injectVisualFeature(f.key, f.magnitude, width, height);
    previousVision_.assign(pixels.begin(), pixels.end());
}

void BrainEngine::injectAudio(std::span<const int16_t> pcm, int sampleRate) {
    std::lock_guard lock(mutex_);
    ++pendingAudioChunks_;
    const auto bands = enc::audioBands(pcm, sampleRate, enc::kAudioBands, 16);
    pendingAudioBands_ += bands.size();
    std::array<float,enc::kAudioBands> current{};
    for (const auto& f : bands) {
        const uint32_t b = std::min<uint32_t>(static_cast<uint32_t>(f.key), enc::kAudioBands-1);
        current[b] = std::max(current[b], f.magnitude);
    }
    for (uint32_t b=0;b<enc::kAudioBands;++b) {
        if (current[b] <= 0.0f) continue;
        const float onset = havePreviousAudio_ ? std::max(0.0f, current[b] - previousAudioBands_[b]) : current[b];
        pendingAudioInjections_ += injectAudioBand(b,current[b],onset);
    }
    previousAudioBands_ = current;
    havePreviousAudio_ = true;
}

void BrainEngine::injectSensor(int sensorType, float x, float y, float z) {
    std::lock_guard lock(mutex_);
    const int slot = motionSensorSlot(sensorType);
    if (slot >= 0) {
        ++pendingImuEvents_;
        const std::array<float,3> now{x,y,z};
        auto it = previousMotionSensor_.find(sensorType);
        if (it == previousMotionSensor_.end()) { previousMotionSensor_[sensorType] = now; return; }
        const std::array<float,3> d{x-it->second[0], y-it->second[1], z-it->second[2]};
        it->second = now;
        const float scale = motionDeltaScale(sensorType);
        bool changed=false;
        for (uint32_t axis=0;axis<3;++axis) {
            const float mag = std::clamp(std::abs(d[axis]) / std::max(1e-5f,scale), 0.0f, 1.0f);
            if (mag < 0.045f) continue;
            changed=true;
            const uint32_t polarity = d[axis] >= 0 ? 0u : 1u;
            const uint32_t channel = static_cast<uint32_t>(slot) * 6u + axis*2u + polarity;
            pendingImuInjections_ += injectChannelPopulation(Region::Somatosensory,channel,kMotionSlots*6u,mag,0.020f,cfg_.imuGain,0x534F4D41ull,8);
            pendingImuInjections_ += injectChannelPopulation(Region::Cerebellum,channel,kMotionSlots*6u,mag,0.024f,cfg_.imuGain,0x43455245ull,10);
        }
        if (changed) {
            ++pendingImuChanges_;
            const float coarse = std::clamp(std::sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]) / std::max(1e-5f,scale),0.0f,1.0f);
            pendingImuInjections_ += injectChannelPopulation(Region::Brainstem,static_cast<uint32_t>(slot),kMotionSlots,coarse,0.012f,cfg_.imuGain,0x425241494Eull,4);
        }
        return;
    }
    injectEnvironment(sensorType,x,y,z);
}

void BrainEngine::injectEnvironment(int sensorType, float x, float y, float z) {
    ++pendingEnvironmentEvents_;
    if (sensorType == 10001) {
        const std::array<float,3> levels{
            std::clamp(x,0.0f,1.0f),
            std::clamp((y + 10.0f)/70.0f,0.0f,1.0f),
            std::clamp((z - 3.0f)/1.6f,0.0f,1.0f)};
        for (uint32_t i=0;i<3;++i) pendingEnvironmentInjections_ += injectChannelPopulation(Region::Brainstem,i,8,levels[i],0.020f,cfg_.environmentGain,0x42415454ull+i,6);
        ++pendingEnvironmentChanges_;
        return;
    }
    if (sensorType == 10002) {
        const float level = std::clamp(x/6.0f,0.0f,1.0f);
        pendingEnvironmentInjections_ += injectChannelPopulation(Region::Brainstem,3,8,std::max(0.15f,level),0.020f,cfg_.environmentGain,0x544845524Dull,6);
        ++pendingEnvironmentChanges_;
        return;
    }

    const int slot = environmentSlot(sensorType);
    if (slot < 0) return;
    const float level = normalizedEnvironmentLevel(sensorType,x);
    auto it = previousEnvironmentLevel_.find(sensorType);
    const bool first = it == previousEnvironmentLevel_.end();
    const float prev = first ? level : it->second;
    previousEnvironmentLevel_[sensorType] = level;
    float delta = level - prev;
    if (sensorType == 19 && !first && x > 0) delta = std::max(delta,0.25f);
    const bool eventSensor = sensorType==17 || sensorType==18 || (sensorType>=22 && sensorType<=26) || sensorType==29 || sensorType==30 || sensorType==31 || sensorType==34;
    if (!first && !eventSensor && std::abs(delta) < 0.015f) return;
    ++pendingEnvironmentChanges_;
    pendingEnvironmentInjections_ += injectChannelPopulation(Region::Thalamus,static_cast<uint32_t>(slot),kEnvironmentSlots,
                                                              std::max(0.12f,level),0.018f,cfg_.environmentGain,0x454E564Cull,8);
    if (!first && std::abs(delta) >= 0.015f) {
        const uint32_t ch = static_cast<uint32_t>(slot)*2u + (delta>=0?0u:1u);
        pendingEnvironmentInjections_ += injectChannelPopulation(Region::Somatosensory,ch,kEnvironmentSlots*2u,
                                                                  std::clamp(std::abs(delta)*4.0f,0.0f,1.0f),0.018f,cfg_.environmentGain,0x44454C5441ull,6);
    }
}

void BrainEngine::injectTouch(float xNorm, float yNorm, float pressure) {
    std::lock_guard lock(mutex_);
    ++pendingTouchEvents_;
    xNorm=std::clamp(xNorm,0.0f,1.0f); yNorm=std::clamp(yNorm,0.0f,1.0f);
    const bool down = pressure > 0.0f;
    const uint32_t gx=std::min<uint32_t>(31,static_cast<uint32_t>(xNorm*32.0f));
    const uint32_t gy=std::min<uint32_t>(17,static_cast<uint32_t>(yNorm*18.0f));
    constexpr uint32_t roles=8;
    if (down) {
        const float p=std::clamp(pressure,0.05f,1.0f);
        pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,previousTouch_.active?1u:0u,roles,1.0f,cfg_.touchGain);
        if (p>0.25f) pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,2,roles,p,cfg_.touchGain);
        if (previousTouch_.active) {
            const float dx=xNorm-previousTouch_.x, dy=yNorm-previousTouch_.y;
            if (std::abs(dx)>0.004f) pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,dx>=0?3u:4u,roles,std::min(1.0f,std::abs(dx)*18.0f),cfg_.touchGain);
            if (std::abs(dy)>0.004f) pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,gx,gy,32,18,dy>=0?5u:6u,roles,std::min(1.0f,std::abs(dy)*18.0f),cfg_.touchGain);
        }
        previousTouch_={xNorm,yNorm,p,true};
    } else if (previousTouch_.active) {
        const uint32_t px=std::min<uint32_t>(31,static_cast<uint32_t>(previousTouch_.x*32.0f));
        const uint32_t py=std::min<uint32_t>(17,static_cast<uint32_t>(previousTouch_.y*18.0f));
        pendingTouchInjections_ += injectTopographicCell(Region::Somatosensory,px,py,32,18,7,roles,1.0f,cfg_.touchGain);
        previousTouch_={xNorm,yNorm,0.0f,false};
    }
}

void BrainEngine::injectLocation(double latitude, double longitude, float speed, float bearing) {
    std::lock_guard lock(mutex_);
    ++pendingLocationEvents_;
    const double latRad = latitude * M_PI / 180.0;
    const double north = latitude * 110540.0;
    const double east = longitude * 111320.0 * std::cos(latRad);
    constexpr std::array<double,3> scales{200.0,50.0,10.0};
    for (uint32_t bank=0;bank<scales.size();++bank) {
        const int64_t tx=static_cast<int64_t>(std::floor(east/scales[bank]));
        const int64_t ty=static_cast<int64_t>(std::floor(north/scales[bank]));
        const uint64_t key=mix64(uint64_t(tx) ^ (uint64_t(ty)<<29) ^ uint64_t(bank)*0x9E3779B97F4A7C15ull);
        pendingLocationInjections_ += injectDistributedSubrange(Region::Hippocampus,bank,scales.size(),key,1.0f,0.0025f,cfg_.locationGain,24);
        if (bank==0) pendingLocationInjections_ += injectDistributedSubrange(Region::Semantic,0,4,key^0x504C414345ull,0.8f,0.0015f,cfg_.tokenGain,16);
    }
    if (speed > 0.15f) {
        const float smag=std::clamp(speed/8.0f,0.0f,1.0f);
        const uint32_t dir=static_cast<uint32_t>(std::fmod(std::max(0.0f,bearing),360.0f)/45.0f)%8u;
        pendingLocationInjections_ += injectChannelPopulation(Region::Cerebellum,dir,8,smag,0.012f,cfg_.locationGain,0x475053444952ull,8);
        pendingLocationInjections_ += injectChannelPopulation(Region::Thalamus,0,8,smag,0.010f,cfg_.locationGain,0x475053535044ull,6);
    }
}

void BrainEngine::injectToken(uint32_t channel, std::span<const uint8_t> bytes) {
    std::lock_guard lock(mutex_);
    const uint64_t key = enc::hashBytes(channel, bytes);
    if (channel == 9) {
        // Scientific regression lock: keep the exact pre-v3 cue injection used by
        // the reward-learning smoke/CORE53 bridge. Physical senses use new topology.
        injectPopulation(Region::Semantic, key, 0.8f, 8, cfg_.sensorGain);
        injectPopulation(Region::Association, key ^ 0xA550Cull, 0.45f, 6, cfg_.sensorGain);
        return;
    }
    const uint32_t bank = channel % 16u;
    const uint32_t sem = injectDistributedSubrange(Region::Semantic,bank,16,key,1.0f,0.0040f,cfg_.tokenGain,32);
    const uint32_t assoc = injectDistributedSubrange(Region::Association,bank,16,key^0xA550Cull,0.85f,0.0025f,cfg_.tokenGain,48);
    if (channel>=1 && channel<=4) {
        ++pendingExternalTokens_;
        pendingExternalInjections_ += sem + assoc;
    }
}

void BrainEngine::resetDiagnostics() {
    std::lock_guard lock(mutex_);
    emaRegionSpikesPerSecond_.fill(0.0);
    emaCameraFramesPerSecond_ = emaVisionFramesPerSecond_ = 0.0;
    emaVisionFeaturesPerSecond_ = emaVisionInjectionsPerSecond_ = 0.0;
    emaAudioChunksPerSecond_ = emaAudioBandsPerSecond_ = emaAudioInjectionsPerSecond_ = 0.0;
    emaTouchEventsPerSecond_ = emaTouchInjectionsPerSecond_ = 0.0;
    emaImuEventsPerSecond_ = emaImuChangesPerSecond_ = emaImuInjectionsPerSecond_ = 0.0;
    emaEnvironmentEventsPerSecond_ = emaEnvironmentChangesPerSecond_ = emaEnvironmentInjectionsPerSecond_ = 0.0;
    emaLocationEventsPerSecond_ = emaLocationInjectionsPerSecond_ = 0.0;
    emaExternalTokensPerSecond_ = emaExternalInjectionsPerSecond_ = 0.0;
    pendingCameraFrames_ = pendingVisionFrames_ = pendingVisionFeatures_ = pendingVisionInjections_ = 0;
    pendingAudioChunks_ = pendingAudioBands_ = pendingAudioInjections_ = 0;
    pendingTouchEvents_ = pendingTouchInjections_ = 0;
    pendingImuEvents_ = pendingImuChanges_ = pendingImuInjections_ = 0;
    pendingEnvironmentEvents_ = pendingEnvironmentChanges_ = pendingEnvironmentInjections_ = 0;
    pendingLocationEvents_ = pendingLocationInjections_ = 0;
    pendingExternalTokens_ = pendingExternalInjections_ = 0;
    previousVision_.clear();
    previousAudioBands_.fill(0.0f); havePreviousAudio_=false;
    previousMotionSensor_.clear(); previousEnvironmentLevel_.clear(); previousTouch_={};
}

void BrainEngine::applyLazyDecay(uint32_t neuron) {
    const uint32_t last = lastUpdateTick_[neuron];
    const uint32_t dt = static_cast<uint32_t>(tick_ - last);
    if (dt) membrane_[neuron] = fastDecay(membrane_[neuron], dt, cfg_.membraneDecay);
    lastUpdateTick_[neuron] = static_cast<uint32_t>(tick_);
}

void BrainEngine::fire(uint32_t neuron, std::vector<uint32_t>& fired) {
    membrane_[neuron] = cfg_.resetPotential;
    lastSpikeTick_[neuron] = static_cast<uint32_t>(tick_);
    fired.push_back(neuron);
}

void BrainEngine::propagate(std::span<const uint32_t> fired, std::vector<TraceEdge>* traceEdges) {
    const uint32_t localSlots = static_cast<uint32_t>(cfg_.fanout * cfg_.localFraction);
    if (traceEdges) {
        size_t expected = 0;
        if (fired.size() <= (std::numeric_limits<size_t>::max() / std::max<uint32_t>(1,cfg_.fanout)))
            expected = fired.size() * size_t(cfg_.fanout);
        traceEdges->clear();
        traceEdges->reserve(expected);
    }
    for (uint32_t src : fired) {
        const Region sr = regionOf(src);
        // Dedicated Motor/VocalMotor outputs do not spray random recurrent edges.
        if (sr == Region::Motor || sr == Region::VocalMotor) continue;
        const bool exc = isExcitatory(src);
        const float weight = exc ? cfg_.excitatoryWeight : -cfg_.inhibitoryWeight;
        const auto rr = regions_[static_cast<size_t>(sr)];
        const uint32_t localN = std::max<uint32_t>(1, rr.end - rr.begin);
        for (uint32_t slot = 0; slot < cfg_.fanout; ++slot) {
            const uint64_t h = mix64(cfg_.seed ^ (uint64_t(src) << 32) ^ uint64_t(slot) * 0xD6E8FEB86659FD93ull);
            uint32_t target;
            if (slot < localSlots) target = rr.begin + static_cast<uint32_t>(h % localN);
            else target = static_cast<uint32_t>(h % cfg_.neurons);
            // Motor output pools are isolated from unrelated recurrent common-mode noise.
            if (target >= motor_.begin && target < motor_.end) continue;
            const uint32_t delay = 1 + static_cast<uint32_t>((h >> 32) % cfg_.recurrentDelayMax);
            schedule(target, weight, delay);
            if (traceEdges) traceEdges->push_back({src,target,static_cast<uint16_t>(delay),static_cast<int8_t>(exc?1:-1)});
            ++edgeEventsTotal_;
        }
    }
}

void BrainEngine::processMotor(std::span<const uint32_t> fired) {
    for (uint32_t n : fired) {
        if (n >= association_.begin && n < association_.end && isExcitatory(n)) {
            const uint32_t ix = n - association_.begin;
            motorEvidence_ += motorDifferential_[ix];
            if (featureCounts_[ix] == 0) featureTouched_.push_back(ix);
            if (featureCounts_[ix] != std::numeric_limits<uint16_t>::max()) ++featureCounts_[ix];
        } else if (n >= motor_.begin && n < motor_.end) {
            const uint32_t half = std::max<uint32_t>(1, (motor_.end - motor_.begin)/2);
            const int a = (n - motor_.begin) < half ? 0 : 1;
            ++motorSpikesWindow_[a];
        }
    }

    // Convert only differential evidence into opponent E/I population current.
    if (std::abs(motorEvidence_) > 1e-9) {
        const uint32_t half = std::max<uint32_t>(1, (motor_.end - motor_.begin)/2);
        const float q = std::min<float>(2.5f, std::abs(float(motorEvidence_)) * cfg_.motorGain);
        const int favored = motorEvidence_ > 0 ? 0 : 1;
        const uint32_t begin = motor_.begin + (favored ? half : 0);
        const uint32_t end = favored ? motor_.end : std::min(motor_.begin + half, motor_.end);
        for (uint32_t n = begin; n < end; ++n) schedule(n, q, 1);
        motorEvidence_ = 0.0;
    }
}

void BrainEngine::resetCurrentFeature() {
    for (uint32_t ix : featureTouched_) featureCounts_[ix] = 0;
    featureTouched_.clear();
}

void BrainEngine::finishActionWindow() {
    lastFeature_.clear();
    lastFeature_.reserve(featureTouched_.size());
    for (uint32_t ix : featureTouched_) if (featureCounts_[ix]) lastFeature_.push_back({ix, featureCounts_[ix]});
    const int64_t margin = int64_t(motorSpikesWindow_[0]) - int64_t(motorSpikesWindow_[1]);
    lastMotorMargin_ = double(margin);
    if (lastFeature_.empty()) lastAction_ = -1;
    else if (margin > 0) lastAction_ = 0;
    else if (margin < 0) lastAction_ = 1;
    else if (mode_ == RunMode::Learn) lastAction_ = int(mix64(cfg_.seed ^ tick_) & 1ull); // explicit exploration only while learning
    else lastAction_ = -1;
    ++actionEpoch_;
    motorSpikesWindow_ = {0,0};
    resetCurrentFeature();
}

void BrainEngine::step() {
    const auto t0 = std::chrono::steady_clock::now();
    std::lock_guard lock(mutex_);
    const uint64_t edgesBefore = edgeEventsTotal_;
    auto& bucket = eventRing_[tick_ % eventRing_.size()];
    touched_.clear();
    if (++touchEpoch_ == 0) { std::fill(touchMarker_.begin(), touchMarker_.end(), 0); touchEpoch_ = 1; }
    for (const auto& e : bucket) {
        const uint32_t n = e.target;
        applyLazyDecay(n);
        membrane_[n] += e.weight;
        if (touchMarker_[n] != touchEpoch_) { touchMarker_[n] = touchEpoch_; touched_.push_back(n); }
    }
    bucket.clear();

    std::vector<uint32_t> fired;
    fired.reserve(touched_.size()/4 + 16);
    for (uint32_t n : touched_) {
        const uint32_t since = static_cast<uint32_t>(tick_ - lastSpikeTick_[n]);
        if (since <= cfg_.refractoryTicks) continue;
        if (membrane_[n] >= thresholdFor(n)) fire(n, fired);
    }
    spikesLastStep_ = static_cast<uint32_t>(fired.size());
    spikesTotal_ += fired.size();

    std::array<uint32_t, static_cast<size_t>(Region::Count)> regionCounts{};
    for (uint32_t n : fired) ++regionCounts[static_cast<size_t>(regionOf(n))];

    processMotor(fired);
    if (traceEnabled_) {
        TraceFrame frame;
        frame.tick = tick_;
        frame.fired = fired;
        propagate(fired, &frame.edges);
        traceFrames_.push_back(std::move(frame));
        while (traceFrames_.size() > kTraceHistoryFrames) traceFrames_.pop_front();
    } else {
        propagate(fired, nullptr);
    }
    ++tick_;
    if (cfg_.actionWindowTicks && tick_ % cfg_.actionWindowTicks == 0) finishActionWindow();

    const auto t1 = std::chrono::steady_clock::now();
    lastStepMs_ = std::chrono::duration<double, std::milli>(t1 - t0).count();
    emaStepMs_ = emaStepMs_ == 0 ? lastStepMs_ : 0.95*emaStepMs_ + 0.05*lastStepMs_;
    const double sec = std::max(1e-6, cfg_.timestepMs / 1000.0);
    const double sps = fired.size()/sec;
    updateEma(emaSpikesPerSecond_, sps);
    const double eps = double(edgeEventsTotal_ - edgesBefore) / sec;
    updateEma(emaEdgesPerSecond_, eps);
    for (size_t r=0; r<regionCounts.size(); ++r) updateEma(emaRegionSpikesPerSecond_[r], regionCounts[r]/sec);

    updateEma(emaCameraFramesPerSecond_, pendingCameraFrames_/sec);
    updateEma(emaVisionFramesPerSecond_, pendingVisionFrames_/sec);
    updateEma(emaVisionFeaturesPerSecond_, pendingVisionFeatures_/sec);
    updateEma(emaVisionInjectionsPerSecond_, pendingVisionInjections_/sec);
    updateEma(emaAudioChunksPerSecond_, pendingAudioChunks_/sec);
    updateEma(emaAudioBandsPerSecond_, pendingAudioBands_/sec);
    updateEma(emaAudioInjectionsPerSecond_, pendingAudioInjections_/sec);
    updateEma(emaTouchEventsPerSecond_, pendingTouchEvents_/sec);
    updateEma(emaTouchInjectionsPerSecond_, pendingTouchInjections_/sec);
    updateEma(emaImuEventsPerSecond_, pendingImuEvents_/sec);
    updateEma(emaImuChangesPerSecond_, pendingImuChanges_/sec);
    updateEma(emaImuInjectionsPerSecond_, pendingImuInjections_/sec);
    updateEma(emaEnvironmentEventsPerSecond_, pendingEnvironmentEvents_/sec);
    updateEma(emaEnvironmentChangesPerSecond_, pendingEnvironmentChanges_/sec);
    updateEma(emaEnvironmentInjectionsPerSecond_, pendingEnvironmentInjections_/sec);
    updateEma(emaLocationEventsPerSecond_, pendingLocationEvents_/sec);
    updateEma(emaLocationInjectionsPerSecond_, pendingLocationInjections_/sec);
    updateEma(emaExternalTokensPerSecond_, pendingExternalTokens_/sec);
    updateEma(emaExternalInjectionsPerSecond_, pendingExternalInjections_/sec);

    pendingCameraFrames_ = pendingVisionFrames_ = pendingVisionFeatures_ = pendingVisionInjections_ = 0;
    pendingAudioChunks_ = pendingAudioBands_ = pendingAudioInjections_ = 0;
    pendingTouchEvents_ = pendingTouchInjections_ = 0;
    pendingImuEvents_ = pendingImuChanges_ = pendingImuInjections_ = 0;
    pendingEnvironmentEvents_ = pendingEnvironmentChanges_ = pendingEnvironmentInjections_ = 0;
    pendingLocationEvents_ = pendingLocationInjections_ = 0;
    pendingExternalTokens_ = pendingExternalInjections_ = 0;
}

void BrainEngine::setTraceEnabled(bool enabled) {
    std::lock_guard lock(mutex_);
    traceEnabled_ = enabled;
    traceFrames_.clear();
}

std::vector<int32_t> BrainEngine::traceFrame(size_t back) const {
    std::lock_guard lock(mutex_);
    if (!traceEnabled_ || traceFrames_.empty() || back >= traceFrames_.size()) return {};
    const auto& f = traceFrames_[traceFrames_.size() - 1 - back];
    // Binary int layout:
    // [version, tickLo, tickHi, neuronCount, edgeCount, totalNeurons, historyDepth,
    //  fired neuron ids..., edge(source,target,delay,sign)*]
    constexpr int32_t version = 1;
    const size_t header = 7;
    const size_t edgeInts = 4;
    if (f.edges.size() > (std::numeric_limits<size_t>::max() - header - f.fired.size()) / edgeInts) return {};
    std::vector<int32_t> out;
    out.reserve(header + f.fired.size() + edgeInts * f.edges.size());
    out.push_back(version);
    out.push_back(static_cast<int32_t>(f.tick & 0xffffffffull));
    out.push_back(static_cast<int32_t>((f.tick >> 32) & 0xffffffffull));
    out.push_back(static_cast<int32_t>(f.fired.size()));
    out.push_back(static_cast<int32_t>(f.edges.size()));
    out.push_back(static_cast<int32_t>(std::min<uint64_t>(cfg_.neurons, uint64_t(std::numeric_limits<int32_t>::max()))));
    out.push_back(static_cast<int32_t>(traceFrames_.size()));
    for (uint32_t n : f.fired) out.push_back(static_cast<int32_t>(n));
    for (const auto& e : f.edges) {
        out.push_back(static_cast<int32_t>(e.source));
        out.push_back(static_cast<int32_t>(e.target));
        out.push_back(static_cast<int32_t>(e.delay));
        out.push_back(static_cast<int32_t>(e.sign));
    }
    return out;
}

void BrainEngine::reward(bool positive) {
    std::lock_guard lock(mutex_);
    if (lastAction_ < 0 || lastFeature_.empty()) return;
    if (!positive && (mode_ == RunMode::Learn || mode_ == RunMode::Act)) {
        for (const auto& f : lastFeature_) {
            if (f.index >= motorDifferential_.size()) continue;
            float& d = motorDifferential_[f.index];
            d = core53ErrorUpdate(d, f.count, lastAction_, cfg_.learningRate);
        }
        ++reinforcedEpisodes_;
    }
}

void BrainEngine::setMode(RunMode mode) { std::lock_guard lock(mutex_); mode_ = mode; }
RunMode BrainEngine::mode() const { std::lock_guard lock(mutex_); return mode_; }

uint64_t BrainEngine::memoryBytesUnsafe() const {
    uint64_t bytes = membrane_.capacity()*sizeof(float) + lastUpdateTick_.capacity()*sizeof(uint32_t) +
        lastSpikeTick_.capacity()*sizeof(uint32_t) + touchMarker_.capacity()*sizeof(uint16_t) +
        motorDifferential_.capacity()*sizeof(float) + featureCounts_.capacity()*sizeof(uint16_t) +
        previousVision_.capacity();
    for (auto& b : eventRing_) bytes += b.capacity()*sizeof(Event);
    return bytes;
}

Stats BrainEngine::stats() const {
    std::lock_guard lock(mutex_);
    uint64_t q = 0; for (const auto& b : eventRing_) q += b.size();
    Stats s;
    s.neurons = cfg_.neurons; s.logicalSynapses = cfg_.neurons * uint64_t(cfg_.fanout);
    s.tick=tick_; s.spikesTotal=spikesTotal_; s.edgeEventsTotal=edgeEventsTotal_;
    s.spikesLastStep=spikesLastStep_; s.queuedEvents=q; s.lastStepMs=lastStepMs_;
    s.spikesPerSecond=emaSpikesPerSecond_; s.edgesPerSecond=emaEdgesPerSecond_;
    s.stepHz=emaStepMs_>0 ? 1000.0/emaStepMs_ : 0.0;
    s.regionSpikesPerSecond=emaRegionSpikesPerSecond_;
    s.cameraFramesPerSecond=emaCameraFramesPerSecond_; s.visionFramesPerSecond=emaVisionFramesPerSecond_;
    s.visionFeaturesPerSecond=emaVisionFeaturesPerSecond_; s.visionInjectionsPerSecond=emaVisionInjectionsPerSecond_;
    s.audioChunksPerSecond=emaAudioChunksPerSecond_; s.audioBandsPerSecond=emaAudioBandsPerSecond_;
    s.audioInjectionsPerSecond=emaAudioInjectionsPerSecond_;
    s.touchEventsPerSecond=emaTouchEventsPerSecond_; s.touchInjectionsPerSecond=emaTouchInjectionsPerSecond_;
    s.imuEventsPerSecond=emaImuEventsPerSecond_; s.imuChangesPerSecond=emaImuChangesPerSecond_; s.imuInjectionsPerSecond=emaImuInjectionsPerSecond_;
    s.environmentEventsPerSecond=emaEnvironmentEventsPerSecond_; s.environmentChangesPerSecond=emaEnvironmentChangesPerSecond_; s.environmentInjectionsPerSecond=emaEnvironmentInjectionsPerSecond_;
    s.locationEventsPerSecond=emaLocationEventsPerSecond_; s.locationInjectionsPerSecond=emaLocationInjectionsPerSecond_;
    s.externalTokensPerSecond=emaExternalTokensPerSecond_; s.externalInjectionsPerSecond=emaExternalInjectionsPerSecond_;
    s.currentAction=lastAction_; s.actionEpoch=actionEpoch_;
    s.motorMargin=lastMotorMargin_;
    double dsum=0.0; for(float d: motorDifferential_) dsum += std::abs(double(d));
    s.motorDifferential = motorDifferential_.empty()?0.0:dsum/motorDifferential_.size();
    s.reinforcedEpisodes=reinforcedEpisodes_;
    s.memoryBytes=memoryBytesUnsafe(); s.mode=mode_; return s;
}

std::string BrainEngine::statsJson() const {
    const auto s=stats(); std::ostringstream o; o<<std::fixed<<std::setprecision(3);
    o<<"{\"neurons\":"<<s.neurons<<",\"logicalSynapses\":"<<s.logicalSynapses
     <<",\"tick\":"<<s.tick<<",\"spikesTotal\":"<<s.spikesTotal
     <<",\"edgeEventsTotal\":"<<s.edgeEventsTotal<<",\"spikesLastStep\":"<<s.spikesLastStep
     <<",\"queuedEvents\":"<<s.queuedEvents<<",\"lastStepMs\":"<<s.lastStepMs
     <<",\"spikesPerSecond\":"<<s.spikesPerSecond<<",\"edgesPerSecond\":"<<s.edgesPerSecond
     <<",\"stepHz\":"<<s.stepHz<<",\"regionSpikesPerSecond\":[";
    for (size_t i=0;i<s.regionSpikesPerSecond.size();++i) { if(i) o<<','; o<<s.regionSpikesPerSecond[i]; }
    o<<"]"
     <<",\"cameraFramesPerSecond\":"<<s.cameraFramesPerSecond
     <<",\"visionFramesPerSecond\":"<<s.visionFramesPerSecond
     <<",\"visionFeaturesPerSecond\":"<<s.visionFeaturesPerSecond
     <<",\"visionInjectionsPerSecond\":"<<s.visionInjectionsPerSecond
     <<",\"audioChunksPerSecond\":"<<s.audioChunksPerSecond
     <<",\"audioBandsPerSecond\":"<<s.audioBandsPerSecond
     <<",\"audioInjectionsPerSecond\":"<<s.audioInjectionsPerSecond
     <<",\"touchEventsPerSecond\":"<<s.touchEventsPerSecond
     <<",\"touchInjectionsPerSecond\":"<<s.touchInjectionsPerSecond
     <<",\"imuEventsPerSecond\":"<<s.imuEventsPerSecond
     <<",\"imuChangesPerSecond\":"<<s.imuChangesPerSecond
     <<",\"imuInjectionsPerSecond\":"<<s.imuInjectionsPerSecond
     <<",\"environmentEventsPerSecond\":"<<s.environmentEventsPerSecond
     <<",\"environmentChangesPerSecond\":"<<s.environmentChangesPerSecond
     <<",\"environmentInjectionsPerSecond\":"<<s.environmentInjectionsPerSecond
     <<",\"locationEventsPerSecond\":"<<s.locationEventsPerSecond
     <<",\"locationInjectionsPerSecond\":"<<s.locationInjectionsPerSecond
     <<",\"externalTokensPerSecond\":"<<s.externalTokensPerSecond
     <<",\"externalInjectionsPerSecond\":"<<s.externalInjectionsPerSecond
     <<",\"currentAction\":"<<s.currentAction<<",\"actionEpoch\":"<<s.actionEpoch
     <<",\"motorMargin\":"<<s.motorMargin<<",\"motorDifferential\":"<<s.motorDifferential<<",\"reinforcedEpisodes\":"<<s.reinforcedEpisodes
     <<",\"memoryBytes\":"<<s.memoryBytes<<",\"mode\":"<<int(s.mode)<<"}";
    return o.str();
}

std::vector<uint8_t> BrainEngine::serializePlasticity() const {
    std::lock_guard lock(mutex_); std::vector<uint8_t> out;
    out.reserve(32 + motorDifferential_.size()*sizeof(float));
    appendBytes(out,kSerializationMagic); appendBytes(out,kSerializationVersion);
    appendBytes(out,cfg_.neurons); appendBytes(out,cfg_.fanout); appendBytes(out,cfg_.seed);
    const uint32_t n=static_cast<uint32_t>(motorDifferential_.size()); appendBytes(out,n);
    const auto* p=reinterpret_cast<const uint8_t*>(motorDifferential_.data()); out.insert(out.end(),p,p+n*sizeof(float));
    return out;
}

bool BrainEngine::restorePlasticity(std::span<const uint8_t> blob) {
    std::lock_guard lock(mutex_); size_t off=0; uint32_t magic=0,ver=0,n=0,fan=0; uint64_t neurons=0,seed=0;
    if(!readBytes(blob,off,magic)||!readBytes(blob,off,ver)||magic!=kSerializationMagic||ver!=kSerializationVersion) return false;
    if(!readBytes(blob,off,neurons)||!readBytes(blob,off,fan)||!readBytes(blob,off,seed)||!readBytes(blob,off,n)) return false;
    if(neurons!=cfg_.neurons||fan!=cfg_.fanout||seed!=cfg_.seed||n!=motorDifferential_.size()) return false;
    if(off+n*sizeof(float)>blob.size()) return false;
    std::memcpy(motorDifferential_.data(),blob.data()+off,n*sizeof(float)); return true;
}

double BrainEngine::benchmarkEdgeHash(uint64_t edges, uint64_t seed) {
    edges = std::max<uint64_t>(edges, 100000);
    volatile uint64_t sink=0; const auto t0=std::chrono::steady_clock::now();
    for(uint64_t i=0;i<edges;++i) sink ^= mix64(seed ^ i*0xD6E8FEB86659FD93ull);
    const auto t1=std::chrono::steady_clock::now(); (void)sink;
    const double sec=std::chrono::duration<double>(t1-t0).count(); return edges/std::max(sec,1e-9);
}

ScaleRecommendation BrainEngine::recommendScale(uint64_t memoryBudgetBytes, double measuredEdgesPerSecond,
                                                double targetHz, double assumedActiveFraction) {
    ScaleRecommendation r; r.memoryBudgetBytes=memoryBudgetBytes; r.measuredEdgeHashPerSecond=measuredEdgesPerSecond;
    constexpr double bytesPerNeuron=18.0; // dense state + differential output amortized; event queues excluded
    const uint64_t nMem=std::min<uint64_t>(kMaxNeurons, uint64_t(memoryBudgetBytes/bytesPerNeuron));
    auto nFor=[&](uint32_t k,double safety){
        const double denom=std::max(1.0,double(k)*assumedActiveFraction*targetHz);
        return std::min<uint64_t>(nMem,std::max<uint64_t>(1024,uint64_t(measuredEdgesPerSecond*safety/denom)));
    };
    // Balanced protects the validated K=1024 topology when possible.
    r.balancedFanout=1024; r.balancedNeurons=nFor(r.balancedFanout,0.40);
    // Max searches larger K, choosing the largest logical N*K that still fits compute/memory.
    uint64_t bestProduct=0; for(uint32_t k: {512u,1024u,2048u,4096u}) {
        const uint64_t n=nFor(k,0.65); const uint64_t p=n*uint64_t(k);
        if(p>bestProduct){bestProduct=p;r.maxNeurons=n;r.maxFanout=k;}
    }
    r.logicalConnectionsBalanced=r.balancedNeurons*uint64_t(r.balancedFanout);
    r.logicalConnectionsMax=r.maxNeurons*uint64_t(r.maxFanout); return r;
}

std::string recommendationJson(const ScaleRecommendation& r) {
    std::ostringstream o; o<<std::fixed<<std::setprecision(1)
      <<"{\"balancedNeurons\":"<<r.balancedNeurons<<",\"balancedFanout\":"<<r.balancedFanout
      <<",\"maxNeurons\":"<<r.maxNeurons<<",\"maxFanout\":"<<r.maxFanout
      <<",\"logicalConnectionsBalanced\":"<<r.logicalConnectionsBalanced
      <<",\"logicalConnectionsMax\":"<<r.logicalConnectionsMax
      <<",\"edgeHashPerSecond\":"<<r.measuredEdgeHashPerSecond
      <<",\"memoryBudgetBytes\":"<<r.memoryBudgetBytes<<"}"; return o.str();
}

} // namespace wb
