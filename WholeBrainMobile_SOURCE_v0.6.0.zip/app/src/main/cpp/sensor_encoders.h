#pragma once
#include <cstdint>
#include <span>
#include <vector>

namespace wb::enc {

// key semantics depend on the encoder:
// - visionFeatures: bits [15:0]=x, [31:16]=y, [39:32]=feature channel
// - audioBands: key = logarithmic band index
// - token/other helpers: hashed stable categorical key
struct RankedStimulus { uint64_t key; float magnitude; };

enum class VisionChannel : uint8_t {
    LumaOn = 0,
    LumaOff = 1,
    MotionOn = 2,
    MotionOff = 3,
    VerticalEdge = 4,
    HorizontalEdge = 5,
    ChromaUPos = 6,
    ChromaUNeg = 7,
    ChromaVPos = 8,
    ChromaVNeg = 9,
    Count = 10
};

constexpr uint32_t kVisionChannels = static_cast<uint32_t>(VisionChannel::Count);
constexpr uint32_t kAudioBands = 32;

uint64_t visionKey(uint32_t x, uint32_t y, VisionChannel channel);
uint32_t visionX(uint64_t key);
uint32_t visionY(uint64_t key);
uint32_t visionChannel(uint64_t key);

// pixels is either width*height grayscale bytes (legacy/tests) or interleaved
// Y,U,V bytes with length width*height*3 (mobile camera path).
std::vector<RankedStimulus> visionFeatures(std::span<const uint8_t> pixels,
                                          std::span<const uint8_t> previous,
                                          int width, int height,
                                          int maxFeatures = 768);

// Returns a sparse, level-normalized logarithmic spectrum. key is the band index,
// so adjacent frequencies remain adjacent in the Auditory region.
std::vector<RankedStimulus> audioBands(std::span<const int16_t> pcm,
                                      int sampleRate,
                                      int bands = static_cast<int>(kAudioBands),
                                      int keep = 16);

float audioRms(std::span<const int16_t> pcm);
uint64_t hashBytes(uint32_t channel, std::span<const uint8_t> bytes);
uint64_t quantizedVectorKey(int type, float x, float y, float z);
uint64_t geoKey(double latitude, double longitude, float speed, float bearing);

} // namespace wb::enc
