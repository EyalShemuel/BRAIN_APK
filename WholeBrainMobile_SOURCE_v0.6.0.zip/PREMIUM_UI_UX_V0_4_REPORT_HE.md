# WholeBrain Mobile v0.4.0 — Premium UI/UX

## עקרון מנחה
המסך בנוי קודם כל סביב משימת המשתמש, ורק אחר כך סביב הטלמטריה ההנדסית. מידע טכני נשאר זמין, אך אינו מתחרה בפעולות הראשיות.

## ניווט
- 4 יעדים ראשיים בלבד: Live / Teach / Memory / System.
- Brain ו-Device אוחדו תחת System כדי להפחית עומס בניווט התחתון.
- מצב המוח Observe/Learn/Act/Sleep נגיש תמיד מהכותרת העליונה.

## Live
- Hero אחד שמציג פעילות מוח כוללת ומצב פעולה.
- בחירת Input Profile פשוטה מתפריט אחד במקום שמונה כפתורים צפופים.
- כרטיסי חושים ברורים: Vision / Audio / Touch / Motion, עם Environment / Location / External בהרחבה.
- תצוגת מצלמה רק כאשר Vision פעיל, עם FPS ברור.
- דיאגנוסטיקה טכנית מוסתרת כברירת מחדל ונפתחת לפי דרישה.
- משטח Touch ייעודי: לחיצות על UI אינן מוזרקות למוח ולכן אינן מזהמות את הקלט הסומטוסנסורי.

## Teach
- מסך ממוקד בהחלטה האחרונה בלבד.
- שני כפתורי משוב גדולים וברורים Good / Wrong.
- המשוב מושבת אוטומטית כאשר אין החלטה או כאשר Learn כבוי.
- מעבר מהיר ל-Learn מתוך המסך.

## Memory
- שמירה ושחזור עברו למקום הטבעי מבחינת המשתמש: Memory.
- סטטוס הפלסטיות מוצג בשפה ברורה, עם הפרדה מטענות capacity.

## System
- Brain: runtime + scientific boundary + פעילות 15 האזורים עם bars.
- Device: permissions, scale, outputs, background runtime.
- Hardware details מוסתרים עד שהמשתמש מבקש אותם.

## Design system
- רקע ניטרלי בהיר, surface לבן, teal ממותן כצבע מותג.
- פינות 18–28dp, היררכיית טקסט חזקה, פחות מסגרות ורעש.
- touch targets גדולים, contrast ברור, dark mode מלא.
- Material icons במקום נקודות/סימנים דקורטיביים.

## Scientific/UX correction
אירועי Touch נאספים רק ממשטח החישה הייעודי. לחיצה על כפתור, ניווט, Teach או Device אינה נתפסת עוד כחוש מגע של המוח. בכך נמנעת זליגת control-plane אל sensory-plane.

## Validation
Host scientific/sensory regression after UI refactor:
- topology_adj=11
- visual20=136
- visual250=304
- audio_sps=2100
- touch_sps=199
- mixed_spikes=4243
- learning seed77 post=1.000
- learning seed78 post=1.000
- learning seed79 post=1.000

Android compilation is delegated to GitHub Actions because the local container does not contain the Android SDK/Gradle toolchain.
