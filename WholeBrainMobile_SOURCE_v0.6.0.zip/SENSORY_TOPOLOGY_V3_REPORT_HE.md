# WholeBrain Mobile 0.3.0 — Sensory Topology v3

תאריך: 2026-09-14

## מטרת השינוי

גרסה 0.2 הוכיחה שהחיישנים מחוברים למנוע, אך גילתה כשל מבני: חלק מהחושים הומרו למספר קטן וקבוע של נוירונים אקראיים. כאשר המוח גדל ל־250K נוירונים, אותו קלט נעשה דליל יחסית, שכנות מרחבית/תדרית אבדה, ומיפוי החוש השתנה עם גודל המוח.

ב־0.3.0 הוחלף front-end החושי למיפוי **מקומי, יציב ו־scale-stable**. מסלול הלמידה המדעי channel 9 נשמר במדויק כדי לא לשבור את רגרסיית CORE53.

## חלוקת אזורים ב־250K נוירונים

| אזור | נוירונים |
|---|---:|
| Visual | 24,647 |
| Auditory | 16,902 |
| Somatosensory | 12,676 |
| Association | 41,550 |
| Hippocampus | 21,127 |
| PFC | 24,647 |
| Thalamus | 8,451 |
| Cerebellum | 20,423 |
| Semantic | 12,676 |
| Brainstem | 4,226 |

## ראייה — Retinotopic Vision

המצלמה מומרת לרשת רטינלית 64×36 = 2,304 תאים. כל תא מקבל דגימת Y/U/V ב־3×3 נקודות מתוך שטח התא המקורי, ולא פיקסל יחיד. התמונה מתוקנת לפי `rotationDegrees`, כך שהמיקום הוויזואלי נשאר עקבי בין orientation של חיישן המצלמה לבין התצוגה.

לכל תא רטינלי 10 roles קבועים:
1. luminance ON
2. luminance OFF
3. temporal ON
4. temporal OFF
5. vertical edge
6. horizontal edge
7. U chroma +
8. U chroma −
9. V chroma +
10. V chroma −

ב־250K קיימים כ־10.7 נוירוני Visual לכל תא רטינלי — התאמה כמעט ישירה ל־10 roles. תאים שכנים בתמונה מקבלים micro-columns שכנים באזור Visual. אין hash של `(x,y)`.

עד 768 features חזקים נשמרים בכל retinal frame, עם quota נפרד לכל ערוץ כדי שתנועה/בהירות לא ידרסו צבע וקצוות. גם תמונה סטטית מובנית מייצרת קלט; המערכת אינה motion-only.

## שמיעה — Tonotopic Audio

קלט המיקרופון הוא PCM mono 16 kHz, חלונות של 512 דגימות (~32 ms). האפליקציה מנסה קודם `UNPROCESSED`, ואם החומרה לא תומכת היא נופלת ל־`VOICE_RECOGNITION` ואז `MIC`.

הספקטרום מיוצג ב־32 bands לוגריתמיים ~80 Hz עד Nyquist שימושי. שקט מתחת לכ־−58 dBFS נדחה. בכל chunk נשמרים עד 16 bands משמעותיים.

band נמוך ממופה לחלק נמוך סמוך של Auditory ו־band גבוה לחלק גבוה יותר. ב־250K יש כ־528 נוירוני Auditory לכל band. אין hash אקראי של תדר.

## טאץ' — Somatotopic Touch

המסך מחולק ל־32×18 = 576 תאי מגע. כל תא ממופה ל־micro-column סמוך ב־Somatosensory; ב־250K יש כ־22 נוירונים לכל תא.

roles:
- contact onset
- sustained contact
- pressure
- X+ / X− motion
- Y+ / Y− motion
- release

נשלחים אירועי down/move/up, והלחץ האמיתי של `PointerInputChange.pressure` משמש כאשר המכשיר מספק אותו.

## IMU / ג'יירוסקופ / מגנטומטר / Orientation

המערכת אינה מזינה gravity/DC שוב ושוב. נשמרת הדגימה הקודמת לכל sensor type ונשלח רק delta משמעותי.

8 משפחות תנועה × 3 axes × 2 polarities = 48 channels מסודרים. כל sensor family מקבל normalization לפי היחידות שלו (rad/s, m/s², µT, degrees/rotation-vector). כל channel מגיע לאזור מסודר ב־Somatosensory וב־Cerebellum, עם event coarse ל־Brainstem.

ב־250K: כ־264 נוירוני S1 וכ־425 נוירוני Cerebellum זמינים לכל channel לפני בחירת population sparse.

## חיישני סביבה / גוף

חיישנים נתמכים כוללים light, pressure, ambient temperature, proximity, humidity, step/significant-motion/gesture families, heart rate, hinge angle ועוד sensor types מוכרים. כל sensor מנורמל ביחידותיו שלו. sensor type לא מוכר לא מוזרק כ־DC לא מכויל.

ערך יציב חוזר אינו יוצר burst חדש; level/change channels נפרדים. Thalamus מקבל context סביבתי, Somatosensory מקבל שינוי, Battery/Thermal ממופים ל־Brainstem כ־interoception.

חיישני one-shot נרשמים דרך `TriggerEventListener` ונרשמים מחדש לאחר trigger. חיישני IMU עובדים בקצב GAME; חיישני סביבה בקצב NORMAL.

## GPS — multi-scale place code

Latitude/longitude מומרים בקירוב למטרים ומקודדים בשלושה scales: 200m, 50m, 10m, בשלושה banks של Hippocampus. ב־250K כל bank מכיל כ־7,042 נוירונים. מהירות/כיוון מקודדים גם ל־Cerebellum/Thalamus.

## NFC / USB / Bluetooth / BLE / Network context

ערוצי זהות חיצוניים הם categorical ולכן hash של הזהות מותר, אך הוא נכנס ל־subrange קבוע ויחסי לגודל האזור במקום modulo על כל האזור. Semantic מחולק ל־16 banks (~792 נוירונים/bank ב־250K) ו־Association ל־16 banks (~2,597/bank).

- NFC: tag id כשהאפליקציה פתוחה.
- USB: connected device identities + attach/detach.
- Bluetooth: bonded devices + BLE low-power scan כאשר יש permission; RSSI bucket עם dedupe.
- Network: Wi-Fi/cellular/ethernet/Bluetooth/offline context בלבד; אין INTERNET permission.

UWB מזוהה כיכולת חומרה בלבד בשלב זה; ranging דורש peer/session configuration ולכן אינו מוזרק כאילו הוא חיישן פעיל.

## יציבות מדעית

channel 9, המשמש scientific/teaching cue, נשמר במסלול הישן המדויק. לאחר שינוי כל ה־front-end החושי נבדקה שוב למידת reward:

- seed 77: 0.4375 → 1.000
- seed 78: 0.4875 → 1.000
- seed 79: 0.4750 → 1.000

כלומר שינוי החושים לא שבר את רגרסיית הלמידה המאומתת.

## בדיקות host — PASS

ה־host suite בודק בין השאר:
- topographic adjacency ו־scale stability
- Vision static ignition ב־20K וב־250K ללא dilution פי 12.5
- temporal visual transition
- explicit chroma feature
- audio silence rejection
- 440 Hz מול 1760 Hz: תדר גבוה → band גבוה
- Auditory direct ignition ללא recurrent amplification
- Touch contact/move/release
- IMU DC rejection + acceleration delta
- environmental calibrated injection + repeated stable level without a new spike burst
- GPS place injection
- external/NFC distributed injection
- mixed-sensor save/restore
- 3-seed reward-learning regression

פלט אחרון:

```text
PASS topology_adj=11 visual20=136 visual250=304 audio_sps=2100 touch_sps=199 mixed_spikes=4243
seed77 post=1.0
seed78 post=1.0
seed79 post=1.0
```

## גבול הטענה

PASS זה הוא host-native. גרסת Android 0.3.0 עדיין חייבת לעבור build CI והתקנה/מדידה במכשיר אמיתי. גם לאחר מכן K1024 הוא runtime engineering scale ולא אימות מדעי של יכולת K1024; הגבול המדעי המאומת נשאר K6 עד ניסוי capacity ייעודי.
