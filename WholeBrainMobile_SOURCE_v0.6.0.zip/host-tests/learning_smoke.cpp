#include "wholebrain_engine.h"
#include <iostream>
#include <vector>
#include <string>

int main(int argc,char**argv){
    int seed=argc>1?std::atoi(argv[1]):77;
    wb::EngineConfig c; c.neurons=30000; c.fanout=64; c.seed=seed; c.sensorGain=3.0f; c.motorGain=12.f; c.learningRate=.003f; c.actionWindowTicks=8;
    wb::BrainEngine e(c); e.setMode(wb::RunMode::Learn);
    auto trial=[&](const char* token,int target,bool learn){
        std::vector<uint8_t> b(token,token+std::char_traits<char>::length(token));
        e.injectToken(9,b);
        for(int i=0;i<8;i++) e.step();
        int a=e.stats().currentAction;
        bool ok=a==target;
        if(learn) e.reward(ok);
        return ok;
    };
    int pre=0;for(int i=0;i<80;i++){pre+=trial(i%2?"B":"A",i%2, false);}
    for(int i=0;i<800;i++){trial(i%2?"B":"A",i%2,true);}
    int post=0;for(int i=0;i<160;i++){post+=trial(i%2?"B":"A",i%2,false);}
    auto s=e.stats();
    std::cout<<"pre="<<pre/80.0<<" post="<<post/160.0<<" d="<<s.motorDifferential<<" updates="<<s.reinforcedEpisodes<<" spikes="<<s.spikesTotal<<"\n";
    return post>=144?0:2;
}
