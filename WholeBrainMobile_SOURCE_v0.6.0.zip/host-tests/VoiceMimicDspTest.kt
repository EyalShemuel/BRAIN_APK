package com.eyalshemuel.wholebrainmobile.output

import kotlin.math.PI
import kotlin.math.sin

fun main() {
    val sr = 16_000
    val seconds = 3
    val f0 = 132.0
    val samples = ShortArray(sr * seconds) { i ->
        val t = i.toDouble() / sr
        val env = 0.75 + 0.25 * sin(2 * PI * 2.2 * t)
        val v = 0.52 * sin(2 * PI * f0 * t) + 0.18 * sin(2 * PI * f0 * 2 * t) + 0.08 * sin(2 * PI * 900.0 * t)
        (v * env * 26000).toInt().coerceIn(-32768,32767).toShort()
    }
    val p = VoiceMimicDsp.analyze(samples, sr)
    check(p.pitchHz in 120f..145f) { "pitch=${p.pitchHz}" }
    check(p.rms > 0.1f)
    check(p.fingerprint.all { it in 0.45f..2.2f })
    val mul = VoiceMimicDsp.ttsPitchMultiplier(p, 1f)
    check(mul in 0.62f..1.55f)
    val self = VoiceMimicDsp.acousticMatch(p, p)
    check(self > 0.99f) { "self=$self" }
    println("PASS voice_mimic pitch=${p.pitchHz} rms=${p.rms} zcr=${p.zcr} fp=${p.fingerprint} ttsPitch=$mul self=$self")
}
