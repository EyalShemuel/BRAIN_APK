#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/dist"; mkdir -p "$OUT"
APK_SRC="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
test -f "$APK_SRC"
cp "$APK_SRC" "$OUT/WholeBrainMobile-debug.apk"
cp "$APK_SRC" "$OUT/WholeBrainMobile-0.6.0-AuthorizedVoiceMimic-debug.apk"
sha256sum "$OUT/WholeBrainMobile-debug.apk" > "$OUT/WholeBrainMobile-debug.apk.sha256"
sha256sum "$OUT/WholeBrainMobile-0.6.0-AuthorizedVoiceMimic-debug.apk" > "$OUT/WholeBrainMobile-0.6.0-AuthorizedVoiceMimic-debug.apk.sha256"
