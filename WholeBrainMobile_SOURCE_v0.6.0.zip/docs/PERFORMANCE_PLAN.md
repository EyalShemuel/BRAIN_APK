# Performance and scaling

## What is optimized

The app tries to maximize useful logical scale under three constraints: memory, edge-event throughput, and thermal stability. `N×K` alone is not an objective if the brain misses real-time deadlines.

## Calibration model

At launch the native library benchmarks deterministic edge hashing. The recommendation assumes a conservative active fraction and target update rate and intersects that compute estimate with a native-memory budget.

The UI shows Balanced and Max separately. Max is an experimental profile, not a validated operating point.

## Runtime telemetry

The native engine reports neurons, logical synapses, spikes/s, edge events/s, queued events, native memory, step latency, motor margin and plastic-update episodes.

When Android reports severe thermal status the scheduler skips steps instead of modifying topology or learned weights behind the user's back.

## Next optimization after CPU certification

Vulkan compute is deliberately postponed until a locked CPU parity fixture exists. The intended GPU design is batched procedural target generation + on-device event reduction; it must reproduce the CPU spike/state certificate before it can become a default backend.
