# GitHub handoff

The repository is ready to push. The connected GitHub identity is visible to ChatGPT, but the GitHub App currently exposes no repository installation, so this session cannot create or write a remote repository yet.

Recommended repository name: `WholeBrainMobile`.

Once an empty repository exists under the desired account and the ChatGPT GitHub connection is granted access to it, the committed source in this package can be pushed without regeneration. The default branch is `main`.

GitHub Actions is already configured in `.github/workflows/android.yml` to:

1. run native host gates;
2. install Android SDK 37 / Build Tools 36.0.0 / NDK 28.2.13676358;
3. use JDK 17 and Gradle 9.6.0;
4. build `:app:assembleDebug`;
5. publish `WholeBrainMobile-debug.apk` and its SHA-256 as the `wholebrain-mobile-debug-apk` artifact.
