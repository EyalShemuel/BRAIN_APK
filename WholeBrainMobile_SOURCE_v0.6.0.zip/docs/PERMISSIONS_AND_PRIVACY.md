# Permissions and privacy

The application has no INTERNET permission.

Requested only after the user taps **Enable available sensors**:
- Camera
- Microphone
- Fine/coarse location
- Bluetooth scan/connect on Android 12+
- Notifications on Android 13+
- Activity recognition (for step sensors where required)
- Optional heart-rate sensor: `BODY_SENSORS` through API 35 or `android.permission.health.READ_HEART_RATE` on Android 16+

The app attempts to register non-one-shot SensorManager sensors while visible and safely ignores sensors the OS refuses. Heart-rate input is optional and follows the Android 16 granular-health permission plus an in-app privacy/rationale screen. Other health-record categories are not requested because they are not generic passive phone sensors in this app.

Camera and microphone stop when the Activity stops. A foreground service can keep the native runtime alive, but v0.1 does not silently keep camera/microphone capture alive in the background.


The optional background runtime is user-started and declared as Android `specialUse`; it keeps only the local native brain runtime alive. Camera and microphone remain Activity-scoped in v0.1.
