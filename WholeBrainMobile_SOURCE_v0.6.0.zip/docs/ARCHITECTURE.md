# Architecture

## Data path

`Sensors → sparse encoders → 15-region event-driven SNN → Association state → differential opponent Motor → Android OutputRouter`

A human or environment can return reward. Positive reward leaves the current mapping unchanged. Negative reward applies the CORE53 push-pull correction to the most recent Association trace.

## Regions

Relative region widths follow the 355-unit Native Speech layout:

Visual 35, Auditory 24, Language 47, Somatosensory 18, Association 59, Hippocampus 30, PFC 35, Basal Ganglia 18, Thalamus 12, Cerebellum 29, Motor 12, Vocal Motor 6, Semantic 18, Neuromod 6, Brainstem 6.

The ratios are scaled to the chosen neuron count.

## Recurrent topology

Every spike regenerates outgoing targets from `(seed, source, slot)` via SplitMix64. By default 87.5% of slots target the source region and 12.5% target the whole network. Delays are deterministic 1–8 ticks.

There is no recurrent edge table. Runtime work is approximately proportional to `spikes × K`.

## Event-driven LIF

Membrane leak is lazy: a neuron is decayed only when an event reaches it. Only touched neurons are threshold-tested. This avoids an O(N) scan on every tick and is the key mobile-scaling property.

## Motor

The old output organ lost a small decision signal inside a large common mode. The mobile engine stores the equivalent differential weight `d_i = W_i0 - W_i1`, bounded to `[-2,2]` with the implicit invariant `W_i0 + W_i1 = 2`.

On a negative reward:

- wrong action 0: `d_i ← clamp(d_i - 2 η x_i)`
- wrong action 1: `d_i ← clamp(d_i + 2 η x_i)`

This is algebraically equivalent to the validated non-negative CORE53 two-weight push-pull update.

Motor pools are isolated from unrelated procedural recurrent arrivals in v0.1 so the differential signal is not re-contaminated by random common-mode input.

## Sensor encoders

- Vision: low-resolution luminance + temporal change, top sparse features.
- Audio: local log-spaced Goertzel spectral bands (mel-like; not claimed as exact log-Mel parity yet).
- IMU/environment: quantized vector population keys.
- Touch: coordinate/pressure population code.
- Location: coarse quantized local geokey injected into Hippocampus/Semantic; no location is transmitted externally.
- NFC/USB/Bluetooth context: local token hashes.

## Persistence

Only plastic Motor differentials are serialized. Transient membrane/event state is intentionally not treated as long-term memory.
