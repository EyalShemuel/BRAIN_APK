# Scientific / engineering gates

A larger number is not accepted as progress unless its upstream gates pass.

| Gate | Requirement | v0.1 status |
|---|---|---|
| G0 | Native C++ deterministic hash/topology primitives | PASS (host test) |
| G1 | CORE53 error-update algebra parity | PASS (host test) |
| G2 | Native engine smoke: sensors→spikes→events, save/restore, no phantom actions | PASS (host test) |
| G2b | Reward-learning surrogate: 3 independent seeds, >=0.90 post-training | PASS (1.00 / 1.00 / 1.00) |
| G3 | Android project compiles + APK generated | CI/local build gate |
| G4 | Capability discovery and permission-denial survival | device test required |
| G5 | CPU Android vs Python CLEAN CORE spike/state parity on a small locked fixture | NOT YET CERTIFIED |
| G6 | K=6 Android behavioral regression, 3 seeds + reverse + non-contingent control | NOT YET CERTIFIED |
| G7 | 30-minute sustained thermal/latency run | device test required |
| G8 | Vulkan backend CPU parity | not implemented; CPU is production backend |
| G9 | Scale > validated K/N | experimental only |

No Android result may be used as a scientific capacity claim before G5 and G6.
