# WholeBrain Mobile v0.3.2 — device findings

תיקונים שנגזרו מהבדיקה על מכשיר אמיתי:

1. המצלמה נקשרה קודם רק כאשר PreviewView שבתוך LazyColumn הורכב בפועל. לכן camera/retinal/Visual היו 0 כל עוד המשתמש לא גלל עד ה-preview. v0.3.2 מפעילה ImageAnalysis כבר ב-onStart, ללא תלות ב-UI.
2. Android חשף מספר חיישני IMU חופפים (calibrated/uncalibrated/gravity/linear/game rotation וכו'), וכל אחד נרשם ב-SENSOR_DELAY_GAME. זה יצר ~595 events/s ו-~7.2K injections/s. v0.3.2 בוחרת canonical set: accelerometer, gyroscope, rotation vector, magnetometer בלבד.
3. מדדי regionSpikesPerSecond הם פעילות כוללת באזור אחרי recurrent mixing, לא attribution לחוש מסוים. הטקסט ב-UI תוקן ל-total, בעוד inject/s נשאר מדד הקלט הישיר.
