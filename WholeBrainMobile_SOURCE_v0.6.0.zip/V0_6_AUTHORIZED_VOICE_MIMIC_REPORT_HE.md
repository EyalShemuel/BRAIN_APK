# WholeBrain Mobile v0.6.0 — Authorized Voice Mimic

## מטרה

להוסיף לפלט הקולי המקומי של v0.5 שכבת חיקוי קול **מורשית בלבד**, ללא ענן וללא הרשאת `INTERNET`, תוך שמירה על ה-Neural View 1:1 ועל רגרסיית הלמידה המאומתת.

## גבול היכולת

v0.6 היא שכבת **acoustic voice mimic** מקומית מעל מנוע ה-TTS שמותקן במכשיר. היא מתאימה:

- pitch / fundamental frequency,
- מעטפת ספקטרלית גסה / timbre,
- dynamics,
- ומודדת acoustic-profile match מול דגימת הייחוס.

היא **אינה** מודל neural zero-shot speaker cloning כדוגמת XTTS/YourTTS, ולכן אינה מוצגת כ-clone זהות באיכות אולפן. הבחירה מכוונת: הפרויקט נשאר self-contained/offline וללא model weights חיצוניים גדולים.

## Enrollment והרשאה

חיקוי הקול אינו יכול להיות מופעל ללא enrollment מפורש. במסך Voice המשתמש חייב לסמן:

> I confirm this is my voice, or I have explicit permission from the speaker to create a local voice mimic profile.

רק לאחר מכן ניתן להקליט 4–12 שניות של דיבור טבעי.

## פרטיות

- דגימת המיקרופון נכתבת זמנית ל-cache בלבד.
- לאחר הפקת הפרופיל האקוסטי, קובץ ה-PCM הגולמי נמחק מיד.
- נשמרים רק מאפיינים קומפקטיים: pitch, voiced fraction, ZCR ו-4 תחומי spectral envelope.
- `wholebrain-voice-mimic.xml` מוחרג מ-Android cloud backup ומ-device transfer.
- אין `INTERNET` permission.

## תיאום עם חישת השמיעה של המוח

בזמן enrollment, `SensorHub` משהה את `AudioBrainCapture` כדי למנוע שני `AudioRecord` מתחרים. בסיום enrollment ערוץ השמיעה של המוח חוזר אוטומטית.

## מסלול הפלט

```text
Brain Motor/Vocal Motor
  -> learned action phrase
  -> local Android offline TTS
  -> pitch target from authorized profile
  -> local 4-band timbre/spectral-envelope match
  -> soft limiter
  -> local playback
  -> real waveform + output fingerprint + acoustic match
```

## ויזואליזציה

מסך Voice מציג:

- waveform של הקובץ המסונתז בפועל,
- pitch היעד מה-reference,
- 4-band fingerprint: Low / Mid / Presence / High,
- reference מול הפלט האחרון,
- acoustic match באחוזים.

ה-match הוא מדד אקוסטי בלבד ואינו אימות זהות של אדם.

## בדיקות

נוספה בדיקת host pure-Kotlin ל-`VoiceMimicDsp.kt`:

- איתור pitch מאות סינתטי,
- fingerprint בתחום חוקי,
- pitch multiplier בתחום בטוח,
- self-match > 0.99.

בנוסף כל בדיקות המנוע והלמידה הקיימות ממשיכות לרוץ ללא שינוי.

## קריטריוני הצלחה על מכשיר

1. enrollment לא מתחיל ללא checkbox הרשאה.
2. enrollment של 4–12 שניות מפיק pitch/fingerprint.
3. raw reference מוצג כ-`retained: No`.
4. הפעלת mimic משנה את הפלט המקומי ומעדכנת output fingerprint.
5. כיבוי mimic מחזיר TTS רגיל.
6. מחיקת profile מבטלת mimic ומוחקת את הנתונים המתמידים.
7. AudioBrainCapture חוזר לפעול לאחר enrollment.
8. אין קריאת רשת ואין INTERNET permission.
