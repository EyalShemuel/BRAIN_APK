# WholeBrain Mobile v0.5.0 — Voice + Exact Neural View

## מטרה

v0.5 מוסיפה שלושה רכיבים בלי לשנות את מסלול הלמידה המאומת:

1. פלט קולי מקומי דרך Android TextToSpeech, ללא הרשאת INTERNET.
2. חיבור Motor Action 1/2 לשתי אמירות שהמשתמש מגדיר.
3. Neural View אמיתי, שבו כל נקודה היא neuron ID שבאמת ירה וכל קו הוא recurrent edge שבאמת נשלח באותו timestep.

## Neural View — מה בדיוק 1:1

המנוע שומר trace רק כאשר Neural View פתוח. לכל timestep נשמרים:

- כל neuron IDs שירו.
- כל recurrent edges שנשלחו כתוצאה מהספייקים האלה.
- source neuron.
- target neuron.
- delay.
- excitatory/inhibitory sign.

נשמרים 20 timesteps אחרונים. אין sampling ואין יצירת אנימציה מלאכותית במסך הזה.

כאשר Neural View סגור tracing כבוי וה־deque נמחק, ולכן אין overhead קבוע למסלול המדעי הרגיל.

## פלט קולי

`SpeechOutputEngine` משתמש ב־Android TextToSpeech אך בוחר רק Voice שעבורו:

`isNetworkConnectionRequired == false`

האפליקציה אינה מבקשת `android.permission.INTERNET`.

הקול מסונתז לקובץ מקומי ולאחר מכן מנוגן. הסיבה לכך היא שה־waveform המוצג במסך Voice נגזר מהקובץ שבאמת נוצר, ולא מאנימציה דקורטיבית.

## Brain → Voice

OutputRouter מאפשר למשתמש להפעיל Voice output. במצב Act, כאשר המוח בוחר Action 1 או Action 2, ניתן להשמיע את המשפט המוגדר עבור אותה פעולה.

ברירת מחדל:

- Action 1 → Yes
- Action 2 → No

המשפטים נשמרים ב־SharedPreferences.

## v0.6

Voice cloning אינו נטען ב־v0.5. v0.6 מיועדת לשכבת חיקוי קול מורשית בלבד, שתתחבר לאותו SpeechOutputEngine/Voice UI. אין ב־v0.5 טענה שה־TTS הנוכחי הוא קול משוכפל.

## בדיקות host

התווסף gate חדש ל־host test:

- tracing enabled → neuronCount > 0.
- edgeCount > 0.
- מספר ה־edges ב־trace שווה בדיוק ל־delta של `edgeEventsTotal` באותו step.
- כל source של edge נמצא ברשימת הנוירונים שירו.
- target תקין.
- delay בתחום.
- sign הוא ±1.
- היסטוריית timestep קיימת.
- לאחר כיבוי trace אין trace נגיש.

בנוסף כל בדיקות החושים והלמידה הוותיקות ממשיכות לעבור.
