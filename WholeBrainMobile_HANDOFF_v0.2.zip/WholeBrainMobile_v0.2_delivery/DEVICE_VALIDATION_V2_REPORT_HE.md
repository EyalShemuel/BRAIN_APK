# WholeBrain Mobile 0.2.0 — Device Validation v2

בוצע:
- VISION / AUDIO / IMU / ALL input isolation.
- מדידת Camera frames, processed Vision frames, features, injections.
- מדידת Audio chunks, bands, injections.
- מדידת IMU raw events ו-meaningful delta changes.
- spikes/s אמיתי לכל 15 אזורי המוח.
- ה-Live orbit מייצג פעילות אזורית אמיתית ולא אנימציה דקורטיבית.
- visionGain=1.30, audioGain=1.15, imuGain=1.10; sensorGain הכללי נשאר 0.80.
- Vision encoder הפך motion-dominant עם sqrt temporal compression; luminance סטטי נשאר weak context.
- IMU מקודד delta ומסנן DC/gravity/noise מתחת לסף 0.03 normalized.
- edge events/s מבוסס על recurrent edges שנקבעו בפועל ולא spikes×K.
- UI: safe status-bar inset, תיקון Background button, Available במקום Ready, והפרדה מפורשת בין K6 validated לבין runtime K experimental.

בדיקות מקומיות:
- C++ host compile: PASS.
- deterministic topology / CORE53 update tests: PASS.
- no phantom motor action: PASS.
- visual black→white isolated ignition: PASS.
- IMU identical/DC rejection: PASS.
- IMU movement delta → Somatosensory spikes: PASS.
- learning smoke seeds 77/78/79: pre≈chance → post=1.000: PASS.

טרם בוצע במשלוח המקומי:
- Android Gradle/NDK compile של v0.2 — מיועד ל-GitHub Actions workflow המצורף.
- on-device validation של v0.2.
