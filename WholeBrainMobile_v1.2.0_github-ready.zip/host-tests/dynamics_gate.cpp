// Network dynamics gate.
//
// Every gate in the v1.0 suite passed on a cortex that never fired: the laminar checks
// asserted that lookup tables return their own constants, and the "stability" check passed
// because a silent network queues nothing. This gate is written the other way round - each
// assertion below FAILS on the v1.0 engine as shipped, and fails again if the network is
// pushed into runaway.
#include "wholebrain_engine.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>

using namespace wb;

struct Run {
    double drivenRate = 0.0;
    double persistRate = 0.0;
    double populationCv = 0.0;
    double branchingSigma = 0.0;
    uint64_t peakMemory = 0;
    uint64_t L[5]{}, C[7]{}, coincidences = 0;
};

static Run run(uint64_t neurons, int warm, int measure, int silent) {
    EngineConfig c;
    c.neurons = neurons;
    c.fanout = 128;
    c.seed = 4242;
    c.sensorGain = 3.0f;
    BrainEngine e(c);
    e.setMode(RunMode::Learn);

    std::vector<uint8_t> frame(64 * 64);
    std::vector<int16_t> pcm(512);
    auto drive = [&](int t) {
        if (t % 3 == 0) {
            for (size_t i = 0; i < frame.size(); ++i) frame[i] = uint8_t((i * 7 + t * 13) & 0xFF);
            e.injectVision(frame, 64, 64);
        }
        if (t % 5 == 0) {
            for (size_t i = 0; i < pcm.size(); ++i) pcm[i] = int16_t(9000 * std::sin(0.05 * i + t));
            e.injectAudio(pcm, 16000);
        }
    };

    Run r;
    for (int t = 0; t < warm; ++t) { drive(t); e.step(); }

    const auto a = e.stats();
    std::vector<double> hist;
    hist.reserve(measure);
    for (int t = 0; t < measure; ++t) {
        drive(warm + t);
        e.step();
        const auto s = e.stats();
        hist.push_back(s.spikesLastStep);
        r.peakMemory = std::max(r.peakMemory, s.memoryBytes);
    }
    const auto b = e.stats();
    r.drivenRate = double(b.spikesTotal - a.spikesTotal) / (double(neurons) * (measure * 0.01));

    double m = 0.0;
    for (double x : hist) m += x;
    m /= double(hist.size());
    double v = 0.0;
    for (double x : hist) v += (x - m) * (x - m);
    r.populationCv = m > 0.0 ? std::sqrt(v / double(hist.size())) / m : 0.0;

    // Sensory input removed. Tonic background tone remains, as it does in vivo.
    std::vector<double> quiet;
    quiet.reserve(silent);
    for (int t = 0; t < silent; ++t) {
        e.step();
        const auto s = e.stats();
        quiet.push_back(s.spikesLastStep);
        r.peakMemory = std::max(r.peakMemory, s.memoryBytes);
    }
    const auto d = e.stats();
    r.persistRate = double(d.spikesTotal - b.spikesTotal) / (double(neurons) * (silent * 0.01));

    double sigma = 0.0;
    int n = 0;
    for (size_t i = 1; i < quiet.size(); ++i) {
        if (quiet[i - 1] > 0.0) { sigma += quiet[i] / quiet[i - 1]; ++n; }
    }
    r.branchingSigma = n ? sigma / n : 0.0;

    for (int i = 0; i < 5; ++i) r.L[i] = d.corticalLayerSpikes[i];
    for (int i = 0; i < 7; ++i) r.C[i] = d.corticalCellSpikes[i];
    r.coincidences = d.corticalDendriticCoincidences;
    return r;
}

int main() {
    // 1. Mean recurrent drive must be inhibition-dominated. With an 80/20 split an
    //    excitatory-dominated mean field has no stable operating point - it is silent or it
    //    ignites, with nothing in between. This is a config invariant, checked first because
    //    every dynamical property below depends on it.
    {
        EngineConfig c;
        const double meanDrive = double(c.excitatoryFraction) * double(c.excitatoryWeight)
                               - (1.0 - double(c.excitatoryFraction)) * double(c.inhibitoryWeight);
        assert(meanDrive < 0.0);
    }

    std::printf("%-9s | %-8s %-8s %-6s %-6s | %-7s %-7s %-7s %-7s %-7s | %-7s %-7s | %-9s %s\n",
                "neurons", "driven", "persist", "CV", "sigma",
                "L1", "L2/3", "L4", "L5", "L6", "ET", "CT", "coinc", "memMB");

    std::vector<double> rates;
    for (uint64_t n : {30000ull, 120000ull, 250000ull}) {
        const Run r = run(n, 400, 400, 300);
        rates.push_back(r.drivenRate);

        std::printf("%-9llu | %-8.3f %-8.3f %-6.2f %-6.3f | %-7llu %-7llu %-7llu %-7llu %-7llu | %-7llu %-7llu | %-9llu %.1f\n",
                    (unsigned long long)n, r.drivenRate, r.persistRate, r.populationCv, r.branchingSigma,
                    (unsigned long long)r.L[0], (unsigned long long)r.L[1], (unsigned long long)r.L[2],
                    (unsigned long long)r.L[3], (unsigned long long)r.L[4],
                    (unsigned long long)r.C[1], (unsigned long long)r.C[2],
                    (unsigned long long)r.coincidences, r.peakMemory / 1e6);

        // 2. The laminar cascade must actually run. On v1.0 every spike was a sensory
        //    injection landing in L4 and nothing propagated: L2/3, L5, ET and CT were all
        //    exactly zero at 250k, and the apical coincidence mechanism fired zero times
        //    despite a million apical events being delivered.
        assert(r.L[static_cast<size_t>(CorticalLayer::L23)] > 0);
        assert(r.L[static_cast<size_t>(CorticalLayer::L5)] > 0);
        assert(r.L[static_cast<size_t>(CorticalLayer::L6)] > 0);
        assert(r.C[static_cast<size_t>(CorticalCellClass::ET)] > 0);
        assert(r.C[static_cast<size_t>(CorticalCellClass::CT)] > 0);
        assert(r.coincidences > 0);

        // 3. Activity must survive removal of sensory input, and must not explode either.
        assert(r.persistRate > 0.02);
        assert(r.branchingSigma > 0.80 && r.branchingSigma < 1.25);

        // 4. Asynchronous, not a synchronous burst train.
        assert(r.populationCv < 0.90);

        // 5. Firing rate in a physiological band rather than silent or saturated.
        assert(r.drivenRate > 0.05 && r.drivenRate < 20.0);

        // 6. Memory is bounded by the per-neuron accumulator, not by spikes x fanout.
        assert(r.peakMemory < 120ull * 1000ull * 1000ull);
    }

    // 7. Scale invariance. v1.0 flipped from runaway at 60k to silent at 120k with the same
    //    weights, because local convergence was never normalised. The operating point must
    //    not depend on how big the network is.
    double lo = rates[0], hi = rates[0];
    for (double x : rates) { lo = std::min(lo, x); hi = std::max(hi, x); }
    assert(hi / lo < 3.0);

    std::printf("PASS dynamics_gate scale_spread=%.2fx\n", hi / lo);
    return 0;
}
