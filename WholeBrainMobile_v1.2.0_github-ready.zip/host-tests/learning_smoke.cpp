#include "wholebrain_engine.h"
#include <iostream>
#include <vector>
#include <string>

int main(int argc,char**argv){
    int seed=argc>1?std::atoi(argv[1]):77;
    wb::EngineConfig c; c.neurons=30000; c.fanout=64; c.seed=seed; c.sensorGain=3.0f; c.motorGain=12.f; c.learningRate=.003f; c.actionWindowTicks=8;
    // Legacy isolated-regime lock. Channel 9 encodes the cue in 6 Association neurons, so
    // this gate only ever measured a 6-dimensional lookup, not cortical learning: under any
    // ongoing background activity the cue is swamped (~380 background activations per 8-tick
    // window against 6 signal neurons). Background tone is therefore switched OFF here so the
    // test keeps locking exactly what it always locked. The live-regime learning test is
    // plasticity_gate, which uses the distributed cue path instead.
    // v1.2 pins the ENTIRE legacy regime here, not just background tone. This gate is a
    // regression lock on the pre-v3 six-neuron cue path, and v1.2 deliberately changed the
    // operating regime it depends on:
    //   - topographicProjections: projections now preserve position instead of hashing, so a
    //     six-neuron cue no longer scatters across the whole Association population
    //   - localFraction: inter-area bandwidth tripled, which further dilutes a six-neuron cue
    //   - homeostaticGuardRatio / SlowGain: the regulator no longer suppresses every rate
    //     excursion within a couple of ticks (in v1.1 it cancelled stimulus responses too)
    //   - criterionAdaptation: the decision criterion now adapts instead of sitting at zero
    //   - thresholdJitter: wider rheobase spread to desynchronise the denser connectivity
    // Each of these is an improvement for a cortex driven by real sensory input and each of
    // them costs accuracy on a 6-dimensional lookup. Pinning them keeps this gate locking
    // exactly what it has always locked. Live-regime behaviour is covered by dynamics_gate,
    // plasticity_gate and topography_gate.
    c.backgroundRate = 0.0f;
    c.topographicProjections = false;
    c.localFraction = 0.875f;
    c.thresholdJitter = 0.25f;
    c.criterionAdaptation = 0.0f;
    c.homeostaticSlowGain = 1.0f;
    c.homeostaticGuardRatio = 1.0f;
    wb::BrainEngine e(c); e.setMode(wb::RunMode::Learn);
    auto trial=[&](const char* token,int target,bool learn){
        std::vector<uint8_t> b(token,token+std::char_traits<char>::length(token));
        e.injectToken(9,b);
        for(int i=0;i<8;i++) e.step();
        int a=e.stats().currentAction;
        bool ok=a==target;
        if(learn) e.reward(ok);
        return ok;
    };
    int pre=0;for(int i=0;i<80;i++){pre+=trial(i%2?"B":"A",i%2, false);}
    for(int i=0;i<800;i++){trial(i%2?"B":"A",i%2,true);}
    int post=0;for(int i=0;i<160;i++){post+=trial(i%2?"B":"A",i%2,false);}
    auto s=e.stats();
    std::cout<<"pre="<<pre/80.0<<" post="<<post/160.0<<" d="<<s.motorDifferential<<" updates="<<s.reinforcedEpisodes<<" spikes="<<s.spikesTotal<<"\n";
    return post>=144?0:2;
}
