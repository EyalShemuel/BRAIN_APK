// Topography gate.
//
// Up to v1.1 a long-range cortical axon chose its target as (hash % neurons) and a local
// laminar projection hashed into the target layer. Both destroy position. The measured
// consequence was that an offline OPTIMAL linear classifier, given the whole Association
// population, could not tell two orthogonal full-field gratings apart at better than chance
// (test accuracy 0.50) - so no readout, learned or otherwise, could have worked.
//
// This gate locks the two properties that fixed it:
//   1. projections preserve position (a structural check that does not depend on dynamics)
//   2. the Association population is decodable above chance, and measurably better with
//      topography on than off (an end-to-end check that does).
#include "wholebrain_engine.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>

using namespace wb;

// Offline logistic regression on Association spike counts. Deliberately a strong readout:
// the question here is whether the INFORMATION is present, not whether the engine's own
// online readout can find it.
static double decodeAccuracy(bool topographic) {
    EngineConfig c;
    c.neurons = 30000;
    c.fanout = 256;
    c.seed = 101;
    c.sensorGain = 3.0f;
    c.plasticity = false;             // representation only; no learning in the loop
    c.topographicProjections = topographic;

    BrainEngine e(c);
    e.setMode(RunMode::Learn);
    e.setTraceEnabled(true);
    const auto bounds = e.regionBounds(Region::Association);
    const uint32_t base = bounds.first, width = bounds.second - bounds.first;

    std::vector<uint8_t> vert(64 * 64), horz(64 * 64);
    for (int y = 0; y < 64; ++y) {
        for (int x = 0; x < 64; ++x) {
            vert[y * 64 + x] = uint8_t((x / 4) % 2 ? 230 : 25);
            horz[y * 64 + x] = uint8_t((y / 4) % 2 ? 230 : 25);
        }
    }
    for (int i = 0; i < 400; ++i) e.step();

    auto trialVector = [&](const std::vector<uint8_t>& image) {
        std::vector<float> v(width, 0.0f);
        e.injectVision(image, 64, 64);
        for (int k = 0; k < 8; ++k) {
            e.step();
            const auto fr = e.traceFrame(0);
            if (fr.size() < 7) continue;
            const int32_t n = fr[3];
            for (int32_t i = 0; i < n && size_t(7 + i) < fr.size(); ++i) {
                const uint32_t id = uint32_t(fr[7 + i]);
                if (id >= base && id < base + width) v[id - base] += 1.0f;
            }
        }
        return v;
    };

    constexpr int kTrain = 300, kTest = 200;
    std::vector<std::vector<float>> X;
    std::vector<int> Y;
    for (int i = 0; i < kTrain + kTest; ++i) {
        const bool a = (i % 2 == 0);
        X.push_back(trialVector(a ? vert : horz));
        Y.push_back(a ? 1 : -1);
    }

    std::vector<float> w(width, 0.0f);
    float b = 0.0f;
    const float eta = 0.02f, lambda = 1e-4f;
    for (int epoch = 0; epoch < 400; ++epoch) {
        for (int i = 0; i < kTrain; ++i) {
            float z = b;
            for (uint32_t j = 0; j < width; ++j) z += w[j] * X[i][j];
            const float p = 1.0f / (1.0f + std::exp(-z));
            const float g = p - (Y[i] > 0 ? 1.0f : 0.0f);
            for (uint32_t j = 0; j < width; ++j)
                if (X[i][j] != 0.0f) w[j] -= eta * (g * X[i][j] + lambda * w[j]);
            b -= eta * g;
        }
    }
    int correct = 0;
    for (int i = kTrain; i < kTrain + kTest; ++i) {
        float z = b;
        for (uint32_t j = 0; j < width; ++j) z += w[j] * X[i][j];
        if ((z > 0) == (Y[i] > 0)) ++correct;
    }
    return double(correct) / kTest;
}

int main() {
    // 1. Structural: a projection must map neighbouring sources to neighbouring targets.
    //    Sweep the source position across a layer and require the mapped target to advance
    //    monotonically overall, and to stay inside the arbor locally. This assertion fails on
    //    v1.1's hash-based placement no matter what seed it is given.
    {
        EngineConfig c;
        c.neurons = 60000;
        c.fanout = 64;
        c.seed = 7;
        BrainEngine e(c);
        const auto vb = e.regionBounds(Region::Visual);
        const uint32_t vN = vb.second - vb.first;
        assert(vN > 1000);

        uint32_t lastTarget = 0;
        int inversions = 0, samples = 0;
        double totalAdvance = 0.0;
        for (uint32_t step = 0; step <= 100; ++step) {
            const float p = float(step) / 100.0f;
            const uint32_t t = e.probeTopographicTarget(Region::Association, CorticalLayer::L4,
                                                        CorticalCellClass::IT, p, 0.0f);
            if (step) {
                if (t < lastTarget) ++inversions;
                totalAdvance += double(t) - double(lastTarget);
                ++samples;
            }
            lastTarget = t;
        }
        // With a zero arbor the map must be exactly monotonic.
        assert(inversions == 0);
        assert(totalAdvance > 0.0);

        // Two nearby source positions must land within a bounded distance of each other.
        const uint32_t a = e.probeTopographicTarget(Region::Association, CorticalLayer::L4,
                                                    CorticalCellClass::IT, 0.500f, 0.0f);
        const uint32_t d = e.probeTopographicTarget(Region::Association, CorticalLayer::L4,
                                                    CorticalCellClass::IT, 0.505f, 0.0f);
        const uint32_t far = e.probeTopographicTarget(Region::Association, CorticalLayer::L4,
                                                      CorticalCellClass::IT, 0.900f, 0.0f);
        const uint32_t near = a > d ? a - d : d - a;
        const uint32_t apart = a > far ? a - far : far - a;
        assert(near < apart);
    }

    // 2. End-to-end: the stimulus must be decodable from Association, and topography must be
    //    what makes it so.
    const double withTopo = decodeAccuracy(true);
    const double withoutTopo = decodeAccuracy(false);

    std::printf("PASS topography_gate decode_topographic=%.3f decode_hashed=%.3f gain=%+.3f\n",
                withTopo, withoutTopo, withTopo - withoutTopo);

    assert(withoutTopo < 0.60);           // hashed projections: at or near chance
    assert(withTopo > 0.65);              // topographic projections: clearly above chance
    assert(withTopo > withoutTopo + 0.10);
    return 0;
}
