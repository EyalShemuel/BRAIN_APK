// Synaptic plasticity gate, run in the live operating regime.
//
// Until v1.1 the engine had NO synaptic plasticity at all: every synapse carried one of two
// global constants generated from a hash, and the only learnable state in the whole system
// was a linear readout over Association spike counts plus some hash tables of audio
// primitives. This gate locks the fact that synapses now exist, change, are actually used by
// propagation, and survive serialisation - with the cortex running (background tone on,
// laminar cascade active), not on a silent network.
//
// v1.2 additionally asserts that the network can discriminate two stimuli end to end. On
// v1.1 it could not - d' at the Association readout sat at 0.007, exactly chance - because
// long-range projections picked targets as (hash % neurons) and destroyed the sensory map.
// With topography-preserving projections the same measurement is ~0.95, so what was a
// tracked OPEN metric is now a hard bound.
#include "wholebrain_engine.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <vector>

using namespace wb;

int main(int argc, char** argv) {
    const int seed = argc > 1 ? std::atoi(argv[1]) : 101;

    EngineConfig cfg;
    cfg.neurons = 30000;
    // Inter-area convergence matters here: at fanout 64 each Association neuron receives
    // roughly two synapses from Visual in the entire connectome, against a threshold needing
    // tens of coincident inputs, so the visual pathway cannot drive it at all.
    cfg.fanout = 256;
    cfg.seed = seed;
    cfg.sensorGain = 3.0f;
    cfg.motorGain = 12.0f;
    cfg.learningRate = 0.004f;
    cfg.actionWindowTicks = 8;

    assert(cfg.plasticity);

    BrainEngine e(cfg);
    e.setMode(RunMode::Learn);

    std::vector<uint8_t> vert(64 * 64), horz(64 * 64);
    for (int y = 0; y < 64; ++y) {
        for (int x = 0; x < 64; ++x) {
            vert[y * 64 + x] = uint8_t((x / 4) % 2 ? 230 : 25);
            horz[y * 64 + x] = uint8_t((y / 4) % 2 ? 230 : 25);
        }
    }

    std::vector<double> marginA, marginB;
    auto trial = [&](bool isA, bool learn) {
        e.injectVision(isA ? vert : horz, 64, 64);
        for (uint32_t i = 0; i < cfg.actionWindowTicks; ++i) e.step();
        const auto s = e.stats();
        const bool ok = s.currentAction == (isA ? 0 : 1);
        if (learn) e.reward(ok);
        else (isA ? marginA : marginB).push_back(s.motorMargin);
        return ok;
    };

    for (int i = 0; i < 300; ++i) e.step();

    // The gate is meaningless unless the cortex is actually running.
    {
        const auto s = e.stats();
        assert(s.corticalLayerSpikes[static_cast<size_t>(CorticalLayer::L23)] > 0);
        assert(s.corticalLayerSpikes[static_cast<size_t>(CorticalLayer::L5)] > 0);
        assert(s.corticalCellSpikes[static_cast<size_t>(CorticalCellClass::ET)] > 0);
        assert(s.corticalDendriticCoincidences > 0);
        // Nothing has been rewarded yet, so no weight may have moved.
        assert(s.plasticUpdates == 0);
        assert(s.plasticWeightRms == 0.0);
    }

    int pre = 0;
    for (int i = 0; i < 200; ++i) pre += trial(i % 2 == 0, false);
    for (int i = 0; i < 900; ++i) trial(i % 2 == 0, true);

    marginA.clear();
    marginB.clear();
    int post = 0;
    for (int i = 0; i < 200; ++i) post += trial(i % 2 == 0, false);

    const auto s = e.stats();

    // 1. Reward must have driven real synaptic change.
    assert(s.plasticUpdates > 0);
    assert(s.plasticWeightRms > 1e-6);

    // 2. Those weights must be inside their configured bounds.
    assert(s.plasticWeightRms < std::max(std::abs(cfg.plasticWeightMin), cfg.plasticWeightMax));

    // 3. Plasticity must be causal - an engine with it switched off, given the identical
    //    stimulus sequence and seed, must end up in a measurably different state.
    {
        EngineConfig frozen = cfg;
        frozen.plasticity = false;
        BrainEngine f(frozen);
        f.setMode(RunMode::Learn);
        for (int i = 0; i < 300; ++i) f.step();
        for (int i = 0; i < 120; ++i) {
            f.injectVision(i % 2 == 0 ? vert : horz, 64, 64);
            for (uint32_t k = 0; k < frozen.actionWindowTicks; ++k) f.step();
            f.reward(f.stats().currentAction == (i % 2 == 0 ? 0 : 1));
        }
        const auto fs = f.stats();
        assert(fs.plasticUpdates == 0);
        assert(fs.plasticWeightRms == 0.0);
        assert(fs.spikesTotal != s.spikesTotal);
    }

    // 4. Learned synaptic weights must survive a serialise/restore round trip.
    {
        const auto blob = e.serializePlasticity();
        BrainEngine restored(cfg);
        assert(restored.restorePlasticity(blob));
        const auto rs = restored.stats();
        assert(std::abs(rs.plasticWeightRms - s.plasticWeightRms) < 1e-9);
    }

    // 5. End-to-end discrimination. This is the assertion v1.1 could not have passed.
    double ma = 0.0, mb = 0.0;
    for (double x : marginA) ma += x;
    for (double x : marginB) mb += x;
    ma /= std::max<size_t>(1, marginA.size());
    mb /= std::max<size_t>(1, marginB.size());
    double va = 0.0, vb = 0.0;
    for (double x : marginA) va += (x - ma) * (x - ma);
    for (double x : marginB) vb += (x - mb) * (x - mb);
    va = std::sqrt(va / std::max<size_t>(1, marginA.size()));
    vb = std::sqrt(vb / std::max<size_t>(1, marginB.size()));
    const double dprime = (va + vb) > 0.0 ? std::abs(ma - mb) / (0.5 * (va + vb)) : 0.0;

    assert(dprime > 0.45);
    assert(post / 200.0 > 0.62);
    assert(post / 200.0 > pre / 200.0 + 0.08);

    std::printf("PASS plasticity_gate seed=%d plastic_updates=%llu weight_rms=%.6f "
                "coinc=%llu stimulus_dprime=%.3f pre=%.3f post=%.3f\n",
                seed,
                static_cast<unsigned long long>(s.plasticUpdates),
                s.plasticWeightRms,
                static_cast<unsigned long long>(s.corticalDendriticCoincidences),
                dprime, pre / 200.0, post / 200.0);
    return 0;
}
