#include "../app/src/main/cpp/wholebrain_engine.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <span>
#include <string>
#include <vector>

static std::vector<int16_t> tone(double hz, double seconds, double phase=0.0) {
    constexpr int sr=16000;
    const size_t n=static_cast<size_t>(std::llround(seconds*sr));
    std::vector<int16_t> x(n);
    for(size_t i=0;i<n;++i) {
        const double env=std::min(1.0,std::min(double(i)/160.0,double(n-1-i)/160.0));
        x[i]=static_cast<int16_t>(std::sin(2.0*M_PI*hz*double(i)/sr+phase)*15000.0*std::max(0.0,env));
    }
    return x;
}

static std::vector<int16_t> phrase(std::initializer_list<double> hz) {
    std::vector<int16_t> out;
    for(double f:hz) {
        auto p=tone(f,0.16);
        out.insert(out.end(),p.begin(),p.end());
    }
    return out;
}

static std::span<const uint8_t> bytes(const std::string& s) {
    return {reinterpret_cast<const uint8_t*>(s.data()),s.size()};
}

int main() {
    wb::EngineConfig c; c.neurons=30000; c.fanout=64; c.seed=8080;
    wb::BrainEngine e(c);
    e.setMode(wb::RunMode::Learn);
    // Clear the constructor-time refractory window before testing motor activation.
    for(int i=0;i<4;++i) e.step();

    const std::string A="g:05d0", B="g:05d1", M="g:05de";
    const std::string AB=A+char(0x1f)+B;
    const std::string MA=M+char(0x1f)+A;
    const std::string BM=B+char(0x1f)+M;
    assert(e.learnGenerativeSpeech(bytes(AB),phrase({230.0,340.0}),16000));
    assert(e.learnGenerativeSpeech(bytes(MA),phrase({470.0,230.0}),16000));
    assert(e.learnGenerativeSpeech(bytes(BM),phrase({340.0,470.0}),16000));
    assert(e.learnedSpeechPrimitives()>=3);
    assert(e.hasSpeechPrimitive(bytes(A)) && e.hasSpeechPrimitive(bytes(B)) && e.hasSpeechPrimitive(bytes(M)));

    // ABA/MAB/etc. were never taught as whole phrases. The generator must compose one.
    const std::string novel=A+char(0x1f)+M+char(0x1f)+B+char(0x1f)+"#p";
    const auto generated=e.renderGenerativeSpeech(bytes(novel));
    assert(!generated.empty());
    assert(generated.size()>5000 && generated.size()<50000);
    int peak=0; for(int16_t v:generated) peak=std::max(peak,std::abs(int(v)));
    assert(peak>500);
    auto s=e.stats();
    assert(s.generatedSpeechCount==1);
    assert(s.learnedSpeechPrimitives>=3);
    assert(s.learnedSpeechTransitions>=3);

    // Same motor units with question control must take a different prosodic path.
    const std::string question=A+char(0x1f)+M+char(0x1f)+B+char(0x1f)+"#q";
    const auto q=e.renderGenerativeSpeech(bytes(question));
    assert(!q.empty());
    assert(q.size()!=generated.size() || !std::equal(q.begin(),q.begin()+std::min(q.size(),generated.size()),generated.begin()));

    // Generation must activate the actual VocalMotor population after stepping the brain.
    for(int i=0;i<6;++i) e.step();
    s=e.stats();
    assert(s.regionSpikesPerSecond[static_cast<size_t>(wb::Region::VocalMotor)]>0.0);

    // Generative cortex must survive native plasticity persistence.
    const auto blob=e.serializePlasticity();
    wb::BrainEngine restored(c);
    assert(restored.restorePlasticity(blob));
    assert(restored.learnedSpeechPrimitives()>=3);
    const auto generated2=restored.renderGenerativeSpeech(bytes(novel));
    assert(!generated2.empty());
    assert(generated2==generated); // deterministic cortical vocoder from persisted parameters

    // Explicit v0.8 (serialization v4) backward-compatibility gate.  With no
    // BioSpeech motor programs learned yet, the v5 suffix is exactly:
    // uint32 bioSize + empty BSP1 blob (16 bytes).  v6 appends the sparse synaptic
    // weight table, which on an engine that has never been rewarded is just a
    // uint32 zero count (4 bytes).  Remove both suffixes and rewrite the outer
    // version to reproduce a genuine v0.8 plasticity blob.
    constexpr size_t kV5Suffix=20;   // uint32 bioSize + empty BSP1 blob
    constexpr size_t kV6Suffix=4;    // uint32 non-zero synaptic weight count
    auto v4blob=blob;
    assert(v4blob.size()>kV5Suffix+kV6Suffix);
    const uint32_t v4=4;
    std::memcpy(v4blob.data()+sizeof(uint32_t),&v4,sizeof(v4));
    v4blob.resize(v4blob.size()-kV5Suffix-kV6Suffix);
    wb::BrainEngine fromV08(c);
    assert(fromV08.restorePlasticity(v4blob));
    assert(fromV08.learnedSpeechPrimitives()>=3);
    assert(fromV08.learnedBioSpeechPrimitives()==0);
    const auto v08Generated=fromV08.renderGenerativeSpeech(bytes(novel));
    assert(!v08Generated.empty());
    assert(v08Generated==generated);

    // Missing sub-word primitives must fail closed instead of falling back to TTS/phrase replay.
    const std::string missing=A+char(0x1f)+"g:05ea";
    assert(restored.renderGenerativeSpeech(bytes(missing)).empty());

    std::cout << "PASS generative_speech primitives=" << s.learnedSpeechPrimitives
              << " transitions=" << s.learnedSpeechTransitions
              << " novel_samples=" << generated.size()
              << " question_samples=" << q.size()
              << " vocal_sps=" << s.regionSpikesPerSecond[static_cast<size_t>(wb::Region::VocalMotor)]
              << "\n";
}
