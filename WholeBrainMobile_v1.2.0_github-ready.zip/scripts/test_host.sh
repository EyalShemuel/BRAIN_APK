#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cmake -S "$ROOT/host-tests" -B "$ROOT/host-tests/build" -G Ninja
cmake --build "$ROOT/host-tests/build"
"$ROOT/host-tests/build/wholebrain_host_test"

# Learning smoke: the same reward loop must learn two opposite associations
# from chance-like pre-training performance to >=0.75 on three independent seeds.
for seed in 77 78 79; do
  "$ROOT/host-tests/build/learning_smoke" "$seed"
done

# Legacy neural-speech persistence/recall gate remains for state compatibility.
"$ROOT/host-tests/build/neural_speech_test"

# v0.8 compatibility gate: teach only sub-word pairs, then require a never-taught utterance.
"$ROOT/host-tests/build/generative_speech_test"

# v0.9 BioSpeech gate: articulatory plant + auditory/somatosensory feedback + selective lesions.
"$ROOT/host-tests/build/biospeech_test"

# v1.0 cortical scaffold gate: laminar populations, inhibitory subclasses,
# apical coincidence, feedforward/feedback compartments and conduction delays.
# NOTE: this gate only checks that the lookup tables return their own constants. It passes
# on a completely silent network. dynamics_gate below is what checks the cortex is running.
"$ROOT/host-tests/build/cortical_microcircuit_test"

# v1.1 dynamics gate: the laminar cascade must actually carry signal, the operating point
# must not depend on network size, activity must survive removal of sensory input without
# running away, and memory must stay bounded. Every assertion in it fails on v1.0 as shipped.
"$ROOT/host-tests/build/dynamics_gate"

# v1.2 topography gate: projections must preserve position, and the Association population
# must be decodable above chance BECAUSE of that. Fails on v1.0/v1.1 hashed projections.
"$ROOT/host-tests/build/topography_gate"

# v1.1 plasticity gate: synapses exist, change under reward, are used by propagation,
# and survive serialisation - with the cortex live rather than silent.
"$ROOT/host-tests/build/plasticity_gate" 101

# v0.7 neural-speech architectural gate: active app source must not depend on Android TTS.
if grep -RInE 'android\.speech\.tts|TTS_SERVICE|synthesizeToFile' \
  "$ROOT/app/src/main/java" "$ROOT/app/src/main/AndroidManifest.xml" >/tmp/wb_tts_hits.txt; then
  cat /tmp/wb_tts_hits.txt
  echo "FAIL: active neural speech path still contains Android TTS"
  exit 1
fi
grep -q 'nativeLearnSpeech' "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/brain/NativeBrain.kt"
grep -q 'nativeRenderSpeech' "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/brain/NativeBrain.kt"
grep -q 'FastSpeechCurriculum' "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/output/SpeechOutputEngine.kt"
grep -q 'nativeLearnBioSpeech' "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/brain/NativeBrain.kt"
grep -q 'nativeRenderBioSpeech' "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/brain/NativeBrain.kt"
grep -q 'renderBioSpeech(plan.wire)' "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/output/SpeechOutputEngine.kt"
grep -q 'learnBioSpeech(plan.wire' "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/output/SpeechOutputEngine.kt"
test -f "$ROOT/app/src/main/cpp/biospeech_model.cpp"
# Active speech path must never fall back to v0.7 whole-phrase recall/composition.
if grep -nE 'learnSpeechUnit\(|renderSpeechUnit\(|composeFromLearnedWords' \
  "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/output/SpeechOutputEngine.kt"; then
  echo "FAIL: active speech path still uses phrase replay"
  exit 1
fi

# BioSpeech active Android path must not call the legacy v0.8 acoustic generator.
if grep -nE 'renderGenerativeSpeech\(|learnGenerativeSpeech\(' \
  "$ROOT/app/src/main/java/com/eyalshemuel/wholebrainmobile/output/SpeechOutputEngine.kt"; then
  echo "FAIL: active speech path still calls legacy acoustic generator"
  exit 1
fi

# v0.9 BioSpeech architectural/teaching locks.
grep -q 'injectSpeechMicrocircuit' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"
grep -q 'LesionSomatosensory' "$ROOT/app/src/main/cpp/biospeech_model.h"
grep -q 'LesionCerebellum' "$ROOT/app/src/main/cpp/biospeech_model.h"
if grep -q 'compandedPcm' "$ROOT/app/src/main/cpp/biospeech_model.cpp" "$ROOT/app/src/main/cpp/biospeech_model.h"; then
  echo "FAIL: BioSpeech model stores replay PCM"
  exit 1
fi

python3 - "$ROOT/app/src/main/assets/learning/biospeech_he_v3.txt" <<'PY'
import sys, unicodedata
from pathlib import Path
p=Path(sys.argv[1])
lines=[x.strip() for x in p.read_text(encoding='utf-8').splitlines() if x.strip() and not x.startswith('#')]
assert len(lines)==40, f"expected 40 BioSpeech prompts, got {len(lines)}"
letters='אבגדהוזחטיכלמנסעפצקרשת'
final={'ך':'כ','ם':'מ','ן':'נ','ף':'פ','ץ':'צ'}
marks={'\u05B0':'v:schwa','\u05B1':'v:e','\u05B2':'v:a','\u05B3':'v:o','\u05B4':'v:i','\u05B5':'v:e','\u05B6':'v:e','\u05B7':'v:a','\u05B8':'v:a','\u05B9':'v:o','\u05BB':'v:u','\u05C7':'v:o'}
found=set()
for line in lines:
    for ch in unicodedata.normalize('NFKC',line):
        if ch in marks: found.add(marks[ch])
        c=final.get(ch,ch)
        if c in letters: found.add('g:'+format(ord(c),'04x'))
required={'g:'+format(ord(c),'04x') for c in letters}|{'v:a','v:e','v:i','v:o','v:u','v:schwa'}
missing=required-found
assert not missing, f"BioSpeech curriculum missing units: {sorted(missing)}"
print(f"PASS biospeech_curriculum prompts={len(lines)} core_units={len(required)}")
PY

# v1.0 cortex source locks.
test -f "$ROOT/app/src/main/cpp/cortical_microcircuit.cpp"
grep -q 'apicalDendrite_' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"
grep -q 'CorticalCellClass::LAMP5' "$ROOT/app/src/main/cpp/cortical_microcircuit.cpp"
grep -q 'structuredCorticalTarget' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"

# v1.1 source locks. These are grep checks and, like every grep check in this file, they
# only prove the text is present - the behavioural gates above are what prove it works.
grep -q 'updateHomeostasis' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"
grep -q 'applyPlasticity' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"
grep -q 'slotCurrent_' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"

# v1.2 source locks.
grep -q 'topographicTarget' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"
grep -q 'longRangeTargetRegion' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"
# A long-range cortical axon must never again choose its target uniformly at random.
if grep -q 'target = static_cast<uint32_t>(h % cfg_.neurons);' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp" \
   && ! grep -q 'topographic && srcCortical' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"; then
  echo "FAIL: long-range projections are unstructured again"
  exit 1
fi
# The engine must not go back to storing one queued event per synaptic edge.
if grep -q 'eventRing_' "$ROOT/app/src/main/cpp/wholebrain_engine.cpp"; then
  echo "FAIL: per-edge event queue reintroduced"
  exit 1
fi
