#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

OUT="dist"
mkdir -p "$OUT"

APK_SRC="app/build/outputs/apk/debug/app-debug.apk"
test -f "$APK_SRC"

VERSIONED="$OUT/WholeBrainMobile-1.2.0-debug.apk"
LATEST="$OUT/WholeBrainMobile-debug.apk"

cp "$APK_SRC" "$LATEST"
cp "$APK_SRC" "$VERSIONED"

# Checksums are written with paths relative to the repo root, not absolute ones.
# `sha256sum` records whatever path it was handed, so absolute paths make the manifest
# verifiable only on the machine that produced it and only from the directory it ran in.
sha256sum "$LATEST"    > "${LATEST}.sha256"
sha256sum "$VERSIONED" > "${VERSIONED}.sha256"

# Verify immediately, from the repo root, so a broken manifest fails here rather than in
# whatever consumes the release later.
sha256sum -c "${LATEST}.sha256"
sha256sum -c "${VERSIONED}.sha256"

echo "packaged:"
sha256sum "$VERSIONED"
