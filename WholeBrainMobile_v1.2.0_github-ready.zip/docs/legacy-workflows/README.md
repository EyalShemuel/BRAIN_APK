# Legacy workflows (inactive)

These are the v0.7-v1.0 build workflows. They are kept for history only and are deliberately
NOT in `.github/workflows/`, so GitHub Actions does not run them.

Two reasons they cannot run as-is:

1. They build from `WholeBrainMobile_SOURCE_v1.0.0.zip` committed at the repo root. The zip
   is no longer the source of truth - the working tree is - so the `test -f` at the top of
   each would fail immediately.
2. They install `platforms/android-37.2` from the SDK manager's `--canary` channel. Canary
   artifacts are replaced and withdrawn, so these pin build inputs that no longer exist.

The active workflow is `.github/workflows/build-human-cortex-v1.yml`.
