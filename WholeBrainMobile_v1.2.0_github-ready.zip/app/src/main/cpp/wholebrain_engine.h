#pragma once
#include <array>
#include <cstdint>
#include <deque>
#include <mutex>
#include <span>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#include "biospeech_model.h"
#include "cortical_microcircuit.h"

namespace wb {

enum class Region : uint8_t {
    Visual = 0, Auditory, Language, Somatosensory, Association,
    Hippocampus, Pfc, BasalGanglia, Thalamus, Cerebellum,
    Motor, VocalMotor, Semantic, Neuromod, Brainstem, Count
};

enum class RunMode : int { Observe = 0, Learn = 1, Act = 2, Sleep = 3 };

struct EngineConfig {
    uint64_t neurons = 250000;
    uint32_t fanout = 1024;
    uint64_t seed = 1;
    uint32_t timestepMs = 10;
    uint32_t recurrentDelayMax = 8;
    // v1.2: 12.5% long-range was not enough bandwidth between areas to matter. At fanout 64
    // each Association neuron ended up with roughly TWO synapses from Visual in the entire
    // connectome, while firing needs ~26 coincident inputs - so the visual pathway was
    // structurally incapable of driving Association, whatever its topography. 30% makes
    // inter-area projections a driver pathway rather than a rounding error.
    float localFraction = 0.70f;
    float excitatoryFraction = 0.80f;
    float membraneDecay = 0.90f;
    float threshold = 1.0f;
    float resetPotential = 0.0f;
    uint32_t refractoryTicks = 2;
    float excitatoryWeight = 0.040f;
    // 80/20 E/I split with a 1.3x weight ratio leaves mean recurrent drive net
    // EXCITATORY (0.8*0.040 - 0.2*0.052 = +0.022), so the network has no stable
    // operating point: it either sits silent or ignites. A ratio near 6 puts the
    // mean field slightly inhibition-dominated and firing becomes fluctuation-driven.
    float inhibitoryWeight = 0.240f;

    // v1.0 biologically constrained cortical scaffold. Cortical regions use
    // laminar/cell-class phenotypes, apical dendritic integration and structured
    // local/feedforward/feedback targeting. Non-cortical regions retain the validated path.
    bool biologicalCortex = true;
    float structuredCorticalFraction = 0.28f;

    // Modality-specific gains. Sensory geometry is fixed independently of these gains;
    // gain only controls current strength, not which neuron represents which input.
    float sensorGain = 0.90f;
    float visionGain = 1.15f;
    float audioGain = 1.15f;
    float touchGain = 1.20f;
    float imuGain = 1.15f;
    float environmentGain = 1.10f;
    float locationGain = 1.15f;
    float tokenGain = 1.20f;

    // v1.1 homeostatic excitability regulation. Local convergence in this engine is
    // fanout*localFraction spread over a region, so a fixed threshold has no
    // scale-invariant operating point: the same weights that ignite a 60k network
    // leave a 250k network silent. A slow per-region controller drives each cortical
    // region toward targetRateHz and makes the operating point independent of size.
    bool homeostasis = true;
    float targetRateHz = 2.0f;          // per-neuron target firing rate
    float homeostaticRate = 0.004f;     // controller gain per tick (relaxing a silent region)
    float homeostaticUpGain = 25.0f;    // extra gain in the runaway-guard regime only
    // The controller must regulate the ONGOING operating point, not the response to a
    // stimulus. v1.1 used one fast gain for any overshoot, which meant a region whose rate
    // rose because something was presented to it had its threshold raised within a couple of
    // ticks - the controller cancelled the stimulus. Raising visionGain tenfold then changed
    // the Association representation by nothing at all, because the regulator simply absorbed
    // it. Real synaptic scaling acts over hours; the fast path here exists only to catch a
    // genuine avalanche, and normal regulation is two orders of magnitude slower.
    float homeostaticSlowGain = 0.04f;  // multiplier on homeostaticRate inside the normal band
    float homeostaticGuardRatio = 4.0f; // rate/target above which the fast guard engages
    float homeostaticMin = 0.02f;       // floor on the threshold multiplier
    float homeostaticMax = 8.0f;        // ceiling on the threshold multiplier
    float thresholdJitter = 0.45f;      // +/- fractional per-neuron rheobase spread
    uint64_t queueSoftCap = 400000;     // events; above this, synapses start failing

    // Tonic background drive. An isolated cortical sheet is not self-sustaining in vivo
    // either: it sits on brainstem/neuromodulatory tone and spontaneous vesicle release,
    // which hold the membrane distribution near threshold so recurrent activity is
    // fluctuation-driven. Without it this engine is strictly stimulus-locked - remove the
    // camera and every region goes to exactly zero.
    float backgroundRate = 0.004f;      // fraction of neurons receiving a spontaneous event per tick
    float backgroundWeight = 0.35f;     // magnitude of that event

    // Synaptic plasticity. Until now every synapse carried one of two global constants
    // generated from a hash, so nothing in the cortex could change: the only learnable
    // state in the engine was a linear readout over Association spike counts. Synapses are
    // procedural and a dense per-synapse array would cost neurons*fanout floats (128 MB at
    // 250k/128), so weights live in a fixed hashed table and colliding synapses share a
    // weight - the hashing trick, with collisions acting as weight sharing.
    // The rule is voltage-gated and reward-modulated (Clopath-style three-factor):
    // a presynaptic spike onto a depolarised target builds positive eligibility, a
    // presynaptic spike onto a target that just fired builds negative eligibility, and
    // reward converts eligibility into weight change.
    bool plasticity = true;
    uint32_t plasticTableBits = 18;     // 2^18 shared weights
    float traceDecay = 0.92f;           // postsynaptic spike trace decay per tick
    float ltpRate = 0.020f;
    float ltdRate = 0.010f;
    float depolarizationGate = 0.45f;   // fraction of threshold below which no LTP accrues
    float plasticWeightMin = -0.80f;
    float plasticWeightMax = 2.00f;
    // Forgetting rate on the Association readout. Under background activity thousands of
    // non-stimulus neurons enter every action window; their differentials random-walk and
    // their summed contribution swamps the few hundred stimulus-driven ones. Decay pulls
    // unreinforced features back to zero while consistently-reinforced ones hold.
    float readoutDecay = 0.0f;   // opt-in; see plasticity_gate notes
    // Adaptation rate of the decision criterion. Must be slow enough to track only the
    // stationary common-mode term and NOT the stimulus alternation itself - at 0.02/tick the
    // criterion followed an A/B alternating sequence closely enough to subtract the very
    // signal it was meant to expose. This is ~500 ticks, tens of trials.
    float criterionAdaptation = 0.002f;

    // v1.2 topography-preserving projections.
    //
    // Up to v1.1 a long-range cortical axon picked its target as (hash % neurons) - uniformly
    // across the entire brain - and a local laminar projection picked its target by hashing
    // into the target layer. Both are position-destroying. The consequence was measurable:
    // the retinotopic map that injectTopographicCell builds in V1 L4 was gone by the time
    // anything reached L2/3 of the same area, and Association received input from Visual that
    // was statistically independent of WHICH part of the visual field was driven. Two
    // orthogonal full-field gratings produced d' ~ 0.03 at the readout - chance.
    //
    // A projection now maps the source's normalised position within its own layer onto the
    // same normalised position in the target layer, plus a bounded arbor. Local projections
    // get a narrow arbor (a cortical column); long-range projections get a wider one
    // (a terminal arbor spanning a few percent of the target area).
    bool topographicProjections = true;
    float columnarSpread = 0.015f;    // local arbor, as a fraction of the target layer
    float projectionSpread = 0.010f;  // long-range terminal arbor

    float motorGain = 8.0f;
    float learningRate = 0.001f;
    uint32_t actionWindowTicks = 8;
};

struct Event { uint32_t target; float weight; uint8_t compartment = static_cast<uint8_t>(DendriticCompartment::Soma); };

struct TraceEdge {
    uint32_t source = 0;
    uint32_t target = 0;
    uint16_t delay = 0;
    int8_t sign = 0;
};

struct TraceFrame {
    uint64_t tick = 0;
    std::vector<uint32_t> fired;
    std::vector<TraceEdge> edges;
};

struct Stats {
    uint64_t neurons = 0;
    uint64_t logicalSynapses = 0;
    uint64_t tick = 0;
    uint64_t spikesTotal = 0;
    uint64_t edgeEventsTotal = 0;
    uint32_t spikesLastStep = 0;
    uint64_t queuedEvents = 0;
    double lastStepMs = 0.0;
    double spikesPerSecond = 0.0;
    double edgesPerSecond = 0.0;
    double stepHz = 0.0;
    std::array<double, static_cast<size_t>(Region::Count)> regionSpikesPerSecond{};

    double cameraFramesPerSecond = 0.0;
    double visionFramesPerSecond = 0.0;
    double visionFeaturesPerSecond = 0.0;
    double visionInjectionsPerSecond = 0.0;

    double audioChunksPerSecond = 0.0;
    double audioBandsPerSecond = 0.0;
    double audioInjectionsPerSecond = 0.0;

    double touchEventsPerSecond = 0.0;
    double touchInjectionsPerSecond = 0.0;

    double imuEventsPerSecond = 0.0;
    double imuChangesPerSecond = 0.0;
    double imuInjectionsPerSecond = 0.0;

    double environmentEventsPerSecond = 0.0;
    double environmentChangesPerSecond = 0.0;
    double environmentInjectionsPerSecond = 0.0;

    double locationEventsPerSecond = 0.0;
    double locationInjectionsPerSecond = 0.0;

    double externalTokensPerSecond = 0.0;
    double externalInjectionsPerSecond = 0.0;

    int currentAction = -1;
    uint64_t actionEpoch = 0;
    double motorMargin = 0.0;
    double motorDifferential = 0.0;
    uint64_t reinforcedEpisodes = 0;
    uint32_t learnedSpeechUnits = 0;
    uint32_t learnedSpeechPrimitives = 0;
    uint32_t learnedSpeechTransitions = 0;
    uint64_t speechMemoryBytes = 0;
    uint64_t speechRenderCount = 0;
    uint64_t generatedSpeechCount = 0;
    uint32_t learnedBioSpeechPrimitives = 0;
    uint32_t learnedBioSpeechTransitions = 0;
    uint64_t bioSpeechMemoryBytes = 0;
    uint64_t bioSpeechRenderCount = 0;
    double bioSpeechAuditoryErrorBefore = 0.0;
    double bioSpeechAuditoryErrorAfter = 0.0;
    double bioSpeechSomatosensoryError = 0.0;
    double bioSpeechCompensation = 0.0;
    uint32_t bioSpeechLesionMask = 0;

    uint64_t corticalApicalEvents = 0;
    uint64_t corticalDendriticCoincidences = 0;
    uint64_t plasticUpdates = 0;
    double plasticWeightRms = 0.0;
    uint64_t synapticFailures = 0;
    uint64_t corticalStructuredEdges = 0;
    std::array<uint64_t, static_cast<size_t>(CorticalLayer::Count)> corticalLayerSpikes{};
    std::array<uint64_t, static_cast<size_t>(CorticalCellClass::Count)> corticalCellSpikes{};
    uint64_t memoryBytes = 0;
    RunMode mode = RunMode::Observe;
};

struct ScaleRecommendation {
    uint64_t balancedNeurons = 0;
    uint32_t balancedFanout = 1024;
    uint64_t maxNeurons = 0;
    uint32_t maxFanout = 1024;
    uint64_t logicalConnectionsBalanced = 0;
    uint64_t logicalConnectionsMax = 0;
    double measuredEdgeHashPerSecond = 0.0;
    uint64_t memoryBudgetBytes = 0;
};

class BrainEngine {
public:
    explicit BrainEngine(const EngineConfig& config);
    ~BrainEngine() = default;
    BrainEngine(const BrainEngine&) = delete;
    BrainEngine& operator=(const BrainEngine&) = delete;

    void step();
    void setMode(RunMode mode);
    RunMode mode() const;

    void noteCameraFrame();
    void injectVision(std::span<const uint8_t> pixels, int width, int height);
    void injectAudio(std::span<const int16_t> pcm, int sampleRate);
    void injectSensor(int sensorType, float x, float y, float z);
    void injectTouch(float xNorm, float yNorm, float pressure);
    void injectLocation(double latitude, double longitude, float speed, float bearing);
    void injectToken(uint32_t channel, std::span<const uint8_t> bytes);
    void resetDiagnostics();

    // Exact active-subgraph tracing. Frames are recorded only while enabled so the
    // scientific/runtime path is unchanged when Neural View is closed. Each frame
    // contains every neuron that fired in that simulation step and every recurrent
    // edge that was actually scheduled by those spikes.
    void setTraceEnabled(bool enabled);
    std::vector<int32_t> traceFrame(size_t back = 0) const;
    // Diagnostics: region boundaries, so an analysis harness can attribute spikes to areas
    // without duplicating the layout arithmetic.
    std::pair<uint32_t,uint32_t> regionBounds(Region region) const;
    // Diagnostics: resolve a projection target for a given normalised source position, so a
    // test can check the map directly instead of inferring it from spiking.
    uint32_t probeTopographicTarget(Region targetRegion, CorticalLayer layer, CorticalCellClass preferred,
                                    float sourcePosition, float spreadFraction) const;

    void reward(bool positive);

    // Learned neural speech: explicit teaching pairs a language token with microphone PCM.
    // Rendering recalls a learned VocalMotor engram and returns PCM directly; no TTS is used.
    bool learnSpeech(std::span<const uint8_t> token, std::span<const int16_t> pcm, int sampleRate);
    std::vector<int16_t> renderSpeech(std::span<const uint8_t> token);

    // Generative speech cortex. A teaching sample is aligned to sub-word motor units
    // encoded in `plan`; generation composes learned primitives/transitions into a
    // novel utterance. The active Android speech path uses these APIs, never phrase PCM.
    bool learnGenerativeSpeech(std::span<const uint8_t> plan, std::span<const int16_t> pcm, int sampleRate);
    std::vector<int16_t> renderGenerativeSpeech(std::span<const uint8_t> plan);
    bool hasSpeechPrimitive(std::span<const uint8_t> unit) const;
    uint32_t learnedSpeechPrimitives() const;

    // v0.9 BioSpeech: learned articulatory motor programs drive a vocal-tract plant.
    // Auditory and somatosensory prediction errors close the loop through the
    // cerebellar/BG/thalamic control path. No waveform replay or TTS is involved.
    bool learnBioSpeech(std::span<const uint8_t> plan, std::span<const int16_t> pcm, int sampleRate);
    std::vector<int16_t> renderBioSpeech(std::span<const uint8_t> plan);
    bool hasBioSpeechPrimitive(std::span<const uint8_t> unit) const;
    uint32_t learnedBioSpeechPrimitives() const;
    void setBioSpeechPerturbation(float auditoryF1ShiftHz, float auditoryF2ShiftHz, float jawOffset);
    void setBioSpeechLesionMask(uint32_t mask);
    BioSpeechModel::Diagnostics bioSpeechDiagnostics() const;

    void clearSpeech();
    uint32_t learnedSpeechUnits() const;

    Stats stats() const;
    std::string statsJson() const;
    std::vector<uint8_t> serializePlasticity() const;
    bool restorePlasticity(std::span<const uint8_t> blob);

    const EngineConfig& config() const { return cfg_; }
    static double benchmarkEdgeHash(uint64_t edges, uint64_t seed = 1);
    static ScaleRecommendation recommendScale(uint64_t memoryBudgetBytes,
                                              double measuredEdgesPerSecond,
                                              double targetHz = 60.0,
                                              double assumedActiveFraction = 0.005);

    // Deterministic scientific/test primitives.
    static uint64_t mix64(uint64_t x);
    static uint32_t deterministicTarget(uint32_t source, uint32_t slot,
                                        uint32_t n, uint64_t seed);
    static float core53ErrorUpdate(float differential, uint16_t count, int chosen, float eta);

    // Scale-stable topographic mapping. Adjacent cells map to adjacent neuron columns;
    // role chooses a neuron inside the cell column and never hashes spatial position.
    static uint32_t topographicLocal(uint32_t regionSize,
                                     uint32_t cellIndex,
                                     uint32_t cellCount,
                                     uint32_t role,
                                     uint32_t roleCount);

private:
    struct RegionRange { uint32_t begin = 0, end = 0; };
    struct FeatureCount { uint32_t index; uint16_t count; };
    struct TouchState { float x=0.0f, y=0.0f, pressure=0.0f; bool active=false; };
    struct SpeechEngram {
        uint32_t sampleRate = 16000;
        std::vector<int8_t> compandedPcm;
    };
    static constexpr size_t kSpeechLpcOrder = 10;
    struct SpeechAcousticFrame {
        float f0Hz = 0.0f;
        float rms = 0.0f;
        float voiced = 0.0f;
        std::array<float,kSpeechLpcOrder> lpc{};
    };
    struct SpeechPrimitive {
        uint32_t sampleRate = 16000;
        uint16_t observations = 1;
        std::vector<SpeechAcousticFrame> frames;
    };

    void buildRegions();
    Region regionOf(uint32_t neuron) const;
    uint32_t regionSize(Region region) const;
    bool isExcitatory(uint32_t neuron) const;
    bool isCorticalRegion(Region region) const;
    CorticalAreaKind corticalAreaKind(Region region) const;
    int corticalHierarchy(Region region) const;
    CorticalPhenotype corticalPhenotype(uint32_t neuron) const;
    uint32_t structuredCorticalTarget(Region targetRegion, CorticalLayer layer, CorticalCellClass preferred, uint64_t hash) const;
    float corticalPosition(uint32_t neuron) const;
    uint32_t topographicTarget(Region targetRegion, CorticalLayer layer, CorticalCellClass preferred,
                               float sourcePosition, float spreadFraction, uint64_t hash) const;
    Region longRangeTargetRegion(Region source, uint64_t hash) const;
    void schedule(uint32_t target, float weight, uint32_t delayTicks, DendriticCompartment compartment = DendriticCompartment::Soma);
    uint32_t injectPopulation(Region region, uint64_t key, float magnitude, uint32_t count, float gain);
    uint32_t injectChannelPopulation(Region region, uint32_t channel, uint32_t channelCount,
                                     float magnitude, float density, float gain, uint64_t salt = 0,
                                     uint32_t maxCount = 16);
    uint32_t injectDistributedSubrange(Region region, uint32_t bank, uint32_t banks,
                                       uint64_t key, float magnitude, float density, float gain,
                                       uint32_t maxCount = 64);
    // Speech-cortex microcircuit mapper. layer: 0=L4, 1=L2/3, 2=L5, 3=L6.
    // cellClass: 0=pyramidal, 1=PV, 2=SST, 3=VIP. Inhibitory classes are
    // deterministic subdivisions of the engine's inhibitory population.
    uint32_t injectSpeechMicrocircuit(Region region, uint32_t layer, uint32_t cellClass,
                                      uint64_t key, float magnitude, float gain,
                                      uint32_t maxCount = 12);
    uint32_t injectTopographicCell(Region region, uint32_t x, uint32_t y,
                                   uint32_t width, uint32_t height,
                                   uint32_t role, uint32_t roleCount,
                                   float magnitude, float gain);
    uint32_t injectVisualFeature(uint64_t key, float magnitude, int width, int height);
    uint32_t injectAudioBand(uint32_t band, float magnitude, float onset);
    void injectEnvironment(int sensorType, float x, float y, float z);

    void applyLazyDecay(uint32_t neuron);
    void fire(uint32_t neuron, std::vector<uint32_t>& fired);
    void propagate(std::span<const uint32_t> fired, std::vector<TraceEdge>* traceEdges = nullptr);
    void processMotor(std::span<const uint32_t> fired);
    void finishActionWindow();
    void resetCurrentFeature();
    float thresholdFor(uint32_t neuron) const;
    void updateHomeostasis(const std::array<uint32_t, static_cast<size_t>(Region::Count)>& counts);
    float spikeTrace(uint32_t neuron) const;
    uint32_t synapseIndex(uint32_t src, uint32_t slot) const;
    void applyPlasticity(float reward);
    uint64_t memoryBytesUnsafe() const;
    static uint64_t speechPrimitiveKey(std::span<const uint8_t> unit);
    static uint64_t speechTransitionKey(uint64_t a, uint64_t b);
    static std::vector<SpeechAcousticFrame> analyzeSpeechFrames(std::span<const int16_t> pcm);
    static std::vector<int16_t> synthesizeSpeechFrames(std::span<const SpeechAcousticFrame> frames, uint64_t seed, double rate);
    void learnPrimitive(std::unordered_map<uint64_t, SpeechPrimitive>& table, uint64_t key, std::span<const int16_t> pcm);

    EngineConfig cfg_;
    mutable std::mutex mutex_;
    std::array<RegionRange, static_cast<size_t>(Region::Count)> regions_{};

    std::vector<float> membrane_;
    std::vector<float> apicalDendrite_;
    std::vector<float> adaptation_;
    std::vector<uint32_t> lastUpdateTick_;
    std::vector<uint32_t> lastSpikeTick_;
    std::vector<uint16_t> touchMarker_;
    uint16_t touchEpoch_ = 1;
    std::vector<uint32_t> touched_;
    // Delayed input is accumulated as current per (neuron, delay slot) rather than stored
    // as one event per synaptic edge. The edge list costs O(spikes * fanout) and is
    // unbounded; this costs neurons * slots * 2 floats, fixed, and gets relatively cheaper
    // as activity rises because every edge landing on the same target in the same slot
    // collapses into one add. slotTouched_ keeps the drain sparse.
    std::vector<float> slotCurrent_;          // [(slot*neurons + n)*2 + compartment]
    std::vector<uint8_t> slotMarker_;         // [slot*neurons + n], 1 if pending
    std::vector<std::vector<uint32_t>> slotTouched_;
    size_t slots_ = 0;

    RegionRange association_{};
    RegionRange motor_{};
    RegionRange vocalMotor_{};
    std::vector<float> motorDifferential_;
    std::vector<uint16_t> featureCounts_;
    std::vector<uint32_t> featureTouched_;
    std::vector<FeatureCount> lastFeature_;
    double motorEvidence_ = 0.0;
    std::array<uint32_t, 2> motorSpikesWindow_{0, 0};
    int lastAction_ = -1;
    uint64_t actionEpoch_ = 0;
    double lastMotorMargin_ = 0.0;
    uint64_t reinforcedEpisodes_ = 0;
    std::unordered_map<uint64_t, SpeechEngram> speechEngrams_; // v0.7 legacy phrase memory, kept for state compatibility only
    std::unordered_map<uint64_t, SpeechPrimitive> speechPrimitives_;
    std::unordered_map<uint64_t, SpeechPrimitive> speechTransitions_;
    uint64_t speechRenderCount_ = 0;
    uint64_t generatedSpeechCount_ = 0;
    BioSpeechModel bioSpeech_;
    uint64_t bioSpeechRenderCount_ = 0;

    uint64_t corticalApicalEvents_ = 0;
    uint64_t corticalDendriticCoincidences_ = 0;
    uint64_t corticalStructuredEdges_ = 0;
    std::array<uint64_t, static_cast<size_t>(CorticalLayer::Count)> corticalLayerSpikes_{};
    std::array<uint64_t, static_cast<size_t>(CorticalCellClass::Count)> corticalCellSpikes_{};

    uint64_t tick_ = 0;
    uint64_t spikesTotal_ = 0;
    uint64_t edgeEventsTotal_ = 0;
    uint32_t spikesLastStep_ = 0;
    double lastStepMs_ = 0.0;
    double emaStepMs_ = 0.0;
    double emaSpikesPerSecond_ = 0.0;
    double emaEdgesPerSecond_ = 0.0;
    std::array<double, static_cast<size_t>(Region::Count)> emaRegionSpikesPerSecond_{};
    std::array<float, static_cast<size_t>(Region::Count)> regionThresholdScale_{};
    // Cell identity cache: bits 0-2 the cell class, bit 3 excitatory. corticalPhenotype()
    // recomputes a 64-bit mix and the layer boundaries every call, and the topographic arbor
    // search asks about up to 2*arbor+1 neighbours for EVERY edge, so this was dominating
    // propagate(). One byte per neuron; the full phenotype is still computed where its
    // continuous parameters are actually needed.
    std::vector<uint8_t> cellCache_;
    uint64_t queuedEvents_ = 0;
    uint64_t synapticFailures_ = 0;
    std::vector<float> featureBaseline_;
    double motorEvidenceBaseline_ = 0.0;
    std::vector<float> synapticWeight_;
    std::vector<float> synapticEligibility_;
    uint32_t plasticMask_ = 0;
    uint64_t plasticUpdates_ = 0;
    std::array<double, static_cast<size_t>(Region::Count)> regionRateEma_{};

    double emaCameraFramesPerSecond_ = 0.0;
    double emaVisionFramesPerSecond_ = 0.0;
    double emaVisionFeaturesPerSecond_ = 0.0;
    double emaVisionInjectionsPerSecond_ = 0.0;
    double emaAudioChunksPerSecond_ = 0.0;
    double emaAudioBandsPerSecond_ = 0.0;
    double emaAudioInjectionsPerSecond_ = 0.0;
    double emaTouchEventsPerSecond_ = 0.0;
    double emaTouchInjectionsPerSecond_ = 0.0;
    double emaImuEventsPerSecond_ = 0.0;
    double emaImuChangesPerSecond_ = 0.0;
    double emaImuInjectionsPerSecond_ = 0.0;
    double emaEnvironmentEventsPerSecond_ = 0.0;
    double emaEnvironmentChangesPerSecond_ = 0.0;
    double emaEnvironmentInjectionsPerSecond_ = 0.0;
    double emaLocationEventsPerSecond_ = 0.0;
    double emaLocationInjectionsPerSecond_ = 0.0;
    double emaExternalTokensPerSecond_ = 0.0;
    double emaExternalInjectionsPerSecond_ = 0.0;

    uint64_t pendingCameraFrames_ = 0;
    uint64_t pendingVisionFrames_ = 0;
    uint64_t pendingVisionFeatures_ = 0;
    uint64_t pendingVisionInjections_ = 0;
    uint64_t pendingAudioChunks_ = 0;
    uint64_t pendingAudioBands_ = 0;
    uint64_t pendingAudioInjections_ = 0;
    uint64_t pendingTouchEvents_ = 0;
    uint64_t pendingTouchInjections_ = 0;
    uint64_t pendingImuEvents_ = 0;
    uint64_t pendingImuChanges_ = 0;
    uint64_t pendingImuInjections_ = 0;
    uint64_t pendingEnvironmentEvents_ = 0;
    uint64_t pendingEnvironmentChanges_ = 0;
    uint64_t pendingEnvironmentInjections_ = 0;
    uint64_t pendingLocationEvents_ = 0;
    uint64_t pendingLocationInjections_ = 0;
    uint64_t pendingExternalTokens_ = 0;
    uint64_t pendingExternalInjections_ = 0;

    RunMode mode_ = RunMode::Observe;

    bool traceEnabled_ = false;
    std::deque<TraceFrame> traceFrames_;
    static constexpr size_t kTraceHistoryFrames = 20;

    std::vector<uint8_t> previousVision_;
    std::array<float, 32> previousAudioBands_{};
    bool havePreviousAudio_ = false;
    std::unordered_map<int, std::array<float,3>> previousMotionSensor_;
    std::unordered_map<int, float> previousEnvironmentLevel_;
    TouchState previousTouch_{};
};

std::string recommendationJson(const ScaleRecommendation& r);

} // namespace wb
